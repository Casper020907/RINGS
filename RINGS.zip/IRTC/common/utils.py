
import os
import random
from pathlib import Path
import numpy as np
import torch


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True


def mkdir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def save_checkpoint(path, **kwargs):
    mkdir(os.path.dirname(path))
    torch.save(kwargs, path)


def load_checkpoint(path, map_location='cpu'):
    return torch.load(path, map_location=map_location)


def accuracy_score_np(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    return float((y_true == y_pred).mean())


def macro_prf_np(y_true, y_pred, n_classes=None):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    if n_classes is None:
        n_classes = int(max(y_true.max(), y_pred.max()) + 1) if y_true.size else 0
    precisions, recalls, f1s = [], [], []
    for c in range(n_classes):
        tp = np.sum((y_true == c) & (y_pred == c))
        fp = np.sum((y_true != c) & (y_pred == c))
        fn = np.sum((y_true == c) & (y_pred != c))
        prec = tp / (tp + fp + 1e-12)
        rec = tp / (tp + fn + 1e-12)
        f1 = 2 * prec * rec / (prec + rec + 1e-12)
        precisions.append(prec); recalls.append(rec); f1s.append(f1)
    return float(np.mean(precisions)), float(np.mean(recalls)), float(np.mean(f1s))


def classification_metrics(y_true, logits):
    y_true = np.asarray(y_true)
    logits = np.asarray(logits)
    y_pred = logits.argmax(axis=1)
    n_classes = logits.shape[1]
    acc = accuracy_score_np(y_true, y_pred)
    p, r, f1 = macro_prf_np(y_true, y_pred, n_classes)
    out = {'acc': acc, 'precision_macro': p, 'recall_macro': r, 'f1_macro': f1}
    try:
        from sklearn.metrics import roc_auc_score, average_precision_score
        probs = np.exp(logits - logits.max(axis=1, keepdims=True))
        probs = probs / probs.sum(axis=1, keepdims=True)
        if n_classes == 2:
            out['auc'] = float(roc_auc_score(y_true, probs[:, 1]))
            out['prc'] = float(average_precision_score(y_true, probs[:, 1]))
        else:
            y_one = np.eye(n_classes)[y_true.astype(int)]
            out['auc'] = float(roc_auc_score(y_one, probs, multi_class='ovr', average='macro'))
            out['prc'] = float(average_precision_score(y_one, probs, average='macro'))
    except Exception:
        out['auc'] = float('nan')
        out['prc'] = float('nan')
    return out


def metric_line(prefix, m):
    return (f"{prefix}: Acc={m.get('acc', float('nan'))*100:.4f} | "
            f"Precision={m.get('precision_macro', float('nan'))*100:.4f} | "
            f"Recall={m.get('recall_macro', float('nan'))*100:.4f} | "
            f"F1={m.get('f1_macro', float('nan'))*100:.4f} | "
            f"AUC={m.get('auc', float('nan'))*100:.4f} | "
            f"PRC={m.get('prc', float('nan'))*100:.4f}")
