
import torch
import torch.nn as nn
import torch.nn.functional as F


def negative_cosine(p: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
    p = F.normalize(p, dim=-1)
    z = F.normalize(z.detach(), dim=-1)
    return 1.0 - (p * z).sum(dim=-1).mean()


def simsiam_loss(z1: torch.Tensor, z2: torch.Tensor, predictor: nn.Module) -> torch.Tensor:
    p1 = predictor(z1)
    p2 = predictor(z2)
    return 0.5 * negative_cosine(p1, z2) + 0.5 * negative_cosine(p2, z1)


def relation_graph(z: torch.Tensor, tau: float = 0.2, topk: int = 0, exclude_self: bool = True) -> torch.Tensor:
    """Row-wise sample relation distribution A, shape (B,B)."""
    z = F.normalize(z, dim=-1)
    logits = torch.matmul(z, z.t()) / tau
    B = logits.size(0)
    if exclude_self and B > 1:
        logits = logits.clone()
        logits.fill_diagonal_(-1e9)
    if topk and topk > 0 and topk < B:
        vals, idx = torch.topk(logits, k=topk, dim=-1)
        masked = torch.full_like(logits, -1e9)
        masked.scatter_(dim=-1, index=idx, src=vals)
        logits = masked
    return torch.softmax(logits, dim=-1)


def symmetric_kl(p: torch.Tensor, q: torch.Tensor, detach_target: bool = True) -> torch.Tensor:
    eps = 1e-8
    p = p.clamp_min(eps)
    q = q.clamp_min(eps)
    if detach_target:
        loss1 = F.kl_div(p.log(), q.detach(), reduction='batchmean')
        loss2 = F.kl_div(q.log(), p.detach(), reduction='batchmean')
    else:
        loss1 = F.kl_div(p.log(), q, reduction='batchmean')
        loss2 = F.kl_div(q.log(), p, reduction='batchmean')
    return 0.5 * (loss1 + loss2)


def js_divergence(p: torch.Tensor, q: torch.Tensor, detach_target: bool = True) -> torch.Tensor:
    eps = 1e-8
    p = p.clamp_min(eps)
    q = q.clamp_min(eps)
    m = 0.5 * (p + q)
    if detach_target:
        return 0.5 * F.kl_div(p.log(), m.detach(), reduction='batchmean') + \
               0.5 * F.kl_div(q.log(), m.detach(), reduction='batchmean')
    return 0.5 * F.kl_div(p.log(), m, reduction='batchmean') + 0.5 * F.kl_div(q.log(), m, reduction='batchmean')


class IRTCLoss(nn.Module):
    """Instance-Relational Time-Frequency Consistency loss.

    L = L_TIC + lambda_trgc*L_TRGC + lambda_frgc*L_FRGC + lambda_tfrc*L_TFRC.
    """
    def __init__(self, lambda_tic=1.0, lambda_trgc=0.2, lambda_frgc=0.2, lambda_tfrc=0.1,
                 tau_t=0.2, tau_f=0.2, topk=0, detach_graph_target=True):
        super().__init__()
        self.lambda_tic = lambda_tic
        self.lambda_trgc = lambda_trgc
        self.lambda_frgc = lambda_frgc
        self.lambda_tfrc = lambda_tfrc
        self.tau_t = tau_t
        self.tau_f = tau_f
        self.topk = topk
        self.detach_graph_target = detach_graph_target

    def forward(self, model, z_tw, z_ts, z_fw, z_fs, graph_weight=1.0):
        losses = {}
        losses['tic'] = simsiam_loss(z_tw, z_ts, model.predictor)

        A_tw = relation_graph(z_tw, tau=self.tau_t, topk=self.topk)
        A_ts = relation_graph(z_ts, tau=self.tau_t, topk=self.topk)
        A_fw = relation_graph(z_fw, tau=self.tau_f, topk=self.topk)
        A_fs = relation_graph(z_fs, tau=self.tau_f, topk=self.topk)

        losses['trgc'] = symmetric_kl(A_tw, A_ts, detach_target=self.detach_graph_target)
        losses['frgc'] = symmetric_kl(A_fw, A_fs, detach_target=self.detach_graph_target)
        A_t = 0.5 * (A_tw + A_ts)
        A_f = 0.5 * (A_fw + A_fs)
        losses['tfrc'] = js_divergence(A_t, A_f, detach_target=self.detach_graph_target)

        total = self.lambda_tic * losses['tic'] + graph_weight * (
            self.lambda_trgc * losses['trgc'] +
            self.lambda_frgc * losses['frgc'] +
            self.lambda_tfrc * losses['tfrc']
        )
        losses['total'] = total
        return losses
