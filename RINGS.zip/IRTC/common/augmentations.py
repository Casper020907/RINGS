# -*- coding: utf-8 -*-
"""Time-series augmentations.

The default behavior remains compatible with the classification project.
Forecasting code should instantiate augmentors with ``forecasting_safe=True``.
In that mode:
- temporal order is never permuted;
- no arbitrary crop/resize is used;
- the final ``preserve_tail`` timestamps are copied back unchanged;
- frequency perturbations are restricted to the historical prefix.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F


def ensure_bct(x: torch.Tensor) -> torch.Tensor:
    """Return tensor as [B,C,T]."""
    if x.dim() == 2:
        return x.unsqueeze(1).float()
    if x.dim() != 3:
        raise ValueError(
            f"Expected 2D/3D time-series tensor, got shape={tuple(x.shape)}"
        )
    x = x.float()
    if x.shape[1] <= x.shape[2] and x.shape[1] <= 64:
        return x
    return x.permute(0, 2, 1).contiguous()


def bct_to_btc(x: torch.Tensor) -> torch.Tensor:
    return x.permute(0, 2, 1).contiguous()


def jitter(x: torch.Tensor, sigma: float = 0.03) -> torch.Tensor:
    if sigma <= 0:
        return x
    scale = x.detach().std(dim=-1, keepdim=True).clamp_min(1e-5)
    return x + torch.randn_like(x) * scale * sigma


def scaling(x: torch.Tensor, sigma: float = 0.1) -> torch.Tensor:
    if sigma <= 0:
        return x
    factor = 1.0 + sigma * torch.randn(
        x.size(0), x.size(1), 1, device=x.device, dtype=x.dtype
    )
    return x * factor


def time_mask(x: torch.Tensor, mask_ratio: float = 0.1) -> torch.Tensor:
    if mask_ratio <= 0:
        return x
    mask = torch.rand(x.size(0), 1, x.size(-1), device=x.device) < mask_ratio
    return x.masked_fill(mask, 0.0)


def crop_resize(x: torch.Tensor, min_ratio: float = 0.8) -> torch.Tensor:
    if min_ratio >= 1.0:
        return x
    _, _, length = x.shape
    crop_len = max(
        4,
        int(
            length
            * (
                min_ratio
                + (1.0 - min_ratio)
                * torch.rand(1, device=x.device).item()
            )
        ),
    )
    if crop_len >= length:
        return x
    start = int(
        torch.randint(
            0, length - crop_len + 1, (1,), device=x.device
        ).item()
    )
    crop = x[..., start : start + crop_len]
    return F.interpolate(crop, size=length, mode="linear", align_corners=False)


def segment_permutation(
    x: torch.Tensor,
    max_segments: int = 4,
    p: float = 0.5,
) -> torch.Tensor:
    if (
        max_segments <= 1
        or torch.rand(1, device=x.device).item() > p
    ):
        return x
    _, _, length = x.shape
    n_seg = int(
        torch.randint(2, max_segments + 1, (1,), device=x.device).item()
    )
    cuts = torch.linspace(
        0, length, n_seg + 1, device=x.device
    ).long().tolist()
    perm = torch.randperm(n_seg, device=x.device).tolist()
    segments = [x[..., cuts[i] : cuts[i + 1]] for i in range(n_seg)]
    return torch.cat([segments[i] for i in perm], dim=-1)[..., :length]


def _history_and_tail(
    x: torch.Tensor,
    preserve_tail: int,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    preserve_tail = int(preserve_tail)
    if preserve_tail <= 0:
        return x, None
    if preserve_tail >= x.size(-1):
        return x[..., :0], x
    return x[..., :-preserve_tail], x[..., -preserve_tail:]


def _restore_tail(
    augmented_history: torch.Tensor,
    original_tail: torch.Tensor | None,
) -> torch.Tensor:
    if original_tail is None:
        return augmented_history
    return torch.cat([augmented_history, original_tail], dim=-1)


class TimeAugmentor:
    """Weak/strong time-domain augmentation for [B,C,T]."""

    def __init__(
        self,
        weak: bool = True,
        forecasting_safe: bool = False,
        preserve_tail: int = 0,
    ):
        self.weak = bool(weak)
        self.forecasting_safe = bool(forecasting_safe)
        self.preserve_tail = int(preserve_tail)

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        if not self.forecasting_safe:
            if self.weak:
                out = jitter(x, 0.03)
                out = scaling(out, 0.08)
                return time_mask(out, 0.05)
            out = jitter(x, 0.07)
            out = scaling(out, 0.18)
            out = time_mask(out, 0.18)
            out = crop_resize(out, 0.75)
            return segment_permutation(out, 4, p=0.35)

        # Forecasting-safe path: never alter order and never alter the
        # final patch that defines the current timestamp representation.
        history, tail = _history_and_tail(x, self.preserve_tail)
        if history.size(-1) == 0:
            return x.clone()

        if self.weak:
            history = jitter(history, 0.01)
            history = time_mask(history, 0.03)
        else:
            history = jitter(history, 0.025)
            history = scaling(history, 0.04)
            history = time_mask(history, 0.12)

        return _restore_tail(history, tail)


def frequency_augment(
    x: torch.Tensor,
    weak: bool = True,
    amp_sigma: float | None = None,
    mask_ratio: float | None = None,
    phase_sigma: float | None = None,
) -> torch.Tensor:
    """Frequency-domain perturbation followed by inverse FFT."""
    batch, channels, length = x.shape
    if length == 0:
        return x
    if amp_sigma is None:
        amp_sigma = 0.03 if weak else 0.08
    if mask_ratio is None:
        mask_ratio = 0.05 if weak else 0.15
    if phase_sigma is None:
        phase_sigma = 0.02 if weak else 0.06

    spectrum = torch.fft.rfft(x, dim=-1)
    amp_factor = 1.0 + amp_sigma * torch.randn(
        batch,
        channels,
        spectrum.size(-1),
        device=x.device,
        dtype=x.dtype,
    )
    spectrum = spectrum * amp_factor

    if mask_ratio > 0:
        mask = (
            torch.rand(
                batch,
                1,
                spectrum.size(-1),
                device=x.device,
            )
            < mask_ratio
        )
        mask[..., 0] = False
        spectrum = spectrum.masked_fill(mask, 0.0)

    if phase_sigma > 0:
        phase_noise = phase_sigma * torch.randn(
            batch,
            channels,
            spectrum.size(-1),
            device=x.device,
            dtype=x.dtype,
        )
        spectrum = spectrum * torch.exp(1j * phase_noise)

    return torch.fft.irfft(spectrum, n=length, dim=-1).real


class FreqAugmentor:
    def __init__(
        self,
        weak: bool = True,
        forecasting_safe: bool = False,
        preserve_tail: int = 0,
    ):
        self.weak = bool(weak)
        self.forecasting_safe = bool(forecasting_safe)
        self.preserve_tail = int(preserve_tail)

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        if not self.forecasting_safe:
            return frequency_augment(x, weak=self.weak)

        history, tail = _history_and_tail(x, self.preserve_tail)
        if history.size(-1) < 4:
            return x.clone()

        if self.weak:
            augmented = frequency_augment(
                history,
                weak=True,
                amp_sigma=0.015,
                mask_ratio=0.02,
                phase_sigma=0.01,
            )
        else:
            augmented = frequency_augment(
                history,
                weak=False,
                amp_sigma=0.04,
                mask_ratio=0.08,
                phase_sigma=0.025,
            )
        return _restore_tail(augmented, tail)
