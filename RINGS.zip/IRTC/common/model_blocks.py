import torch
import torch.nn as nn
import torch.nn.functional as F


def _match_length(y: torch.Tensor, target_len: int) -> torch.Tensor:
    """Crop or interpolate temporal dimension to target length."""
    if y.size(-1) == target_len:
        return y
    if y.size(-1) > target_len:
        return y[..., :target_len]
    return F.interpolate(y, size=target_len, mode='linear', align_corners=False)


class ConvBlock(nn.Module):
    """Original lightweight TCN block, kept for backbone ablations."""
    def __init__(self, dim: int, kernel_size: int = 3, dilation: int = 1, dropout: float = 0.1):
        super().__init__()
        pad = (kernel_size - 1) * dilation // 2
        self.net = nn.Sequential(
            nn.Conv1d(dim, dim, kernel_size, padding=pad, dilation=dilation),
            nn.BatchNorm1d(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(dim, dim, kernel_size, padding=pad, dilation=dilation),
            nn.BatchNorm1d(dim),
            nn.GELU(),
        )

    def forward(self, x):
        y = self.net(x)
        y = _match_length(y, x.size(-1))
        return x + y


class ChannelIndependentTCN(nn.Module):
    """Channel-independent TCN encoder.

    Kept mainly for ablation. The default backbone is now the ResNet-style
    encoder below.
    """
    def __init__(self, hidden_dim: int = 128, depth: int = 4, dropout: float = 0.1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.stem = nn.Sequential(
            nn.Conv1d(1, hidden_dim, kernel_size=7, padding=3),
            nn.BatchNorm1d(hidden_dim),
            nn.GELU(),
        )
        blocks = []
        for i in range(depth):
            blocks.append(ConvBlock(hidden_dim, kernel_size=3, dilation=2 ** i, dropout=dropout))
        self.blocks = nn.Sequential(*blocks)
        self.out_norm = nn.BatchNorm1d(hidden_dim)

    def forward_sequence(self, x):
        # x: B,C,T
        B, C, T = x.shape
        y = x.reshape(B * C, 1, T)
        y = self.stem(y)
        y = self.blocks(y)
        y = self.out_norm(y)
        y = _match_length(y, T)
        # B*C,D,T -> B,C,D,T -> B,D,T
        y = y.reshape(B, C, self.hidden_dim, T).mean(dim=1)
        return y

    def forward(self, x):
        seq = self.forward_sequence(x)
        return seq.mean(dim=-1)


class ResNetBlock1D(nn.Module):
    """SimMTM-style 1D residual block.

    This block follows the common time-series ResNet design used in many
    SimMTM/TF-C/TS-TCC style classification backbones: stacked 1D convolutions,
    BatchNorm, ReLU/GELU activation and a residual shortcut. Kernel sizes
    8/5/3 are intentionally used because they are strong for local temporal
    morphology in classification transfer tasks.
    """
    def __init__(self, in_channels: int, out_channels: int, dropout: float = 0.1):
        super().__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=8, padding=4, bias=False)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=5, padding=2, bias=False)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.conv3 = nn.Conv1d(out_channels, out_channels, kernel_size=3, padding=1, bias=False)
        self.bn3 = nn.BatchNorm1d(out_channels)
        self.dropout = nn.Dropout(dropout)
        self.shortcut = nn.Identity() if in_channels == out_channels else nn.Sequential(
            nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.BatchNorm1d(out_channels),
        )
        self.act = nn.GELU()

    def forward(self, x):
        T = x.size(-1)
        residual = self.shortcut(x)
        residual = _match_length(residual, T)

        y = self.conv1(x)
        y = self.bn1(y)
        y = self.act(y)
        y = self.dropout(y)

        y = self.conv2(y)
        y = self.bn2(y)
        y = self.act(y)
        y = self.dropout(y)

        y = self.conv3(y)
        y = self.bn3(y)
        y = _match_length(y, residual.size(-1))
        return self.act(y + residual)


class ChannelIndependentResNet1D(nn.Module):
    """Channel-independent 1D ResNet encoder.

    Why channel-independent:
    - SimMTM-style transfer experiments often pretrain on one dataset and
      fine-tune on another.
    - Source and target datasets may have different channel counts.
    - A standard first Conv1d(in_channels=C, ...) would make checkpoint loading
      fail when C changes.

    This encoder applies the same ResNet stem to every channel separately and
    averages channel-level representations. It keeps the SimMTM/ResNet temporal
    residual design while remaining safe for cross-dataset transfer.
    """
    def __init__(self, hidden_dim: int = 128, depth: int = 4, dropout: float = 0.1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.stem = nn.Sequential(
            nn.Conv1d(1, hidden_dim, kernel_size=7, padding=3, bias=False),
            nn.BatchNorm1d(hidden_dim),
            nn.GELU(),
        )
        self.blocks = nn.Sequential(*[
            ResNetBlock1D(hidden_dim, hidden_dim, dropout=dropout)
            for _ in range(depth)
        ])
        self.out_norm = nn.BatchNorm1d(hidden_dim)

    def forward_sequence(self, x):
        # x: B,C,T
        B, C, T = x.shape
        y = x.reshape(B * C, 1, T)
        y = self.stem(y)
        y = self.blocks(y)
        y = self.out_norm(y)
        y = _match_length(y, T)
        y = y.reshape(B, C, self.hidden_dim, T).mean(dim=1)
        return y

    def forward(self, x):
        seq = self.forward_sequence(x)
        return seq.mean(dim=-1)


# ============================================================
# Inception backbone
# ============================================================

class InceptionBlock1D(nn.Module):
    """Channel-independent Inception-style 1D block.

    It uses multi-scale convolution branches to capture local temporal
    morphology at different receptive fields, which is often useful for
    UCR-like datasets such as FordA/FordB.
    """
    def __init__(
        self,
        in_channels: int,
        branch_channels: int,
        bottleneck_channels: int,
        kernel_sizes=(9, 19, 39),
        dropout: float = 0.1,
        use_residual: bool = True,
    ):
        super().__init__()

        self.use_residual = use_residual

        # For the first single-channel layer, bottleneck is unnecessary.
        # For deeper layers, bottleneck reduces computation before large kernels.
        if in_channels > 1:
            self.bottleneck = nn.Conv1d(
                in_channels,
                bottleneck_channels,
                kernel_size=1,
                bias=False,
            )
            conv_in = bottleneck_channels
        else:
            self.bottleneck = nn.Identity()
            conv_in = in_channels

        self.branches = nn.ModuleList([
            nn.Conv1d(
                conv_in,
                branch_channels,
                kernel_size=k,
                padding=k // 2,
                bias=False,
            )
            for k in kernel_sizes
        ])

        self.pool_branch = nn.Sequential(
            nn.MaxPool1d(kernel_size=3, stride=1, padding=1),
            nn.Conv1d(
                in_channels,
                branch_channels,
                kernel_size=1,
                bias=False,
            ),
        )

        out_channels = branch_channels * (len(kernel_sizes) + 1)
        self.out_channels = out_channels

        self.bn = nn.BatchNorm1d(out_channels)
        self.act = nn.GELU()
        self.dropout = nn.Dropout(dropout)

        if use_residual:
            if in_channels != out_channels:
                self.shortcut = nn.Sequential(
                    nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                    nn.BatchNorm1d(out_channels),
                )
            else:
                self.shortcut = nn.Identity()
        else:
            self.shortcut = None

    def forward(self, x):
        # x: [B*C, D, T]
        T = x.size(-1)

        z = self.bottleneck(x)

        outs = [branch(z) for branch in self.branches]
        outs.append(self.pool_branch(x))

        y = torch.cat(outs, dim=1)
        y = _match_length(y, T)
        y = self.bn(y)

        if self.shortcut is not None:
            residual = self.shortcut(x)
            residual = _match_length(residual, y.size(-1))
            y = y + residual

        y = self.act(y)
        y = self.dropout(y)
        return y


class ChannelIndependentInception1D(nn.Module):
    """Channel-independent Inception1D encoder.

    This follows the same channel-independent protocol as your existing
    ResNet/TCN backbones:
    - reshape [B, C, T] -> [B*C, 1, T]
    - apply the same temporal encoder to each channel
    - reshape back and average over channels

    This keeps cross-dataset transfer safe when source/target channel counts differ.
    """
    def __init__(self, hidden_dim: int = 128, depth: int = 4, dropout: float = 0.1):
        super().__init__()

        self.hidden_dim = hidden_dim

        # 3 convolution branches + 1 pooling branch.
        # branch_channels * 4 ~= hidden_dim.
        branch_channels = max(8, hidden_dim // 4)
        bottleneck_channels = max(8, hidden_dim // 4)

        blocks = []
        in_channels = 1

        for _ in range(depth):
            block = InceptionBlock1D(
                in_channels=in_channels,
                branch_channels=branch_channels,
                bottleneck_channels=bottleneck_channels,
                kernel_sizes=(9, 19, 39),
                dropout=dropout,
                use_residual=True,
            )
            blocks.append(block)
            in_channels = block.out_channels

        self.blocks = nn.Sequential(*blocks)
        self.out_norm = nn.BatchNorm1d(in_channels)

        # If in_channels is not exactly hidden_dim, project it back.
        # Usually hidden_dim=128 and branch_channels=32, so in_channels=128.
        if in_channels == hidden_dim:
            self.proj = nn.Identity()
        else:
            self.proj = nn.Conv1d(in_channels, hidden_dim, kernel_size=1, bias=False)

    def forward_sequence(self, x):
        # x: B,C,T
        B, C, T = x.shape

        y = x.reshape(B * C, 1, T)
        y = self.blocks(y)
        y = self.out_norm(y)
        y = self.proj(y)
        y = _match_length(y, T)

        # B*C,D,T -> B,C,D,T -> B,D,T
        y = y.reshape(B, C, self.hidden_dim, T).mean(dim=1)
        return y

    def forward(self, x):
        seq = self.forward_sequence(x)
        return seq.mean(dim=-1)


class ProjectionHead(nn.Module):
    def __init__(self, in_dim: int, proj_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, in_dim),
            nn.BatchNorm1d(in_dim),
            nn.GELU(),
            nn.Linear(in_dim, proj_dim),
        )

    def forward(self, x):
        return self.net(x)


class Predictor(nn.Module):
    def __init__(self, dim: int = 128, hidden_dim: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, dim),
        )

    def forward(self, x):
        return self.net(x)


def build_backbone(encoder_type: str, hidden_dim: int, depth: int, dropout: float) -> nn.Module:
    encoder_type = (encoder_type or 'resnet').lower()

    if encoder_type in ['resnet', 'resnet1d', 'simmtm_resnet']:
        return ChannelIndependentResNet1D(
            hidden_dim=hidden_dim,
            depth=depth,
            dropout=dropout,
        )

    if encoder_type in ['tcn', 'ci_tcn']:
        return ChannelIndependentTCN(
            hidden_dim=hidden_dim,
            depth=depth,
            dropout=dropout,
        )

    if encoder_type in ['inception', 'inception1d', 'ci_inception']:
        return ChannelIndependentInception1D(
            hidden_dim=hidden_dim,
            depth=depth,
            dropout=dropout,
        )

    raise ValueError(
        f"Unknown encoder type: {encoder_type}. "
        f"Available: resnet, tcn, inception"
    )


class IRTCEncoderModel(nn.Module):
    def __init__(self, hidden_dim=128, depth=4, proj_dim=128, dropout=0.1, encoder_type: str = 'resnet'):
        super().__init__()
        self.encoder_type = encoder_type
        self.encoder = build_backbone(encoder_type, hidden_dim, depth, dropout)
        self.projector = ProjectionHead(hidden_dim, proj_dim)
        self.predictor = Predictor(proj_dim)
        self.hidden_dim = hidden_dim
        self.proj_dim = proj_dim

    def encode(self, x, project=False):
        h = self.encoder(x)
        if project:
            return self.projector(h)
        return h

    def encode_sequence(self, x):
        return self.encoder.forward_sequence(x)

    def forward(self, x):
        return self.encode(x, project=True)