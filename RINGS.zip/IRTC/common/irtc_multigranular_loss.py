import torch
import torch.nn as nn
import torch.nn.functional as F


def _flatten_last_dim(z: torch.Tensor) -> torch.Tensor:
    """Flatten every leading dimension and preserve the representation dimension."""
    if z.dim() < 2:
        raise ValueError(f"Expected tensor with at least 2 dims, got {tuple(z.shape)}")
    return z.reshape(-1, z.size(-1))


def negative_cosine(p: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
    """SimSiam negative cosine distance with stop-gradient on the target."""
    p = F.normalize(p, dim=-1)
    z = F.normalize(z.detach(), dim=-1)
    return 1.0 - (p * z).sum(dim=-1).mean()


def simsiam_loss(
    z1: torch.Tensor,
    z2: torch.Tensor,
    predictor: nn.Module,
) -> torch.Tensor:
    """SimSiam loss for [B,D], [B,C,D], or [B,N,D] representations."""
    if z1.shape != z2.shape:
        raise ValueError(
            f"SimSiam views must have the same shape, got "
            f"{tuple(z1.shape)} and {tuple(z2.shape)}"
        )

    z1_flat = _flatten_last_dim(z1)
    z2_flat = _flatten_last_dim(z2)

    p1 = predictor(z1_flat)
    p2 = predictor(z2_flat)

    return (
        0.5 * negative_cosine(p1, z2_flat)
        + 0.5 * negative_cosine(p2, z1_flat)
    )


def relation_graph(
    z: torch.Tensor,
    tau: float = 0.2,
    topk: int = 0,
    exclude_self: bool = True,
) -> torch.Tensor:
    """Build a row-wise sample relation distribution, shape [B,B]."""
    if z.dim() != 2:
        raise ValueError(f"Expected z as [B,D], got {tuple(z.shape)}")
    if tau <= 0:
        raise ValueError(f"tau must be positive, got {tau}")

    z = F.normalize(z, dim=-1)
    logits = torch.matmul(z, z.transpose(0, 1)) / tau
    batch_size = logits.size(0)

    if exclude_self and batch_size > 1:
        logits = logits.clone()
        logits.fill_diagonal_(-torch.inf)

    # topk counts non-self candidates when self is excluded.
    max_neighbors = batch_size - 1 if exclude_self else batch_size
    if topk > 0 and topk < max_neighbors:
        values, indices = torch.topk(logits, k=topk, dim=-1)
        masked = torch.full_like(logits, -torch.inf)
        masked.scatter_(dim=-1, index=indices, src=values)
        logits = masked

    return torch.softmax(logits, dim=-1)


def _kl_distribution(
    p: torch.Tensor,
    q: torch.Tensor,
    detach_q: bool,
) -> torch.Tensor:
    """KL(p || q), averaged over every row."""
    eps = 1e-8
    p = p.clamp_min(eps)
    q_target = q.detach() if detach_q else q
    q_target = q_target.clamp_min(eps)

    return (
        p * (p.log() - q_target.log())
    ).sum(dim=-1).mean()


def symmetric_kl(
    p: torch.Tensor,
    q: torch.Tensor,
    detach_target: bool = True,
) -> torch.Tensor:
    """0.5 * KL(p||q) + 0.5 * KL(q||p)."""
    return 0.5 * (
        _kl_distribution(p, q, detach_q=detach_target)
        + _kl_distribution(q, p, detach_q=detach_target)
    )


def js_divergence(
    p: torch.Tensor,
    q: torch.Tensor,
    detach_consensus: bool = True,
) -> torch.Tensor:
    """Standard Jensen-Shannon divergence.

    JS(p,q) = 0.5*KL(p||m) + 0.5*KL(q||m),
    where m = 0.5*(p+q).
    """
    eps = 1e-8
    p = p.clamp_min(eps)
    q = q.clamp_min(eps)
    consensus = 0.5 * (p + q)
    if detach_consensus:
        consensus = consensus.detach()

    return 0.5 * (
        _kl_distribution(p, consensus, detach_q=False)
        + _kl_distribution(q, consensus, detach_q=False)
    )


def _resolve_predictor(model: nn.Module) -> nn.Module:
    """Support either encoder_model or the outer forecasting wrapper."""
    if hasattr(model, "predictor"):
        return model.predictor
    if hasattr(model, "encoder_model") and hasattr(model.encoder_model, "predictor"):
        return model.encoder_model.predictor
    raise AttributeError(
        "Could not find predictor. Expected model.predictor or "
        "model.encoder_model.predictor."
    )


class MultiGranularIRTCLoss(nn.Module):
    """Multi-granular Instance-Relational Time-Frequency Consistency loss.

    Each view must be a dictionary:
        {
            "global":  [B, Dp],
            "channel": [B, C, Dp],
            "patch":   [B, N, Dp],
        }

    Main improvements over the original loss:
      1. Both temporal and frequency views receive SimSiam instance constraints.
      2. Channel-level and patch-level representations are directly supervised.
      3. TFRC uses the mathematically standard Jensen-Shannon divergence.

    Total:
        L = lambda_global * L_global
          + lambda_channel * L_channel
          + lambda_patch * L_patch
          + graph_weight * (
                lambda_trgc * L_trgc
              + lambda_frgc * L_frgc
              + lambda_tfrc * L_tfrc
            )
    """

    REQUIRED_KEYS = ("global", "channel", "patch")

    def __init__(
        self,
        lambda_global: float = 1.0,
        lambda_channel: float = 0.2,
        lambda_patch: float = 0.2,
        lambda_trgc: float = 0.2,
        lambda_frgc: float = 0.2,
        lambda_tfrc: float = 0.1,
        tau_t: float = 0.2,
        tau_f: float = 0.2,
        topk: int = 0,
        detach_graph_target: bool = True,
        detach_js_consensus: bool = True,
    ):
        super().__init__()
        self.lambda_global = lambda_global
        self.lambda_channel = lambda_channel
        self.lambda_patch = lambda_patch
        self.lambda_trgc = lambda_trgc
        self.lambda_frgc = lambda_frgc
        self.lambda_tfrc = lambda_tfrc
        self.tau_t = tau_t
        self.tau_f = tau_f
        self.topk = topk
        self.detach_graph_target = detach_graph_target
        self.detach_js_consensus = detach_js_consensus

    def _validate_view(self, name: str, view: dict[str, torch.Tensor]) -> None:
        missing = [key for key in self.REQUIRED_KEYS if key not in view]
        if missing:
            raise KeyError(f"{name} is missing representation keys: {missing}")

        if view["global"].dim() != 2:
            raise ValueError(
                f"{name}['global'] must be [B,D], "
                f"got {tuple(view['global'].shape)}"
            )
        if view["channel"].dim() != 3:
            raise ValueError(
                f"{name}['channel'] must be [B,C,D], "
                f"got {tuple(view['channel'].shape)}"
            )
        if view["patch"].dim() != 3:
            raise ValueError(
                f"{name}['patch'] must be [B,N,D], "
                f"got {tuple(view['patch'].shape)}"
            )

    def forward(
        self,
        model: nn.Module,
        z_tw: dict[str, torch.Tensor],
        z_ts: dict[str, torch.Tensor],
        z_fw: dict[str, torch.Tensor],
        z_fs: dict[str, torch.Tensor],
        graph_weight: float = 1.0,
    ) -> dict[str, torch.Tensor]:
        for name, view in (
            ("z_tw", z_tw),
            ("z_ts", z_ts),
            ("z_fw", z_fw),
            ("z_fs", z_fs),
        ):
            self._validate_view(name, view)

        predictor = _resolve_predictor(model)
        losses: dict[str, torch.Tensor] = {}

        # ------------------------------------------------------------------
        # 1. Global instance consistency in both domains.
        # ------------------------------------------------------------------
        losses["tic_time"] = simsiam_loss(
            z_tw["global"],
            z_ts["global"],
            predictor,
        )
        losses["tic_freq"] = simsiam_loss(
            z_fw["global"],
            z_fs["global"],
            predictor,
        )
        losses["global_ic"] = 0.5 * (
            losses["tic_time"] + losses["tic_freq"]
        )

        # ------------------------------------------------------------------
        # 2. Channel-level consistency.
        # Each channel keeps a direct self-supervised learning signal.
        # ------------------------------------------------------------------
        losses["channel_time"] = simsiam_loss(
            z_tw["channel"],
            z_ts["channel"],
            predictor,
        )
        losses["channel_freq"] = simsiam_loss(
            z_fw["channel"],
            z_fs["channel"],
            predictor,
        )
        losses["channel_ic"] = 0.5 * (
            losses["channel_time"] + losses["channel_freq"]
        )

        # ------------------------------------------------------------------
        # 3. Patch-level consistency.
        # Enable only when augmentations preserve patch correspondence.
        # ------------------------------------------------------------------
        losses["patch_time"] = simsiam_loss(
            z_tw["patch"],
            z_ts["patch"],
            predictor,
        )
        losses["patch_freq"] = simsiam_loss(
            z_fw["patch"],
            z_fs["patch"],
            predictor,
        )
        losses["patch_ic"] = 0.5 * (
            losses["patch_time"] + losses["patch_freq"]
        )

        # ------------------------------------------------------------------
        # 4. Global batch-wise relation consistency.
        # Skip degenerate relation losses when B < 3.
        # ------------------------------------------------------------------
        batch_size = z_tw["global"].size(0)
        zero = z_tw["global"].sum() * 0.0

        if batch_size >= 3:
            a_tw = relation_graph(
                z_tw["global"],
                tau=self.tau_t,
                topk=self.topk,
            )
            a_ts = relation_graph(
                z_ts["global"],
                tau=self.tau_t,
                topk=self.topk,
            )
            a_fw = relation_graph(
                z_fw["global"],
                tau=self.tau_f,
                topk=self.topk,
            )
            a_fs = relation_graph(
                z_fs["global"],
                tau=self.tau_f,
                topk=self.topk,
            )

            losses["trgc"] = symmetric_kl(
                a_tw,
                a_ts,
                detach_target=self.detach_graph_target,
            )
            losses["frgc"] = symmetric_kl(
                a_fw,
                a_fs,
                detach_target=self.detach_graph_target,
            )

            a_t = 0.5 * (a_tw + a_ts)
            a_f = 0.5 * (a_fw + a_fs)
            losses["tfrc"] = js_divergence(
                a_t,
                a_f,
                detach_consensus=self.detach_js_consensus,
            )
        else:
            losses["trgc"] = zero
            losses["frgc"] = zero
            losses["tfrc"] = zero

        graph_loss = (
            self.lambda_trgc * losses["trgc"]
            + self.lambda_frgc * losses["frgc"]
            + self.lambda_tfrc * losses["tfrc"]
        )

        losses["total"] = (
            self.lambda_global * losses["global_ic"]
            + self.lambda_channel * losses["channel_ic"]
            + self.lambda_patch * losses["patch_ic"]
            + float(graph_weight) * graph_loss
        )

        return losses
