
import numpy as np


def _safe_div(a, b):
    return float(a) / float(b) if b != 0 else 0.0


def binary_metrics(y_true, y_pred):
    y_true = np.asarray(y_true).astype(int).reshape(-1)
    y_pred = np.asarray(y_pred).astype(int).reshape(-1)

    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())

    precision = _safe_div(tp, tp + fp)
    recall = _safe_div(tp, tp + fn)
    f1 = _safe_div(2 * precision * recall, precision + recall)
    acc = _safe_div(tp + tn, tp + fp + tn + fn)

    return {
        "accuracy": acc,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "tp": tp,
        "fp": fp,
        "tn": tn,
        "fn": fn,
    }


def best_f1_threshold(scores, labels, num_thresholds=500):
    scores = np.asarray(scores, dtype=np.float64).reshape(-1)
    labels = np.asarray(labels).astype(int).reshape(-1)

    if len(np.unique(labels)) < 2:
        thr = float(np.percentile(scores, 99))
        pred = (scores >= thr).astype(int)
        m = binary_metrics(labels, pred)
        m["threshold"] = thr
        return m

    thresholds = np.unique(np.percentile(scores, np.linspace(0, 100, num_thresholds)))
    best = None
    for thr in thresholds:
        pred = (scores >= thr).astype(int)
        m = binary_metrics(labels, pred)
        m["threshold"] = float(thr)
        if best is None or m["f1"] > best["f1"]:
            best = m
    return best


def quantile_threshold(train_scores, q=0.995):
    return float(np.quantile(np.asarray(train_scores, dtype=np.float64).reshape(-1), q))


def auroc_auprc(scores, labels):
    scores = np.asarray(scores).reshape(-1)
    labels = np.asarray(labels).astype(int).reshape(-1)
    out = {"auroc": None, "auprc": None}
    try:
        from sklearn.metrics import roc_auc_score, average_precision_score
        if len(np.unique(labels)) >= 2:
            out["auroc"] = float(roc_auc_score(labels, scores))
            out["auprc"] = float(average_precision_score(labels, scores))
    except Exception:
        pass
    return out


def normalize_scores(scores, ref_scores=None, eps=1e-6):
    scores = np.asarray(scores, dtype=np.float64)
    ref = np.asarray(ref_scores if ref_scores is not None else scores, dtype=np.float64)
    med = np.median(ref)
    iqr = np.percentile(ref, 75) - np.percentile(ref, 25)
    if iqr < eps:
        iqr = np.std(ref) + eps
    return ((scores - med) / iqr).astype(np.float32)


# ==============================
# TS2Vec / SoftCLT-style AD eval
# ==============================


def infer_default_delay(dataset_name):
    name = str(dataset_name).lower()
    if "yahoo" in name:
        return 3
    if "kpi" in name:
        return 7
    return 7


def _moving_mean(x, window):
    """Bottleneck-free moving mean with NaN warmup behavior close to bottleneck.move_mean."""
    x = np.asarray(x, dtype=np.float64).reshape(-1)
    window = int(window)
    out = np.full_like(x, np.nan, dtype=np.float64)
    if window <= 1:
        return x.copy()
    if len(x) < window:
        return out
    csum = np.cumsum(np.insert(x, 0, 0.0))
    vals = (csum[window:] - csum[:-window]) / float(window)
    out[window - 1:] = vals
    return out


def np_shift(arr, num, fill_value=np.nan):
    arr = np.asarray(arr)
    result = np.empty_like(arr)
    if num > 0:
        result[:num] = fill_value
        result[num:] = arr[:-num]
    elif num < 0:
        result[num:] = fill_value
        result[:num] = arr[-num:]
    else:
        result[:] = arr
    return result


def ts2vec_adjust_scores(train_scores, test_scores, ma_window=21, skip=22, eps=1e-8):
    """
    TS2Vec-style anomaly score normalization.

    Original TS2Vec computes train_err/test_err, then subtracts a shifted moving
    average of concat(train_err, test_err), and thresholds train_err_adj[22:].
    Here we apply the same normalization to IRTC point-level anomaly scores.
    """
    train_scores = np.asarray(train_scores, dtype=np.float64).reshape(-1)
    test_scores = np.asarray(test_scores, dtype=np.float64).reshape(-1)
    concat = np.concatenate([train_scores, test_scores], axis=0)

    ma = np_shift(_moving_mean(concat, int(ma_window)), 1)
    # Avoid division by zero / NaN in early positions.
    valid_ma = ma[np.isfinite(ma)]
    fill = float(np.nanmedian(valid_ma)) if valid_ma.size > 0 else 1.0
    ma = np.where(np.isfinite(ma), ma, fill)
    ma = np.where(np.abs(ma) < eps, eps, ma)

    adj = (concat - ma) / ma
    train_adj = adj[:len(train_scores)]
    test_adj = adj[len(train_scores):]

    if skip > 0 and len(train_adj) > skip:
        train_adj = train_adj[skip:]
    return train_adj.astype(np.float64), test_adj.astype(np.float64)


def ts2vec_threshold(train_adj_scores, sigma=4.0):
    train_adj_scores = np.asarray(train_adj_scores, dtype=np.float64).reshape(-1)
    train_adj_scores = train_adj_scores[np.isfinite(train_adj_scores)]
    if train_adj_scores.size == 0:
        return 0.0
    return float(np.mean(train_adj_scores) + float(sigma) * np.std(train_adj_scores))


def ts2vec_suppress_duplicate_alarms(predict, delay=7):
    """
    Match TS2Vec post-processing: if an alarm has already occurred in the
    previous delay points, suppress the current alarm.
    """
    pred = np.asarray(predict).astype(int).reshape(-1).copy()
    delay = int(delay)
    if delay <= 0:
        return pred
    for i in range(len(pred)):
        if i >= delay and pred[i - delay:i].sum() >= 1:
            pred[i] = 0
    return pred


def get_range_proba(predict, label, delay=7):
    """
    TS2Vec range-probability adjustment.
    If an anomaly segment has at least one prediction within its first delay+1
    points, the whole segment is counted as detected; otherwise it is missed.
    """
    predict = np.asarray(predict).astype(int).reshape(-1)
    label = np.asarray(label).astype(int).reshape(-1)
    assert predict.shape == label.shape, (predict.shape, label.shape)

    splits = np.where(label[1:] != label[:-1])[0] + 1
    is_anomaly = label[0] == 1
    new_predict = np.array(predict, dtype=int)
    pos = 0

    for sp in splits:
        if is_anomaly:
            if 1 in predict[pos:min(pos + int(delay) + 1, sp)]:
                new_predict[pos:sp] = 1
            else:
                new_predict[pos:sp] = 0
        is_anomaly = not is_anomaly
        pos = sp

    sp = len(label)
    if is_anomaly:
        if 1 in predict[pos:min(pos + int(delay) + 1, sp)]:
            new_predict[pos:sp] = 1
        else:
            new_predict[pos:sp] = 0
    return new_predict


def reconstruct_label(timestamp, label):
    """
    TS2Vec missing-timestamp reconstruction. If timestamp is None, returns label.
    """
    if timestamp is None:
        return np.asarray(label).astype(int).reshape(-1)
    timestamp = np.asarray(timestamp, np.int64).reshape(-1)
    label = np.asarray(label, np.int64).reshape(-1)
    index = np.argsort(timestamp)
    timestamp_sorted = np.asarray(timestamp[index])
    label = np.asarray(label[index])
    if len(timestamp_sorted) <= 1:
        return label
    interval = np.min(np.diff(timestamp_sorted))
    idx = (timestamp_sorted - timestamp_sorted[0]) // interval
    new_label = np.zeros(shape=((timestamp_sorted[-1] - timestamp_sorted[0]) // interval + 1,), dtype=int)
    new_label[idx] = label
    return new_label


def ts2vec_eval_from_pred(pred, label, delay=7, timestamp=None):
    """
    Return TS2Vec/SoftCLT-style point-level F1/Precision/Recall.
    This is the field you should compare with TS2Vec/SoftCLT AD tables.
    """
    label_rec = reconstruct_label(timestamp, label)
    pred_rec = reconstruct_label(timestamp, pred)
    pred_rec = ts2vec_suppress_duplicate_alarms(pred_rec, delay=delay)
    pred_adj = get_range_proba(pred_rec, label_rec, delay=delay)
    out = binary_metrics(label_rec, pred_adj)
    out["delay"] = int(delay)
    return out
