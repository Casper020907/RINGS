
import numpy as np
import torch
import torch.nn.functional as F

from common.augmentations import ensure_bct, FreqAugmentor


def extract_embeddings(model, loader, device, use_freq=False):
    """
    Return projected embeddings [N, D], reusing Model.encode_projected used in IRTC pretraining.
    """
    model.eval()
    zs = []
    freq_aug = FreqAugmentor(weak=True) if use_freq else None

    with torch.no_grad():
        for seq_x, _ in loader:
            x = ensure_bct(seq_x.float()).to(device)  # [B,T,C] -> [B,C,T]
            if use_freq:
                x = freq_aug(x)
            z = model.encode_projected(x)
            z = F.normalize(z, dim=1)
            zs.append(z.detach().cpu())

    return torch.cat(zs, dim=0)


def knn_scores(train_z, test_z, k=5, chunk_size=1024):
    """
    Average cosine distance to k nearest normal train embeddings.
    """
    train_z = F.normalize(train_z.float(), dim=1)
    test_z = F.normalize(test_z.float(), dim=1)
    device = test_z.device
    train_z = train_z.to(device)
    scores = []

    for i in range(0, len(test_z), chunk_size):
        q = test_z[i:i + chunk_size].to(device)
        dist = 1.0 - torch.matmul(q, train_z.t())
        vals, _ = torch.topk(dist, k=min(k, train_z.size(0)), dim=1, largest=False)
        scores.append(vals.mean(dim=1).detach().cpu())

    return torch.cat(scores, dim=0).numpy().astype(np.float32)


def train_knn_scores_leave_one_out(train_z, k=5, chunk_size=1024):
    train_z = F.normalize(train_z.float(), dim=1)
    device = train_z.device
    scores = []
    n = len(train_z)

    for i in range(0, n, chunk_size):
        q = train_z[i:i + chunk_size].to(device)
        dist = 1.0 - torch.matmul(q, train_z.t())

        rows = torch.arange(i, min(i + chunk_size, n), device=device)
        local = torch.arange(0, len(rows), device=device)
        dist[local, rows] = float("inf")

        vals, _ = torch.topk(dist, k=min(k, max(1, n - 1)), dim=1, largest=False)
        scores.append(vals.mean(dim=1).detach().cpu())

    return torch.cat(scores, dim=0).numpy().astype(np.float32)


def _js_divergence_rows(p, q, eps=1e-8):
    p = torch.clamp(p, min=eps)
    q = torch.clamp(q, min=eps)
    m = 0.5 * (p + q)
    return 0.5 * (p * (p.log() - m.log())).sum(dim=1) + 0.5 * (q * (q.log() - m.log())).sum(dim=1)


def tfrc_scores(train_time_z, train_freq_z, test_time_z, test_freq_z, tau=0.2, chunk_size=1024):
    """
    Time-Frequency Relational Consistency anomaly score.
    For each test window, compare its soft relation distribution to normal train windows
    in time-view embedding space and frequency-view embedding space.
    """
    train_time_z = F.normalize(train_time_z.float(), dim=1)
    train_freq_z = F.normalize(train_freq_z.float(), dim=1)
    test_time_z = F.normalize(test_time_z.float(), dim=1)
    test_freq_z = F.normalize(test_freq_z.float(), dim=1)

    device = test_time_z.device
    train_time_z = train_time_z.to(device)
    train_freq_z = train_freq_z.to(device)
    scores = []

    for i in range(0, len(test_time_z), chunk_size):
        zt = test_time_z[i:i + chunk_size].to(device)
        zf = test_freq_z[i:i + chunk_size].to(device)

        at = torch.softmax(torch.matmul(zt, train_time_z.t()) / tau, dim=1)
        af = torch.softmax(torch.matmul(zf, train_freq_z.t()) / tau, dim=1)
        scores.append(_js_divergence_rows(at, af).detach().cpu())

    return torch.cat(scores, dim=0).numpy().astype(np.float32)


def train_tfrc_scores(train_time_z, train_freq_z, tau=0.2, chunk_size=1024):
    return tfrc_scores(train_time_z, train_freq_z, train_time_z, train_freq_z, tau=tau, chunk_size=chunk_size)


# =============================================================================
# IRTC-MaskScore utilities
# =============================================================================
import numpy as _np_maskscore
import torch as _torch_maskscore
import torch.nn.functional as _F_maskscore
from torch.utils.data import DataLoader as _DataLoader_maskscore
from torch.utils.data import TensorDataset as _TensorDataset_maskscore


def _take_representation_maskscore(output):
    """
    Robustly extract a 2D representation tensor [B, D] from model output.

    Supports Tensor, dict, tuple/list. If output is [B, L, D], mean-pool over L.
    """
    if isinstance(output, _torch_maskscore.Tensor):
        z = output
    elif isinstance(output, dict):
        z = None
        for k in ['repr', 'representation', 'embedding', 'emb', 'z', 'h', 'features', 'feat', 'out']:
            if k in output and isinstance(output[k], _torch_maskscore.Tensor):
                z = output[k]
                break
        if z is None:
            tensors = [v for v in output.values() if isinstance(v, _torch_maskscore.Tensor)]
            if not tensors:
                raise TypeError(f'Cannot extract tensor representation from dict keys={list(output.keys())}')
            z = next((t for t in tensors if t.ndim == 2), tensors[0])
    elif isinstance(output, (tuple, list)):
        tensors = [v for v in output if isinstance(v, _torch_maskscore.Tensor)]
        if not tensors:
            raise TypeError('Cannot extract tensor representation from tuple/list output.')
        z = next((t for t in tensors if t.ndim == 2), tensors[0])
    else:
        raise TypeError(f'Unsupported model output type: {type(output)}')

    if z.ndim == 3:
        z = z.mean(dim=1)
    elif z.ndim > 3:
        z = z.reshape(z.shape[0], -1)
    return z


def _forward_encoder_repr_maskscore(model, x):
    """
    Generic forward wrapper for IRTC models.
    Priority: model.encode(x) -> model.encoder(x) -> model(x)
    """
    if hasattr(model, 'encode') and callable(getattr(model, 'encode')):
        out = model.encode(x)
    elif hasattr(model, 'encoder') and callable(getattr(model, 'encoder')):
        out = model.encoder(x)
    else:
        out = model(x)
    return _take_representation_maskscore(out)


def apply_tail_mask(x, mask_ratio=0.2, mask_value=0.0):
    """
    Mask the tail part of a window.

    x: [B, L, C]
    Since inputs are standardized, mask_value=0.0 means replacing by train mean.
    """
    xm = x.clone()
    L = xm.shape[1]
    mask_len = max(1, int(round(float(L) * float(mask_ratio))))
    xm[:, -mask_len:, :] = float(mask_value)
    return xm


@_torch_maskscore.no_grad()
def mask_window_scores(
    model,
    windows,
    batch_size=64,
    device='cuda',
    mask_ratio=0.2,
    mask_value=0.0,
    distance='l1',
    normalize_repr=True,
    num_workers=0,
):
    """
    Compute generic IRTC-MaskScore.

    score(x) = distance( h(x), h(mask_tail(x)) )

    windows: np.ndarray [N, L, C]
    distance: l1 / l2 / cosine
    return: np.ndarray [N], window-level anomaly score.
    """
    model.eval()
    windows = _np_maskscore.asarray(windows, dtype=_np_maskscore.float32)
    dataset = _TensorDataset_maskscore(_torch_maskscore.from_numpy(windows).float())
    loader = _DataLoader_maskscore(
        dataset,
        batch_size=int(batch_size),
        shuffle=False,
        num_workers=int(num_workers),
        drop_last=False,
        pin_memory=_torch_maskscore.cuda.is_available(),
    )

    scores = []
    for (x,) in loader:
        x = x.to(device)
        xm = apply_tail_mask(x, mask_ratio=mask_ratio, mask_value=mask_value)

        z1 = _forward_encoder_repr_maskscore(model, x)
        z2 = _forward_encoder_repr_maskscore(model, xm)

        if normalize_repr:
            z1 = _F_maskscore.normalize(z1, dim=-1)
            z2 = _F_maskscore.normalize(z2, dim=-1)

        if distance == 'l1':
            sc = _torch_maskscore.mean(_torch_maskscore.abs(z1 - z2), dim=-1)
        elif distance == 'l2':
            sc = _torch_maskscore.norm(z1 - z2, p=2, dim=-1)
        elif distance == 'cosine':
            sc = 1.0 - _F_maskscore.cosine_similarity(z1, z2, dim=-1)
        else:
            raise ValueError(f'Unknown mask distance: {distance}')

        scores.append(sc.detach().cpu().numpy())

    if not scores:
        return _np_maskscore.zeros((0,), dtype=_np_maskscore.float32)
    return _np_maskscore.concatenate(scores, axis=0).astype(_np_maskscore.float32)

