
import os
import sys
import time
import json
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.optim import AdamW

_THIS = os.path.dirname(os.path.abspath(__file__))
_ANOMALY = os.path.abspath(os.path.join(_THIS, ".."))
_ROOT = os.path.abspath(os.path.join(_THIS, "..", ".."))
_FORECASTING = os.path.join(_ROOT, "IRTC_Forecasting")

for p in [_ROOT, _FORECASTING, _ANOMALY]:
    if p not in sys.path:
        sys.path.insert(0, p)

from common.augmentations import ensure_bct, TimeAugmentor, FreqAugmentor
from common.losses import IRTCLoss
from common.utils import mkdir, save_checkpoint, set_seed
from models.IRTC import Model

from dataloader import (
    load_series,
    standardize_by_train,
    make_windows,
    window_labels_from_point_labels,
    windows_to_point_scores,
    build_window_loader,
)
from detector import (
    extract_embeddings,
    knn_scores,
    train_knn_scores_leave_one_out,
    tfrc_scores,
    train_tfrc_scores,
)
from metrics import (
    best_f1_threshold,
    quantile_threshold,
    binary_metrics,
    auroc_auprc,
    normalize_scores,
    ts2vec_adjust_scores,
    ts2vec_threshold,
    ts2vec_eval_from_pred,
    infer_default_delay,
)


def log_print(msg, log_file=None):
    print(msg)
    if log_file is not None:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(str(msg) + "\n")


def get_setting(args, prefix):
    return f"{prefix}_{args.dataset_name}_ws{args.window_size}_st{args.window_stride}_seed{args.seed}"


def build_model_args(args):
    # The existing forecasting Model expects these fields.
    args.seq_len = args.window_size
    args.label_len = 0
    args.pred_len = args.window_size
    args.dec_in = args.enc_in
    args.features = "M"
    args.data = args.dataset_name
    args.model = "IRTC"
    args.use_revin = getattr(args, "use_revin", False)

    # In the existing Model, patch stride is usually named `stride`.
    args.stride = args.patch_stride
    return args


def load_checkpoint_to_model(model, ckpt_path, device):
    if not ckpt_path:
        return

    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"checkpoint not found: {ckpt_path}")

    ckpt = torch.load(ckpt_path, map_location=device)
    if isinstance(ckpt, dict):
        if "model_state" in ckpt and isinstance(ckpt["model_state"], dict):
            state = ckpt["model_state"]
        elif "model_state_dict" in ckpt and isinstance(ckpt["model_state_dict"], dict):
            state = ckpt["model_state_dict"]
        elif "state_dict" in ckpt and isinstance(ckpt["state_dict"], dict):
            state = ckpt["state_dict"]
        elif "model" in ckpt and isinstance(ckpt["model"], dict):
            state = ckpt["model"]
        else:
            state = ckpt
    else:
        raise ValueError(f"unsupported checkpoint type: {type(ckpt)}")

    current = model.state_dict()
    filtered = {}
    skipped = []
    skip_keywords = ["forecast_head", "classifier", "prediction_head", "output_projection"]

    for k, v in state.items():
        kk = k.replace("module.", "")
        if not torch.is_tensor(v):
            skipped.append((kk, type(v).__name__, "non-tensor"))
            continue
        if any(s in kk for s in skip_keywords):
            skipped.append((kk, tuple(v.shape), "task-specific head"))
            continue
        if kk in current and current[kk].shape == v.shape:
            filtered[kk] = v
        else:
            if kk in current:
                skipped.append((kk, tuple(v.shape), tuple(current[kk].shape)))
            else:
                skipped.append((kk, tuple(v.shape), "not in model"))

    missing, unexpected = model.load_state_dict(filtered, strict=False)
    print(f"Loaded compatible parameters: {len(filtered)}")
    print(f"Skipped parameters: {len(skipped)}")
    if skipped:
        print("First skipped:", skipped[:8])
    print(f"Missing keys: {len(missing)} | Unexpected keys: {len(unexpected)}")


def prepare_data(args):
    train = load_series(args.dataset_root, "train")
    test = load_series(args.dataset_root, "test")
    test_label = load_series(args.dataset_root, "test_label")

    train, test, mean, std = standardize_by_train(train, test)
    train_windows, train_starts = make_windows(train, args.window_size, args.window_stride)
    test_windows, test_starts = make_windows(test, args.window_size, args.window_stride)
    window_labels = window_labels_from_point_labels(test_label, test_starts, args.window_size)

    return {
        "train": train,
        "test": test,
        "test_label": test_label,
        "train_windows": train_windows,
        "train_starts": train_starts,
        "test_windows": test_windows,
        "test_starts": test_starts,
        "window_labels": window_labels,
    }


def graph_weight(args, epoch):
    warm = int(max(0, args.train_epochs * args.warmup_ratio))
    if warm <= 0:
        return 1.0
    if epoch <= warm:
        return 0.0
    return min(1.0, (epoch - warm) / max(1, warm))


def pretrain(args):
    args = build_model_args(args)
    set_seed(args.seed)
    torch.set_num_threads(args.num_threads)

    device = torch.device(f"cuda:{args.gpu}" if args.use_gpu and torch.cuda.is_available() else "cpu")
    data = prepare_data(args)
    train_loader = build_window_loader(data["train_windows"], args.batch_size, shuffle=True, num_workers=args.num_workers,drop_last=True)

    model = Model(args).to(device)
    criterion = IRTCLoss(
        lambda_tic=args.lambda_tic,
        lambda_trgc=args.lambda_trgc,
        lambda_frgc=args.lambda_frgc,
        lambda_tfrc=args.lambda_tfrc,
        tau_t=args.tau_t,
        tau_f=args.tau_f,
        topk=args.graph_topk,
    )
    opt = AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)

    setting = get_setting(args, "pretrain")
    ckpt_dir = Path(args.checkpoints) / setting
    mkdir(ckpt_dir)
    log_file = ckpt_dir / "log.txt"

    time_w = TimeAugmentor(weak=True)
    time_s = TimeAugmentor(weak=False)
    freq_w = FreqAugmentor(weak=True)
    freq_s = FreqAugmentor(weak=False)

    best = float("inf")
    log_print(f"Pretraining setting: {setting}", log_file)
    log_print(f"train windows: {len(data['train_windows'])}", log_file)

    for epoch in range(1, args.train_epochs + 1):
        model.train()
        meter = {"total": [], "tic": [], "trgc": [], "frgc": [], "tfrc": []}
        t0 = time.time()
        gw = graph_weight(args, epoch)

        for seq_x, _ in train_loader:
            x = ensure_bct(seq_x.float()).to(device)
            z_tw = model.encode_projected(time_w(x))
            z_ts = model.encode_projected(time_s(x))
            z_fw = model.encode_projected(freq_w(x))
            z_fs = model.encode_projected(freq_s(x))

            losses = criterion(model.encoder_model, z_tw, z_ts, z_fw, z_fs, graph_weight=gw)
            loss = losses["total"]

            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), args.clip_grad)
            opt.step()

            for k in meter:
                meter[k].append(float(losses[k].detach().cpu()))

        total = float(np.mean(meter["total"]))
        line = " | ".join([f"{k}={np.mean(v):.5f}" for k, v in meter.items()])
        log_print(f"Pretrain Epoch {epoch:03d}/{args.train_epochs} | {line} | graph_w={gw:.2f} | {time.time()-t0:.1f}s", log_file)

        save_checkpoint(str(ckpt_dir / "last.pth"), epoch=epoch, model_state=model.state_dict(), args=vars(args), pretrain_loss=total)
        if total < best:
            best = total
            save_checkpoint(str(ckpt_dir / "best.pth"), epoch=epoch, model_state=model.state_dict(), args=vars(args), pretrain_loss=best)

    log_print(f"Best pretrain loss={best:.6f}", log_file)
    return str(ckpt_dir / "best.pth")


def detect(args):
    args = build_model_args(args)
    set_seed(args.seed)
    torch.set_num_threads(args.num_threads)

    device = torch.device(f"cuda:{args.gpu}" if args.use_gpu and torch.cuda.is_available() else "cpu")
    data = prepare_data(args)

    train_loader = build_window_loader(data["train_windows"], args.batch_size, shuffle=False, num_workers=args.num_workers)
    test_loader = build_window_loader(data["test_windows"], args.batch_size, shuffle=False, num_workers=args.num_workers)

    setting = get_setting(args, "detect")
    ckpt_dir = Path(args.checkpoints) / setting
    mkdir(ckpt_dir)
    log_file = ckpt_dir / "log.txt"

    model = Model(args).to(device)
    load_checkpoint_to_model(model, args.transfer_checkpoints, device)
    model.eval()

    log_print(f"Detection setting: {setting}", log_file)
    log_print(f"train windows: {len(data['train_windows'])} | test windows: {len(data['test_windows'])}", log_file)

    train_time_z = extract_embeddings(model, train_loader, device, use_freq=False).to(device)
    test_time_z = extract_embeddings(model, test_loader, device, use_freq=False).to(device)

    scores = {}

    if args.score_method in ["knn", "fusion"]:
        scores["train_knn"] = train_knn_scores_leave_one_out(train_time_z, k=args.knn_k, chunk_size=args.score_chunk_size)
        scores["knn"] = knn_scores(train_time_z, test_time_z, k=args.knn_k, chunk_size=args.score_chunk_size)

    if args.score_method in ["tfrc", "fusion"]:
        train_freq_z = extract_embeddings(model, train_loader, device, use_freq=True).to(device)
        test_freq_z = extract_embeddings(model, test_loader, device, use_freq=True).to(device)
        scores["train_tfrc"] = train_tfrc_scores(train_time_z, train_freq_z, tau=args.tau_f, chunk_size=args.score_chunk_size)
        scores["tfrc"] = tfrc_scores(train_time_z, train_freq_z, test_time_z, test_freq_z, tau=args.tau_f, chunk_size=args.score_chunk_size)

    if args.score_method == "knn":
        final_window_scores = scores["knn"]
        train_ref_scores = scores["train_knn"]
    elif args.score_method == "tfrc":
        final_window_scores = scores["tfrc"]
        train_ref_scores = scores["train_tfrc"]
    elif args.score_method == "fusion":
        knn_norm = normalize_scores(scores["knn"], scores["train_knn"])
        tfrc_norm = normalize_scores(scores["tfrc"], scores["train_tfrc"])
        final_window_scores = args.score_alpha * knn_norm + (1.0 - args.score_alpha) * tfrc_norm
        train_ref_scores = (
            args.score_alpha * normalize_scores(scores["train_knn"], scores["train_knn"])
            + (1.0 - args.score_alpha) * normalize_scores(scores["train_tfrc"], scores["train_tfrc"])
        )
    else:
        raise ValueError(f"Unknown score_method: {args.score_method}")

    point_scores = windows_to_point_scores(
        final_window_scores,
        data["test_starts"],
        total_len=len(data["test_label"]),
        window_size=args.window_size,
        mode=args.point_score_mode,
    )

    train_point_scores = windows_to_point_scores(
        train_ref_scores,
        data["train_starts"],
        total_len=len(data["train"]),
        window_size=args.window_size,
        mode=args.point_score_mode,
    )

    delay = args.eval_delay if args.eval_delay >= 0 else infer_default_delay(args.dataset_name)

    # ------------------------------------------------------------------
    # Threshold selection and strict point-level metrics
    # ------------------------------------------------------------------
    # Important:
    #   threshold_method controls only how binary predictions are produced.
    #   eval_adjustment controls how those predictions are evaluated.
    # This separation allows using the effective KNN/Fusion scores with
    # best_f1/quantile thresholds while also reporting TS2Vec/SoftCLT-style
    # delay-adjusted point-level metrics.
    if args.threshold_method == "best_f1":
        # Debug / upper-bound protocol: uses test labels to search the best threshold.
        point_metrics = best_f1_threshold(point_scores, data["test_label"])
        window_metrics = best_f1_threshold(final_window_scores, data["window_labels"])
        threshold = point_metrics["threshold"]
        point_pred = (point_scores >= threshold).astype(int)
        score_for_auc = point_scores

    elif args.threshold_method == "quantile":
        # Label-free protocol: threshold from train scores quantile.
        threshold = quantile_threshold(train_point_scores, q=args.threshold_quantile)
        point_pred = (point_scores >= threshold).astype(int)
        window_threshold = quantile_threshold(train_ref_scores, q=args.threshold_quantile)
        window_pred = (final_window_scores >= window_threshold).astype(int)
        point_metrics = binary_metrics(data["test_label"], point_pred)
        window_metrics = binary_metrics(data["window_labels"], window_pred)
        point_metrics["threshold"] = float(threshold)
        window_metrics["threshold"] = float(window_threshold)
        score_for_auc = point_scores

    elif args.threshold_method == "ts2vec":
        # Full TS2Vec-style thresholding. This is mainly suitable for TS2Vec-like
        # masked-representation error scores. It may be poorly calibrated for
        # KNN distances, so for IRTC-KNN/Fusion we usually prefer:
        #   --threshold_method best_f1 --eval_adjustment delay
        train_adj, test_adj = ts2vec_adjust_scores(
            train_point_scores,
            point_scores,
            ma_window=args.ts2vec_ma_window,
            skip=args.ts2vec_skip,
        )
        threshold = ts2vec_threshold(train_adj, sigma=args.ts2vec_sigma)
        point_pred = (test_adj >= threshold).astype(int)
        point_metrics = binary_metrics(data["test_label"], point_pred)
        point_metrics["threshold"] = float(threshold)
        window_metrics = best_f1_threshold(final_window_scores, data["window_labels"])
        score_for_auc = test_adj
        point_scores = test_adj

    else:
        raise ValueError(f"Unknown threshold_method: {args.threshold_method}")

    point_metrics.update(auroc_auprc(score_for_auc, data["test_label"]))
    window_metrics.update(auroc_auprc(final_window_scores, data["window_labels"]))

    # ------------------------------------------------------------------
    # Optional evaluation adjustment
    # ------------------------------------------------------------------
    # eval_adjustment=none:
    #   strict point-level metrics; no post-adjustment.
    # eval_adjustment=delay:
    #   TS2Vec/SoftCLT-style delay/range adjustment is applied to the binary
    #   predictions produced by the selected threshold method. This keeps your
    #   current effective scores and thresholding while adding delay-tolerant
    #   evaluation for fair comparison with TS2Vec-style AD protocols.
    if args.eval_adjustment == "delay":
        point_metrics_delay_adjusted = ts2vec_eval_from_pred(
            point_pred,
            data["test_label"],
            delay=delay,
        )
        point_metrics_delay_adjusted["threshold"] = float(threshold)
        point_metrics_delay_adjusted["delay"] = int(delay)
        point_metrics_delay_adjusted["adjustment"] = "delay"
    elif args.eval_adjustment == "none":
        point_metrics_delay_adjusted = None
    else:
        raise ValueError(f"Unknown eval_adjustment: {args.eval_adjustment}")

    result = {
        "dataset": args.dataset_name,
        "score_method": args.score_method,
        "threshold_method": args.threshold_method,
        "eval_adjustment": args.eval_adjustment,
        "threshold": float(threshold),
        "point_metrics": point_metrics,
        "point_metrics_delay_adjusted": point_metrics_delay_adjusted,
        # Backward-compatible alias. Use this only when eval_adjustment='delay'.
        "point_metrics_ts2vec_protocol": point_metrics_delay_adjusted,
        "window_metrics": window_metrics,
        "args": vars(args),
    }

    np.save(ckpt_dir / "window_scores.npy", final_window_scores)
    np.save(ckpt_dir / "point_scores.npy", point_scores)
    np.save(ckpt_dir / "train_point_scores.npy", train_point_scores)
    with open(ckpt_dir / "result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    log_print(json.dumps(result, indent=2, ensure_ascii=False), log_file)
    log_print(f"Saved results to: {ckpt_dir}", log_file)
    return result


def parse_args():
    p = argparse.ArgumentParser("IRTC anomaly detection")

    p.add_argument("--mode", type=str, default="all", choices=["pretrain", "detect", "all"])
    p.add_argument("--dataset_name", type=str, required=True)
    p.add_argument("--dataset_root", type=str, required=True)
    p.add_argument("--checkpoints", type=str, default="../checkpoints")
    p.add_argument("--transfer_checkpoints", type=str, default="")

    p.add_argument("--window_size", type=int, default=100)
    p.add_argument("--window_stride", type=int, default=5)
    p.add_argument("--enc_in", type=int, default=1)
    p.add_argument("--c_out", type=int, default=1)

    p.add_argument("--encoder", type=str, default="transformer", choices=["transformer", "resnet", "tcn"])
    p.add_argument("--d_model", type=int, default=128)
    p.add_argument("--d_ff", type=int, default=256)
    p.add_argument("--e_layers", type=int, default=3)
    p.add_argument("--n_heads", type=int, default=4)
    p.add_argument("--patch_len", type=int, default=16)
    p.add_argument("--patch_stride", type=int, default=8)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--use_revin", action="store_true")

    p.add_argument("--train_epochs", type=int, default=100)
    p.add_argument("--batch_size", type=int, default=64)
    p.add_argument("--learning_rate", type=float, default=1e-4)
    p.add_argument("--weight_decay", type=float, default=1e-4)
    p.add_argument("--clip_grad", type=float, default=5.0)
    p.add_argument("--num_workers", type=int, default=0)
    p.add_argument("--num_threads", type=int, default=4)
    p.add_argument("--seed", type=int, default=42)

    p.add_argument("--lambda_tic", type=float, default=1.0)
    p.add_argument("--lambda_trgc", type=float, default=0.2)
    p.add_argument("--lambda_frgc", type=float, default=0.2)
    p.add_argument("--lambda_tfrc", type=float, default=0.1)
    p.add_argument("--tau_t", type=float, default=0.2)
    p.add_argument("--tau_f", type=float, default=0.2)
    p.add_argument("--graph_topk", type=int, default=0)
    p.add_argument("--warmup_ratio", type=float, default=0.1)

    p.add_argument("--score_method", type=str, default="fusion", choices=["knn", "tfrc", "fusion"])
    p.add_argument("--knn_k", type=int, default=5)
    p.add_argument("--score_alpha", type=float, default=0.5)
    p.add_argument("--score_chunk_size", type=int, default=1024)
    p.add_argument(
        "--point_score_mode",
        type=str,
        default="mean",
        choices=["mean", "max", "center"],
        help="How to convert window-level scores to point-level scores. "
             "mean/max spread scores to all covered points; center assigns each "
             "window score to its center point and interpolates, reducing false positives."
    )
    p.add_argument("--threshold_method", type=str, default="best_f1", choices=["best_f1", "quantile", "ts2vec"])
    p.add_argument("--threshold_quantile", type=float, default=0.995)
    p.add_argument(
        "--eval_adjustment",
        type=str,
        default="none",
        choices=["none", "delay"],
        help="Evaluation post-adjustment. Use 'delay' to apply TS2Vec/SoftCLT-style "
             "range-probability delay adjustment to the binary predictions generated "
             "by threshold_method. This is independent of threshold selection."
    )
    p.add_argument("--eval_delay", type=int, default=-1,
                   help="Delay used by TS2Vec/SoftCLT range-probability evaluation. "
                        "Default -1 means KPI=7, Yahoo=3, otherwise 7.")
    p.add_argument("--ts2vec_ma_window", type=int, default=21,
                   help="Moving average window used for TS2Vec-style score adjustment.")
    p.add_argument("--ts2vec_skip", type=int, default=22,
                   help="Number of initial adjusted train points skipped before thresholding, following TS2Vec.")
    p.add_argument("--ts2vec_sigma", type=float, default=4.0,
                   help="Threshold multiplier: mean(train_adj) + sigma * std(train_adj).")

    p.add_argument("--use_gpu", action="store_true")
    p.add_argument("--gpu", type=int, default=0)

    return p.parse_args()


def main():
    args = parse_args()
    if args.mode == "pretrain":
        pretrain(args)
    elif args.mode == "detect":
        detect(args)
    elif args.mode == "all":
        ckpt = pretrain(args)
        args.transfer_checkpoints = ckpt
        detect(args)


if __name__ == "__main__":
    main()
