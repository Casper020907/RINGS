"""
Dataloader for IRTC_Anomaly.

This file is designed to replace:
    /root/IRTC_SimMTM_style/IRTC_Anomaly/code/dataloader.py

Supported formats:
1) Original IRTC anomaly format:
    dataset_root/train.npy, test.npy, test_label.npy
    or .csv/.txt equivalents.

2) KPI raw format, TS2Vec-style source files:
    dataset_root/phase2_train.csv
    dataset_root/phase2_ground_truth.hdf

3) Yahoo S5 official raw format:
    dataset_root/A1Benchmark/*.csv
    dataset_root/A2Benchmark/*.csv
    dataset_root/A3Benchmark/*.csv
    dataset_root/A4Benchmark/*.csv

4) TS2Vec processed pkl format:
    dataset_root/kpi.pkl or dataset_root/yahoo.pkl
    or dataset_root itself is a .pkl file.

Selecting a KPI series:
    export KPI_SERIES_KEY="your_kpi_id"
    or export KPI_SERIES_INDEX=0

Selecting a Yahoo series:
    export YAHOO_SERIES_KEY="A1Benchmark/real_1.csv"
    or export YAHOO_SERIES_INDEX=0

By default, the first available series is used.
"""

import os
import pickle
import warnings
from functools import lru_cache

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader


def _load_csv(path):
    """Load a generic numeric csv/txt file for the simple train/test/test_label format."""
    try:
        arr = np.loadtxt(path, delimiter=",", skiprows=1)
    except Exception:
        arr = np.loadtxt(path, delimiter=",")
    if arr.ndim == 1:
        arr = arr[:, None]
    return arr.astype(np.float32)


def _as_2d_float(arr):
    arr = np.asarray(arr, dtype=np.float32)
    if arr.ndim == 0:
        arr = arr.reshape(1, 1)
    elif arr.ndim == 1:
        arr = arr[:, None]
    return arr.astype(np.float32)


def _as_label(arr):
    arr = np.asarray(arr).reshape(-1)
    # Some labels may be bool/float; force binary int.
    return (arr > 0).astype(np.int64)


def _find_first_existing(root, names):
    for n in names:
        p = os.path.join(root, n)
        if os.path.exists(p):
            return p
    return None


def _simple_split_path(dataset_root, split):
    candidates = [
        os.path.join(dataset_root, f"{split}.npy"),
        os.path.join(dataset_root, f"{split}.csv"),
        os.path.join(dataset_root, f"{split}.txt"),
    ]
    return next((p for p in candidates if os.path.exists(p)), None)


def _load_simple_split(dataset_root, split):
    path = _simple_split_path(dataset_root, split)
    if path is None:
        raise FileNotFoundError(f"Missing {split}.npy/.csv/.txt in {dataset_root}")

    if path.endswith(".npy"):
        arr = np.load(path)
    elif path.endswith(".csv"):
        arr = _load_csv(path)
    else:
        arr = np.loadtxt(path)

    if split.endswith("label"):
        return _as_label(arr)
    return _as_2d_float(arr)


def _safe_col_lookup(columns, candidates, contains=None):
    lower_map = {str(c).strip().lower(): c for c in columns}
    for cand in candidates:
        if cand.lower() in lower_map:
            return lower_map[cand.lower()]
    if contains is not None:
        for c in columns:
            cl = str(c).strip().lower()
            if contains in cl:
                return c
    return None


def _normalize_kpi_df(df, source_name="kpi"):
    """Normalize KPI dataframe column names to: kpi_id, timestamp, value, label(optional)."""
    import pandas as pd  # Lazy import because only KPI raw needs pandas.

    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"{source_name} is not a DataFrame: {type(df)}")

    cols = list(df.columns)
    id_col = _safe_col_lookup(
        cols,
        candidates=["KPI ID", "kpi_id", "KPI_ID", "id", "ID", "metric", "metric_id"],
        contains="kpi",
    )
    ts_col = _safe_col_lookup(
        cols,
        candidates=["timestamp", "time", "ts", "datetime"],
        contains="time",
    )
    val_col = _safe_col_lookup(
        cols,
        candidates=["value", "values", "val", "metric_value"],
        contains="value",
    )
    label_col = _safe_col_lookup(
        cols,
        candidates=["label", "labels", "is_anomaly", "anomaly", "is_anomaly_label"],
        contains="label",
    )

    missing = []
    if id_col is None:
        missing.append("KPI ID / kpi_id")
    if ts_col is None:
        missing.append("timestamp")
    if val_col is None:
        missing.append("value")
    if missing:
        raise ValueError(
            f"Cannot identify columns {missing} from {source_name}. "
            f"Available columns: {cols}"
        )

    out = df[[id_col, ts_col, val_col] + ([label_col] if label_col is not None else [])].copy()
    rename = {id_col: "kpi_id", ts_col: "timestamp", val_col: "value"}
    if label_col is not None:
        rename[label_col] = "label"
    out = out.rename(columns=rename)

    # Drop NaNs and duplicate timestamps per KPI. TS2Vec-style preprocessing also removes duplicates.
    out = out.dropna(subset=["kpi_id", "timestamp", "value"])
    out = out.drop_duplicates(subset=["kpi_id", "timestamp"], keep="last")
    out = out.sort_values(["kpi_id", "timestamp"]).reset_index(drop=True)
    return out


def _read_hdf_robust(path):
    import pandas as pd
    try:
        return pd.read_hdf(path)
    except Exception:
        # Some HDF files have explicit keys. Try the first key.
        store = pd.HDFStore(path, mode="r")
        try:
            keys = store.keys()
            if not keys:
                raise ValueError(f"No keys found in HDF file: {path}")
            key = keys[0]
            return store[key]
        finally:
            store.close()


def _select_series_key(common_keys):
    common_keys = list(common_keys)
    if not common_keys:
        raise ValueError("No common KPI IDs between train and test.")

    key_env = os.environ.get("KPI_SERIES_KEY") or os.environ.get("IRTC_KPI_SERIES_KEY")
    if key_env is not None and key_env != "":
        # IDs may be strings or numbers; compare by string form.
        for k in common_keys:
            if str(k) == str(key_env):
                return k
        raise ValueError(
            f"KPI_SERIES_KEY={key_env} not found. First available keys: "
            f"{[str(k) for k in common_keys[:10]]}"
        )

    idx = int(os.environ.get("KPI_SERIES_INDEX", os.environ.get("IRTC_KPI_SERIES_INDEX", "0")))
    if idx < 0 or idx >= len(common_keys):
        raise IndexError(f"KPI_SERIES_INDEX={idx} out of range. num_series={len(common_keys)}")
    return common_keys[idx]


def _df_to_series(df, kpi_key, need_label=False):
    sub = df[df["kpi_id"].astype(str) == str(kpi_key)].sort_values("timestamp")
    if len(sub) == 0:
        # If dtype comparison by string failed due to numeric/string quirks, try raw comparison.
        sub = df[df["kpi_id"] == kpi_key].sort_values("timestamp")
    if len(sub) == 0:
        raise ValueError(f"No rows for KPI ID: {kpi_key}")

    values = sub["value"].to_numpy(dtype=np.float32)
    if need_label:
        if "label" not in sub.columns:
            raise ValueError("Test HDF/CSV does not contain a label column.")
        labels = _as_label(sub["label"].to_numpy())
        return values[:, None].astype(np.float32), labels
    return values[:, None].astype(np.float32)


@lru_cache(maxsize=8)
def _load_kpi_raw_cached(dataset_root):
    """Load KPI raw phase2 csv + hdf and return selected train/test/label."""
    import pandas as pd

    train_path = _find_first_existing(dataset_root, [
        "phase2_train.csv",
        "phase2.csv",
        "train.csv",
        "kpi_train.csv",
    ])
    test_path = _find_first_existing(dataset_root, [
        "phase2_ground_truth.hdf",
        "phase2_ground_truth.h5",
        "phase2_test.hdf",
        "phase2_test.h5",
        "ground_truth.hdf",
        "ground_truth.h5",
        "test.hdf",
        "test.h5",
    ])

    if train_path is None or test_path is None:
        raise FileNotFoundError(
            "KPI raw files not found. Expected phase2_train.csv/phase2.csv and "
            "phase2_ground_truth.hdf/.h5 under: " + dataset_root
        )

    print(f"[KPI dataloader] Reading train csv: {train_path}")
    train_df = pd.read_csv(train_path)
    print(f"[KPI dataloader] Reading test hdf: {test_path}")
    test_df = _read_hdf_robust(test_path)

    train_df = _normalize_kpi_df(train_df, train_path)
    test_df = _normalize_kpi_df(test_df, test_path)

    train_keys = list(train_df["kpi_id"].drop_duplicates())
    test_keys = list(test_df["kpi_id"].drop_duplicates())
    common_keys = [k for k in train_keys if str(k) in set(map(str, test_keys))]
    if not common_keys:
        # fallback: intersection preserving string forms
        train_str = {str(k): k for k in train_keys}
        test_str = {str(k): k for k in test_keys}
        common_str = [s for s in train_str if s in test_str]
        common_keys = [train_str[s] for s in common_str]

    key = _select_series_key(common_keys)
    print(f"[KPI dataloader] num_series={len(common_keys)} | using KPI ID={key}")

    train = _df_to_series(train_df, key, need_label=False)
    test, label = _df_to_series(test_df, key, need_label=True)

    # Optional: filter anomalous points from training if a train label column exists.
    # Default is OFF because deleting points breaks temporal continuity.
    filter_train = os.environ.get("KPI_FILTER_TRAIN_ANOMALIES", "0") == "1"
    if filter_train and "label" in train_df.columns:
        sub = train_df[train_df["kpi_id"].astype(str) == str(key)].sort_values("timestamp")
        train_label = _as_label(sub["label"].to_numpy())
        keep = train_label == 0
        if keep.sum() >= 10:
            train = train[keep]
            print(f"[KPI dataloader] filtered train anomalies: kept {keep.sum()}/{len(keep)} points")
        else:
            warnings.warn("KPI_FILTER_TRAIN_ANOMALIES=1 but too few normal points remain; not filtering.")

    print(
        f"[KPI dataloader] train={train.shape}, test={test.shape}, "
        f"label={label.shape}, anomaly_ratio={label.mean():.4f}"
    )
    return train.astype(np.float32), test.astype(np.float32), label.astype(np.int64)




def _safe_yahoo_col_lookup(columns, candidates, contains=None):
    lower_map = {str(c).strip().lower(): c for c in columns}
    for cand in candidates:
        if cand.lower() in lower_map:
            return lower_map[cand.lower()]
    if contains is not None:
        for c in columns:
            cl = str(c).strip().lower()
            if contains in cl:
                return c
    return None


def _is_valid_yahoo_series_csv(path):
    """
    Return True only for one standard Yahoo S5 single-series csv file.

    Some Yahoo downloads contain aggregate wide-table csv files such as:
        A4Benchmark/A4Benchmark_all.csv

    These files contain many columns like A4Benchmark-TS1 ... A4Benchmark-TS100
    and do not contain an anomaly label column. They are NOT one labeled time
    series and must be excluded from the anomaly benchmark file list.
    """
    fn = os.path.basename(path)
    name = fn.lower()

    # Skip hidden/temp files.
    if name.startswith(".") or name.startswith("~"):
        return False

    # Skip aggregate Yahoo wide-table files.
    if name.endswith("_all.csv"):
        return False
    if "benchmark_all" in name or name in {"all.csv", "benchmark_all.csv"}:
        return False

    return name.endswith(".csv")


def _list_yahoo_csv_files(dataset_root):
    """
    Return sorted valid Yahoo S5 single-series csv files under A1Benchmark-A4Benchmark.

    Official Yahoo S5 style:
        A1Benchmark/*.csv
        A2Benchmark/*.csv
        A3Benchmark/*.csv
        A4Benchmark/*.csv

    Notes
    -----
    Some downloaded folders contain aggregate files such as A4Benchmark_all.csv.
    Those are wide tables without anomaly labels and must be excluded; otherwise
    the dataloader will fail while trying to identify a label column.
    """
    if not os.path.isdir(dataset_root):
        return []

    roots = []
    for name in ["A1Benchmark", "A2Benchmark", "A3Benchmark", "A4Benchmark"]:
        p = os.path.join(dataset_root, name)
        if os.path.isdir(p):
            roots.append(p)

    # Fallback: any directory ending with Benchmark.
    if not roots:
        for name in sorted(os.listdir(dataset_root)):
            p = os.path.join(dataset_root, name)
            if os.path.isdir(p) and name.lower().endswith("benchmark"):
                roots.append(p)

    files = []
    skipped = []
    for r in roots:
        for dirpath, _, filenames in os.walk(r):
            for fn in filenames:
                if not fn.lower().endswith(".csv"):
                    continue
                p = os.path.join(dirpath, fn)
                if _is_valid_yahoo_series_csv(p):
                    files.append(p)
                else:
                    skipped.append(p)

    files = sorted(files, key=lambda p: os.path.relpath(p, dataset_root).replace(os.sep, "/"))

    if skipped:
        skipped_rel = [os.path.relpath(p, dataset_root).replace(os.sep, "/") for p in sorted(skipped)]
        print(f"[Yahoo dataloader] skipped non-series csv files: {skipped_rel}")

    return files

def list_yahoo_series(dataset_root):
    """Public helper used by run_all_yahoo.py."""
    files = _list_yahoo_csv_files(dataset_root)
    return [os.path.relpath(p, dataset_root).replace(os.sep, "/") for p in files]


def _is_yahoo_raw_dir(dataset_root):
    return len(_list_yahoo_csv_files(dataset_root)) > 0


def _select_yahoo_file(dataset_root):
    files = _list_yahoo_csv_files(dataset_root)
    if not files:
        raise FileNotFoundError(
            f"No Yahoo csv files found under {dataset_root}. Expected A1Benchmark-A4Benchmark/*.csv"
        )

    key_env = os.environ.get("YAHOO_SERIES_KEY") or os.environ.get("IRTC_YAHOO_SERIES_KEY")
    if key_env:
        norm_key = str(key_env).replace("\\", "/").strip()
        for f in files:
            rel = os.path.relpath(f, dataset_root).replace(os.sep, "/")
            if rel == norm_key or os.path.basename(f) == norm_key:
                return f
        raise ValueError(
            f"YAHOO_SERIES_KEY={key_env!r} not found. First available series: "
            f"{[os.path.relpath(x, dataset_root).replace(os.sep, '/') for x in files[:10]]}"
        )

    idx = int(os.environ.get("YAHOO_SERIES_INDEX", os.environ.get("IRTC_YAHOO_SERIES_INDEX", "0")))
    if idx < 0 or idx >= len(files):
        raise IndexError(f"YAHOO_SERIES_INDEX={idx} out of range. num_series={len(files)}")
    return files[idx]


def _read_yahoo_csv(path):
    import pandas as pd
    df = pd.read_csv(path)
    cols = list(df.columns)

    value_col = _safe_yahoo_col_lookup(
        cols,
        candidates=["value", "values", "val", "y"],
        contains="value",
    )
    label_col = _safe_yahoo_col_lookup(
        cols,
        candidates=["is_anomaly", "anomaly", "label", "labels"],
        contains="anomaly",
    )

    if value_col is None:
        # Fallback: choose first numeric non-time column.
        numeric_cols = [c for c in cols if np.issubdtype(df[c].dtype, np.number)]
        non_time = [c for c in numeric_cols if "time" not in str(c).lower() and str(c).lower() not in {"timestamp"}]
        if label_col in non_time:
            non_time.remove(label_col)
        if not non_time:
            raise ValueError(f"Cannot identify value column from Yahoo file {path}. Columns={cols}")
        value_col = non_time[0]

    if label_col is None:
        raise ValueError(
            f"Cannot identify anomaly label column from Yahoo file {path}. "
            f"Expected is_anomaly/anomaly/label. Columns={cols}"
        )

    values = df[value_col].to_numpy(dtype=np.float32)
    labels = _as_label(df[label_col].to_numpy())

    # Drop NaNs consistently.
    mask = np.isfinite(values)
    if mask.sum() < len(values):
        values = values[mask]
        labels = labels[mask]

    return values[:, None].astype(np.float32), labels.astype(np.int64)


@lru_cache(maxsize=16)
def _load_yahoo_raw_cached(dataset_root):
    """
    Load one Yahoo S5 time series and split it TS2Vec-style.

    TS2Vec-style Yahoo preprocessing treats each csv as one series and uses the first half
    as train and the second half as test. Labels are used for the test half.
    """
    selected = _select_yahoo_file(dataset_root)
    rel = os.path.relpath(selected, dataset_root).replace(os.sep, "/")
    files = _list_yahoo_csv_files(dataset_root)
    idx = files.index(selected)
    print(f"[Yahoo dataloader] num_series={len(files)} | using index={idx} | file={rel}")

    values, labels = _read_yahoo_csv(selected)
    n = len(values)
    if n < 20:
        raise ValueError(f"Yahoo series too short: {rel}, length={n}")

    split = n // 2
    train = values[:split]
    test = values[split:]
    test_label = labels[split:]

    print(
        f"[Yahoo dataloader] train={train.shape}, test={test.shape}, "
        f"label={test_label.shape}, anomaly_ratio={test_label.mean():.4f}"
    )
    return train.astype(np.float32), test.astype(np.float32), test_label.astype(np.int64)


def _find_pkl(dataset_root):
    if os.path.isfile(dataset_root) and dataset_root.endswith(".pkl"):
        return dataset_root
    if os.path.isdir(dataset_root):
        for name in ["kpi.pkl", "KPI.pkl", "yahoo.pkl", "Yahoo.pkl"]:
            p = os.path.join(dataset_root, name)
            if os.path.exists(p):
                return p
    return None


@lru_cache(maxsize=8)
def _load_ts2vec_pkl_cached(pkl_path):
    with open(pkl_path, "rb") as f:
        obj = pickle.load(f)

    if not isinstance(obj, dict):
        raise ValueError(f"Unsupported pkl type: {type(obj)}")

    # TS2Vec KPI/Yahoo style.
    required = ["all_train_data", "all_test_data", "all_test_labels"]
    if not all(k in obj for k in required):
        raise ValueError(f"Unsupported pkl keys: {obj.keys()}")

    train_data = obj["all_train_data"]
    test_data = obj["all_test_data"]
    test_labels = obj["all_test_labels"]

    if isinstance(train_data, dict):
        keys = list(train_data.keys())
        key = _select_series_key(keys)
        train = train_data[key]
        test = test_data[key]
        label = test_labels[key]
        print(f"[PKL dataloader] loaded {os.path.basename(pkl_path)} | num_series={len(keys)} | using key={key}")
    else:
        n = len(train_data)
        idx = int(os.environ.get("KPI_SERIES_INDEX", os.environ.get("IRTC_KPI_SERIES_INDEX", "0")))
        if idx < 0 or idx >= n:
            raise IndexError(f"series index={idx} out of range. num_series={n}")
        train = train_data[idx]
        test = test_data[idx]
        label = test_labels[idx]
        print(f"[PKL dataloader] loaded {os.path.basename(pkl_path)} | num_series={n} | using index={idx}")

    train = _as_2d_float(train)
    test = _as_2d_float(test)
    label = _as_label(label)
    print(f"[PKL dataloader] train={train.shape}, test={test.shape}, label={label.shape}, anomaly_ratio={label.mean():.4f}")
    return train, test, label


def _is_kpi_raw_dir(dataset_root):
    if not os.path.isdir(dataset_root):
        return False
    train_path = _find_first_existing(dataset_root, ["phase2_train.csv", "phase2.csv", "train.csv", "kpi_train.csv"])
    test_path = _find_first_existing(dataset_root, [
        "phase2_ground_truth.hdf", "phase2_ground_truth.h5", "phase2_test.hdf", "phase2_test.h5",
        "ground_truth.hdf", "ground_truth.h5", "test.hdf", "test.h5"
    ])
    return train_path is not None and test_path is not None


def list_kpi_series(dataset_root):
    """Public helper used by joint/all-KPI runners.

    Returns KPI IDs that are present in both train and test raw files.
    For TS2Vec-style pkl, returns its train-data keys when possible.
    """
    pkl_path = _find_pkl(dataset_root)
    if pkl_path is not None:
        with open(pkl_path, "rb") as f:
            obj = pickle.load(f)
        train_data = obj.get("all_train_data")
        if isinstance(train_data, dict):
            return [str(k) for k in train_data.keys()]
        return [str(i) for i in range(len(train_data))]

    if not _is_kpi_raw_dir(dataset_root):
        return []

    train_path = _find_first_existing(dataset_root, ["phase2_train.csv", "phase2.csv", "train.csv", "kpi_train.csv"])
    test_path = _find_first_existing(dataset_root, [
        "phase2_ground_truth.hdf", "phase2_ground_truth.h5", "phase2_test.hdf", "phase2_test.h5",
        "ground_truth.hdf", "ground_truth.h5", "test.hdf", "test.h5"
    ])
    import pandas as pd
    train_df = _normalize_kpi_df(pd.read_csv(train_path), source_name=train_path)
    test_df = _normalize_kpi_df(_read_hdf_robust(test_path), source_name=test_path)
    train_keys = set(str(x) for x in train_df["kpi_id"].unique())
    test_keys = set(str(x) for x in test_df["kpi_id"].unique())
    return sorted(train_keys & test_keys)


def load_series(dataset_root, split):
    """
    Main API used by IRTC_Anomaly/main.py.

    split: train / test / test_label

    Priority:
    1. simple train.npy/test.npy/test_label.npy format
    2. TS2Vec-style pkl, e.g. kpi.pkl/yahoo.pkl
    3. Yahoo raw A1-A4 Benchmark csv folders
    4. KPI raw files: phase2_train.csv + phase2_ground_truth.hdf
    """
    # 1) Original simple format has highest priority.
    if os.path.isdir(dataset_root) and _simple_split_path(dataset_root, split) is not None:
        return _load_simple_split(dataset_root, split)

    # 2) Processed pkl format.
    pkl_path = _find_pkl(dataset_root)
    if pkl_path is not None:
        train, test, label = _load_ts2vec_pkl_cached(os.path.abspath(pkl_path))
        if split == "train":
            return train
        if split == "test":
            return test
        if split == "test_label":
            return label
        raise ValueError(f"Unsupported split: {split}")

    # 3) Yahoo raw A1-A4 benchmark folders.
    if _is_yahoo_raw_dir(dataset_root):
        train, test, label = _load_yahoo_raw_cached(os.path.abspath(dataset_root))
        if split == "train":
            return train
        if split == "test":
            return test
        if split == "test_label":
            return label
        raise ValueError(f"Unsupported split: {split}")

    # 4) KPI raw phase2 csv + hdf.
    if _is_kpi_raw_dir(dataset_root):
        train, test, label = _load_kpi_raw_cached(os.path.abspath(dataset_root))
        if split == "train":
            return train
        if split == "test":
            return test
        if split == "test_label":
            return label
        raise ValueError(f"Unsupported split: {split}")

    raise FileNotFoundError(
        f"Cannot load dataset from {dataset_root}. Expected either:\n"
        f"  train.npy/test.npy/test_label.npy, or\n"
        f"  kpi.pkl/yahoo.pkl, or\n"
        f"  Yahoo raw A1-A4 Benchmark folders, or\n"
        f"  KPI raw phase2_train.csv + phase2_ground_truth.hdf"
    )


def standardize_by_train(train, test, eps=1e-6):
    train = _as_2d_float(train)
    test = _as_2d_float(test)
    mean = train.mean(axis=0, keepdims=True)
    std = train.std(axis=0, keepdims=True)
    std = np.where(std < eps, 1.0, std)
    return (train - mean) / std, (test - mean) / std, mean, std


def make_windows(series, window_size, stride):
    """
    series: [T, C]
    return: windows [N, window_size, C], starts [N]
    """
    series = _as_2d_float(series)
    T = len(series)
    if T < window_size:
        raise ValueError(f"series length {T} < window_size {window_size}")
    xs, starts = [], []
    for s in range(0, T - window_size + 1, stride):
        xs.append(series[s:s + window_size])
        starts.append(s)
    return np.stack(xs, axis=0).astype(np.float32), np.asarray(starts, dtype=np.int64)


def window_labels_from_point_labels(labels, starts, window_size):
    labels = _as_label(labels)
    ys = []
    for s in starts:
        ys.append(int(labels[s:s + window_size].max() > 0))
    return np.asarray(ys, dtype=np.int64)


def windows_to_point_scores(window_scores, starts, total_len, window_size, mode="mean"):
    window_scores = np.asarray(window_scores).reshape(-1)
    starts = np.asarray(starts).reshape(-1)

    if mode == "max":
        point_scores = np.zeros(total_len, dtype=np.float64)
        for sc, s in zip(window_scores, starts):
            point_scores[s:s + window_size] = np.maximum(point_scores[s:s + window_size], sc)
        return point_scores.astype(np.float32)

    if mode == "center":
        centers, values = [], []
        for sc, s in zip(window_scores, starts):
            c = int(s) + int(window_size) // 2
            if 0 <= c < total_len:
                centers.append(c)
                values.append(float(sc))
        if not centers:
            return np.zeros(total_len, dtype=np.float32)
        centers = np.asarray(centers, dtype=np.int64)
        values = np.asarray(values, dtype=np.float64)
        x = np.arange(total_len)
        return np.interp(x, centers, values, left=values[0], right=values[-1]).astype(np.float32)

    if mode == "last":
        # TS2Vec-style causal alignment: assign each window score to the last
        # timestamp covered by the window, then interpolate to all points.
        idx, values = [], []
        for sc, s in zip(window_scores, starts):
            t = int(s) + int(window_size) - 1
            if 0 <= t < total_len:
                idx.append(t)
                values.append(float(sc))
        if not idx:
            return np.zeros(total_len, dtype=np.float32)
        idx = np.asarray(idx, dtype=np.int64)
        values = np.asarray(values, dtype=np.float64)
        x = np.arange(total_len)
        return np.interp(x, idx, values, left=values[0], right=values[-1]).astype(np.float32)

    if mode != "mean":
        raise ValueError(f"Unknown point score mode: {mode}. Choose from mean/max/center/last.")

    scores_sum = np.zeros(total_len, dtype=np.float64)
    counts = np.zeros(total_len, dtype=np.float64)
    for sc, s in zip(window_scores, starts):
        scores_sum[s:s + window_size] += float(sc)
        counts[s:s + window_size] += 1.0
    counts[counts == 0] = 1.0
    return (scores_sum / counts).astype(np.float32)


class WindowDataset(Dataset):
    def __init__(self, windows):
        self.windows = torch.from_numpy(np.asarray(windows, dtype=np.float32)).float()

    def __len__(self):
        return len(self.windows)

    def __getitem__(self, idx):
        return self.windows[idx], torch.tensor(0, dtype=torch.long)


def build_window_loader(windows, batch_size, shuffle, num_workers=0, drop_last=False):
    return DataLoader(
        WindowDataset(windows),
        batch_size=batch_size,
        shuffle=shuffle,
        drop_last=drop_last,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", required=True)
    parser.add_argument("--dataset_name", default="KPI")
    parser.add_argument("--window_size", type=int, default=100)
    parser.add_argument("--window_stride", type=int, default=5)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--series_key", default=None)
    parser.add_argument("--series_index", type=int, default=None)
    args = parser.parse_args()

    if args.series_key is not None:
        os.environ["KPI_SERIES_KEY"] = str(args.series_key)
    if args.series_index is not None:
        os.environ["KPI_SERIES_INDEX"] = str(args.series_index)

    train = load_series(args.dataset_root, "train")
    test = load_series(args.dataset_root, "test")
    label = load_series(args.dataset_root, "test_label")

    train_s, test_s, _, _ = standardize_by_train(train, test)
    train_w, train_st = make_windows(train_s, args.window_size, args.window_stride)
    test_w, test_st = make_windows(test_s, args.window_size, args.window_stride)
    win_label = window_labels_from_point_labels(label, test_st, args.window_size)
    loader = build_window_loader(train_w, args.batch_size, shuffle=True)

    print("==== Dataloader check ====")
    print("dataset_root:", args.dataset_root)
    print("train:", train.shape, train.dtype)
    print("test:", test.shape, test.dtype)
    print("label:", label.shape, label.dtype, "anomaly_ratio=", float(label.mean()))
    print("train_windows:", train_w.shape)
    print("test_windows:", test_w.shape)
    print("window_labels:", win_label.shape, "anomaly_ratio=", float(win_label.mean()))
    bx, by = next(iter(loader))
    print("first batch:", bx.shape, by.shape)
