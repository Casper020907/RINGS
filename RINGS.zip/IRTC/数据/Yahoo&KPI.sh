#yahoo
cd /root/IRTC_SimMTM_style/IRTC_Anomaly/code && python run_ts2vec_fullseq_precision_boost_anomaly.py \
  --dataset_kind Yahoo \
  --dataset_root /root/IRTC_SimMTM_style/datasets/Yahoo \
  --run_tag Yahoo_best_ws20_pred_l1_sigma38_nms3 \
  --encoder tcn \
  --window_size 20 \
  --window_stride 1 \
  --eval_stride 1 \
  --patch_len 4 \
  --patch_stride 2 \
  --train_epochs 50 \
  --batch_size_train 256 \
  --batch_size_eval 512 \
  --lambda_pred 0.2 \
  --pred_repr projected \
  --pred_loss smooth_l1 \
  --search_mode performance \
  --sigma_grid 3.8 \
  --postprocess_modes nms \
  --nms_windows 3 \
  --min_precision 0.72 \
  --rank_by precision_f1 \
  --ts2vec_ma_window 21 \
  --ts2vec_skip 22 \
  --ts2vec_suppress_repeats \
  --eval_delay 3 \
  --use_gpu
Saved: ../checkpoints/yahoo_kpi_medium_final_summary.csv
Yahoo  | F1=0.762976 P=0.861328 R=0.684783 | score=pred_l1 sigma=4.0 post=nms nms=3 TP=1764 FP=284 FN=812
KPI    | F1=0.840185 P=0.887758 R=0.797452 | score=pred_l1 sigma=4.1 post=nms nms=5 TP=43509 FP=5501 FN=11051

Done.
Final CSV:
../checkpoints/yahoo_kpi_medium_final_summary.csv
