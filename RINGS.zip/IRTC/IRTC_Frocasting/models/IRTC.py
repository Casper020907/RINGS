# -*- coding: utf-8 -*-
"""IRTC forecasting v5 with forecast-safe causal timestamp representations.

Main corrections relative to the earlier forecasting version
-------------------------------------------------------------
1. All covariates and value channels are embedded jointly. Channel identity is
   never destroyed by channel-wise averaging.
2. The final causal patch always ends at the current timestamp, even when
   (length - patch_len) is not divisible by stride.
3. A causal Transformer prevents future leakage between patch tokens.
4. The original IRTC objective is applied exactly once to the final
   causal timestamp representation used by frozen Ridge evaluation.
"""

from __future__ import annotations

import os
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

_THIS = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_THIS, "..", ".."))
_PROJECT = os.path.abspath(os.path.join(_THIS, ".."))

if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
if _PROJECT not in sys.path:
    sys.path.insert(0, _PROJECT)

from common.model_blocks import IRTCEncoderModel, Predictor, ProjectionHead


class CausalMultivariatePatchTransformer(nn.Module):
    """Joint multivariate causal patch Transformer.

    Input
    -----
    x_bct : torch.Tensor
        Shape [B,C,T].

    Every patch contains all input features:

        [B,C,T] -> [B,N,C*patch_len] -> [B,N,d_model]

    The final patch always ends at T-1, so ``encode_timestamp`` includes the
    current observation.
    """

    ARCHITECTURE_VERSION = 3
    PROTOCOL_VERSION = 5

    def __init__(
        self,
        input_dim: int,
        seq_len: int,
        pred_len: int,
        c_out: int,
        d_model: int = 320,
        d_ff: int = 640,
        e_layers: int = 3,
        n_heads: int = 8,
        dropout: float = 0.1,
        proj_dim: int = 320,
        patch_len: int = 16,
        stride: int = 8,
        revin: bool = False,
        max_patches: int = 2048,
    ):
        super().__init__()

        if input_dim <= 0:
            raise ValueError(f"input_dim must be positive, got {input_dim}")
        if patch_len <= 0 or stride <= 0:
            raise ValueError("patch_len and stride must be positive")
        if d_model % n_heads != 0:
            raise ValueError(
                f"d_model={d_model} must be divisible by n_heads={n_heads}"
            )

        self.input_dim = int(input_dim)
        self.seq_len = int(seq_len)
        self.pred_len = int(pred_len)
        self.c_out = int(c_out)
        self.d_model = int(d_model)
        self.proj_dim = int(proj_dim)
        self.patch_len = int(patch_len)
        self.stride = int(stride)
        self.revin = bool(revin)
        self.max_patches = int(max_patches)

        # Joint embedding preserves feature identity and cross-feature structure.
        self.patch_embed = nn.Linear(
            self.input_dim * self.patch_len,
            self.d_model,
        )
        self.input_norm = nn.LayerNorm(self.d_model)

        self.pos_embed = nn.Parameter(
            torch.zeros(1, self.max_patches, self.d_model)
        )
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=self.d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=False,
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=e_layers,
        )
        self.output_norm = nn.LayerNorm(self.d_model)

        self.projector = ProjectionHead(
            self.d_model,
            self.proj_dim,
        )
        self.predictor = Predictor(self.proj_dim)

        # Self-supervised endpoint-state decoder. It reconstructs the final
        # physical-value patch and prevents the timestamp representation from
        # discarding level/local dynamics or collapsing to calendar shortcuts.
        self.state_decoder = nn.Sequential(
            nn.Linear(self.d_model, d_ff),
            nn.GELU(),
            nn.Linear(
                d_ff,
                self.input_dim * self.patch_len,
            ),
        )

        # Kept only for interface compatibility. Frozen Ridge evaluation does
        # not train or use this nonlinear head.
        self.forecast_head = nn.Sequential(
            nn.Linear(self.d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, self.pred_len * self.c_out),
        )

        self.register_buffer(
            "architecture_version",
            torch.tensor(
                self.ARCHITECTURE_VERSION,
                dtype=torch.long,
            ),
            persistent=True,
        )

        self.register_buffer(
            "protocol_version",
            torch.tensor(
                self.PROTOCOL_VERSION,
                dtype=torch.long,
            ),
            persistent=True,
        )

    def _patch_starts(self, length: int) -> list[int]:
        """Return causal patch starts and force the final patch to end at T-1."""
        if length <= self.patch_len:
            return [0]

        final_start = length - self.patch_len
        starts = list(
            range(
                0,
                final_start + 1,
                self.stride,
            )
        )

        if starts[-1] != final_start:
            starts.append(final_start)

        return starts

    def _patchify(self, x_bct: torch.Tensor) -> torch.Tensor:
        """Return joint patches [B,N,C*patch_len]."""
        if x_bct.dim() != 3:
            raise ValueError(
                f"Expected x_bct=[B,C,T], got {tuple(x_bct.shape)}"
            )

        batch_size, channels, length = x_bct.shape

        if channels != self.input_dim:
            raise ValueError(
                f"Input feature mismatch: model expects {self.input_dim}, "
                f"but received {channels}."
            )

        if length < self.patch_len:
            # Left padding keeps the final element aligned with the current time.
            x_bct = F.pad(
                x_bct,
                (self.patch_len - length, 0),
                mode="replicate",
            )
            length = self.patch_len

        starts = self._patch_starts(length)
        patches = torch.stack(
            [
                x_bct[..., start : start + self.patch_len]
                for start in starts
            ],
            dim=2,
        )  # [B,C,N,P]

        patches = patches.permute(
            0,
            2,
            1,
            3,
        ).contiguous()  # [B,N,C,P]

        return patches.reshape(
            batch_size,
            len(starts),
            channels * self.patch_len,
        )

    @staticmethod
    def _causal_mask(
        token_count: int,
        device: torch.device,
    ) -> torch.Tensor:
        return torch.triu(
            torch.ones(
                token_count,
                token_count,
                dtype=torch.bool,
                device=device,
            ),
            diagonal=1,
        )

    def _encode_tokens(self, x_bct: torch.Tensor) -> torch.Tensor:
        """Return causal token representations [B,N,D]."""
        patches = self._patchify(x_bct)
        token_count = int(patches.size(1))

        if token_count > self.max_patches:
            raise ValueError(
                f"token_count={token_count} exceeds "
                f"max_patches={self.max_patches}"
            )

        tokens = self.patch_embed(patches)
        tokens = self.input_norm(tokens)
        tokens = (
            tokens
            + self.pos_embed[:, :token_count, :]
        )

        tokens = self.transformer(
            tokens,
            mask=self._causal_mask(
                token_count,
                tokens.device,
            ),
        )
        return self.output_norm(tokens)

    def encode_sequence(
        self,
        x_bct: torch.Tensor,
    ) -> torch.Tensor:
        """Return [B,D,N] causal patch-sequence representations."""
        return self._encode_tokens(
            x_bct
        ).transpose(1, 2).contiguous()

    def encode_timestamp(
        self,
        x_bct: torch.Tensor,
    ) -> torch.Tensor:
        """Return the current timestamp representation [B,D].

        The final token's patch always ends at the final input timestamp.
        """
        tokens = self._encode_tokens(x_bct)
        return tokens[:, -1, :]

    def encode(
        self,
        x_bct: torch.Tensor,
        project: bool = False,
    ) -> torch.Tensor:
        """Compatibility global representation used only by optional ablations."""
        tokens = self._encode_tokens(x_bct)
        representation = tokens.mean(dim=1)
        return (
            self.projector(representation)
            if project
            else representation
        )

    def project_features(
        self,
        features: torch.Tensor,
    ) -> torch.Tensor:
        """Project features whose last dimension is d_model."""
        if features.size(-1) != self.d_model:
            raise ValueError(
                f"Expected last dimension {self.d_model}, "
                f"got {features.size(-1)}"
            )

        original_shape = features.shape[:-1]
        flat = features.reshape(-1, self.d_model)
        projected = self.projector(flat)
        return projected.reshape(
            *original_shape,
            self.proj_dim,
        )

    def projected_endpoint(
        self,
        sequence_bdn: torch.Tensor,
    ) -> torch.Tensor:
        endpoint = sequence_bdn[..., -1]
        return self.project_features(endpoint)

    def reconstruct_last_patch(
        self,
        endpoint_hidden: torch.Tensor,
    ) -> torch.Tensor:
        """Reconstruct the final physical-value patch as [B,C,P]."""
        if endpoint_hidden.dim() != 2:
            raise ValueError(
                f"Expected endpoint_hidden=[B,D], got "
                f"{tuple(endpoint_hidden.shape)}"
            )
        output = self.state_decoder(endpoint_hidden)
        return output.view(
            endpoint_hidden.size(0),
            self.input_dim,
            self.patch_len,
        )

    def forecast(
        self,
        x_btc: torch.Tensor,
    ) -> torch.Tensor:
        """Legacy neural forecast head; not used by frozen-Ridge protocol."""
        if x_btc.dim() != 3:
            raise ValueError(
                f"Expected x_btc=[B,T,C], got {tuple(x_btc.shape)}"
            )

        x_bct = x_btc.permute(
            0,
            2,
            1,
        ).contiguous()
        endpoint = self.encode_timestamp(x_bct)
        output = self.forecast_head(endpoint)
        return output.view(
            x_btc.size(0),
            self.pred_len,
            self.c_out,
        )


class Model(nn.Module):
    """IRTC model exposing causal timestamp and endpoint-IRTC APIs."""

    ARCHITECTURE_VERSION = 3
    PROTOCOL_VERSION = 5

    def __init__(self, configs):
        super().__init__()

        self.configs = configs
        self.encoder_name = str(
            getattr(configs, "encoder", "transformer")
        ).lower()
        self.pred_len = int(configs.pred_len)
        self.c_out = int(configs.c_out)

        if self.encoder_name in {
            "transformer",
            "patchtst",
            "patch_transformer",
        }:
            self.encoder_model = CausalMultivariatePatchTransformer(
                input_dim=int(configs.enc_in),
                seq_len=int(configs.seq_len),
                pred_len=self.pred_len,
                c_out=self.c_out,
                d_model=int(configs.d_model),
                d_ff=int(configs.d_ff),
                e_layers=int(
                    getattr(configs, "e_layers", 3)
                ),
                n_heads=int(
                    getattr(configs, "n_heads", 8)
                ),
                dropout=float(
                    getattr(configs, "dropout", 0.1)
                ),
                proj_dim=int(
                    getattr(configs, "proj_dim", configs.d_model)
                ),
                patch_len=int(
                    getattr(configs, "patch_len", 16)
                ),
                stride=int(
                    getattr(configs, "stride", 8)
                ),
                revin=bool(
                    getattr(configs, "revin", False)
                ),
                max_patches=int(
                    getattr(configs, "max_patches", 2048)
                ),
            )
            self.head = None

        else:
            self.encoder_model = IRTCEncoderModel(
                hidden_dim=int(configs.d_model),
                depth=int(
                    getattr(configs, "e_layers", 3)
                ),
                proj_dim=int(
                    getattr(configs, "proj_dim", configs.d_model)
                ),
                dropout=float(
                    getattr(configs, "dropout", 0.1)
                ),
                encoder_type=self.encoder_name,
            )
            self.head = nn.Sequential(
                nn.Linear(
                    int(configs.d_model) * 2,
                    int(configs.d_ff),
                ),
                nn.GELU(),
                nn.Dropout(
                    float(
                        getattr(configs, "dropout", 0.1)
                    )
                ),
                nn.Linear(
                    int(configs.d_ff),
                    self.pred_len * self.c_out,
                ),
            )

        self.register_buffer(
            "model_architecture_version",
            torch.tensor(
                self.ARCHITECTURE_VERSION,
                dtype=torch.long,
            ),
            persistent=True,
        )

        self.register_buffer(
            "model_protocol_version",
            torch.tensor(
                self.PROTOCOL_VERSION,
                dtype=torch.long,
            ),
            persistent=True,
        )

    def encode_sequence(
        self,
        x_bct: torch.Tensor,
    ) -> torch.Tensor:
        return self.encoder_model.encode_sequence(x_bct)

    def project_features(
        self,
        features: torch.Tensor,
    ) -> torch.Tensor:
        if hasattr(
            self.encoder_model,
            "project_features",
        ):
            return self.encoder_model.project_features(
                features
            )

        hidden_dim = int(
            self.encoder_model.hidden_dim
        )
        original_shape = features.shape[:-1]
        flat = features.reshape(
            -1,
            hidden_dim,
        )
        projected = self.encoder_model.projector(
            flat
        )
        return projected.reshape(
            *original_shape,
            self.encoder_model.proj_dim,
        )

    def projected_endpoint(
        self,
        sequence_bdn: torch.Tensor,
    ) -> torch.Tensor:
        endpoint = sequence_bdn[..., -1]
        return self.project_features(endpoint)

    def reconstruct_last_patch(
        self,
        endpoint_hidden: torch.Tensor,
    ) -> torch.Tensor:
        if not hasattr(self.encoder_model, "reconstruct_last_patch"):
            raise RuntimeError(
                "The selected encoder does not implement state reconstruction."
            )
        return self.encoder_model.reconstruct_last_patch(
            endpoint_hidden
        )

    def encode_projected(
        self,
        x_bct: torch.Tensor,
    ) -> torch.Tensor:
        return self.encoder_model.encode(
            x_bct,
            project=True,
        )

    def encode_timestamp(
        self,
        x_btc: torch.Tensor,
    ) -> torch.Tensor:
        if x_btc.dim() != 3:
            raise ValueError(
                f"Expected x_btc=[B,T,C], got {tuple(x_btc.shape)}"
            )

        x_bct = x_btc.permute(
            0,
            2,
            1,
        ).contiguous()

        if hasattr(
            self.encoder_model,
            "encode_timestamp",
        ):
            return self.encoder_model.encode_timestamp(
                x_bct
            )

        sequence = self.encoder_model.encode_sequence(
            x_bct
        )
        return sequence[..., -1]

    def forward(
        self,
        x_enc,
        x_mark_enc=None,
        x_dec=None,
        x_mark_dec=None,
    ):
        if x_enc.dim() != 3:
            raise ValueError(
                f"Expected x_enc=[B,T,C], got {tuple(x_enc.shape)}"
            )

        if hasattr(
            self.encoder_model,
            "forecast",
        ):
            return self.encoder_model.forecast(x_enc)

        x_bct = x_enc.permute(
            0,
            2,
            1,
        ).contiguous()
        sequence = self.encoder_model.encode_sequence(
            x_bct
        )
        pooled = sequence.mean(dim=-1)
        last = sequence[..., -1]
        features = torch.cat(
            [pooled, last],
            dim=-1,
        )
        return self.head(features).view(
            x_enc.size(0),
            self.pred_len,
            self.c_out,
        )
