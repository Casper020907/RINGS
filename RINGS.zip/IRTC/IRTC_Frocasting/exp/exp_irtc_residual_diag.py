# -*- coding: utf-8 -*-
"""Residual-target diagnostic for forecast-safe IRTC frozen Ridge evaluation."""

from __future__ import annotations

import json
import os
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split
from torch.optim import AdamW

_THIS = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_THIS, "..", ".."))
_PROJECT = os.path.abspath(os.path.join(_THIS, ".."))

if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
if _PROJECT not in sys.path:
    sys.path.insert(0, _PROJECT)

from common.augmentations import FreqAugmentor, TimeAugmentor, ensure_bct
from common.losses import IRTCLoss
from common.utils import mkdir, save_checkpoint, set_seed
from data_provider.data_factory import data_provider, forecasting_data_provider
from models.IRTC import Model


class SharedSpectrumRidge:
    """Exact multi-output Ridge model using a shared feature spectrum.

    Coefficients solve the same fit-intercept L2 objective as sklearn Ridge,
    while reusing one eigendecomposition for every output and alpha.
    """

    def __init__(
        self,
        coef,
        x_mean,
        y_mean,
        alpha,
    ):
        self.coef_ = np.ascontiguousarray(coef, dtype=np.float64)
        self.x_mean_ = np.ascontiguousarray(x_mean, dtype=np.float64)
        self.intercept_ = np.ascontiguousarray(y_mean, dtype=np.float64)
        self.alpha = float(alpha)

    def predict(self, x):
        x = np.ascontiguousarray(x, dtype=np.float64)
        return (x - self.x_mean_) @ self.coef_ + self.intercept_


class Exp_IRTC:
    """Forecast-safe endpoint IRTC with state-preserving SSL."""

    RIDGE_ALPHAS = [
        0.1,
        0.2,
        0.5,
        1,
        2,
        5,
        10,
        20,
        50,
        100,
        200,
        500,
        1000,
        2000,
        5000,
        10000,
        20000,
        50000,
        100000,
    ]

    REQUIRED_V5_KEYS = {
        "encoder_model.patch_embed.weight",
        "encoder_model.patch_embed.bias",
        "encoder_model.architecture_version",
        "model_architecture_version",
        "encoder_model.protocol_version",
        "model_protocol_version",
        "encoder_model.state_decoder.0.weight",
        "encoder_model.state_decoder.2.weight",
    }

    def __init__(self, args):
        self.args = args
        set_seed(args.seed)

        use_cuda = (
            bool(args.use_gpu)
            and torch.cuda.is_available()
        )
        self.device = torch.device(
            f"cuda:{args.gpu}"
            if use_cuda
            else "cpu"
        )
        self.model = Model(args).to(self.device)

    def _ckpt_dir(self, setting):
        path = (
            Path(self.args.checkpoints)
            / setting
        )
        mkdir(path)
        return path

    @staticmethod
    def _write_log(log_path, message):
        print(message)
        if log_path is not None:
            with open(
                log_path,
                "a",
                encoding="utf-8",
            ) as file:
                file.write(message + "\n")

    def _graph_weight(self, epoch, epochs):
        warm = int(
            max(
                0,
                epochs * self.args.warmup_ratio,
            )
        )

        if warm <= 0:
            return 1.0
        if epoch <= warm:
            return 0.0

        return min(
            1.0,
            (epoch - warm) / max(1, warm),
        )

    @staticmethod
    def _torch_load(path, device):
        try:
            return torch.load(
                path,
                map_location=device,
                weights_only=False,
            )
        except TypeError:
            return torch.load(
                path,
                map_location=device,
            )

    @staticmethod
    def _extract_state_dict(checkpoint):
        if not isinstance(checkpoint, dict):
            raise ValueError(
                f"Unsupported checkpoint type: "
                f"{type(checkpoint)}"
            )

        for key in (
            "model_state_dict",
            "model_state",
            "state_dict",
            "model",
            "net",
        ):
            state = checkpoint.get(key)
            if isinstance(state, dict):
                return state

        if checkpoint and all(
            torch.is_tensor(value)
            for value in checkpoint.values()
        ):
            return checkpoint

        raise ValueError(
            "No model state dictionary found "
            "in checkpoint."
        )

    @staticmethod
    def _is_forecast_head_param(name):
        return (
            name.startswith("head.")
            or any(
                key in name
                for key in (
                    "forecast_head",
                    "linear_forecast",
                    "prediction_head",
                    "output_projection",
                )
            )
        )

    def _resolve_checkpoint(
        self,
        checkpoint_arg,
    ):
        if not checkpoint_arg:
            raise ValueError(
                "Frozen forecasting requires a pretrained "
                "v5 forecast-safe endpoint-IRTC encoder checkpoint."
            )

        checkpoint_path = Path(
            checkpoint_arg
        )

        if not checkpoint_path.exists():
            candidate = (
                Path(self.args.checkpoints)
                / checkpoint_arg
            )

            if candidate.exists():
                checkpoint_path = candidate
            else:
                raise FileNotFoundError(
                    f"Checkpoint not found: "
                    f"{checkpoint_arg}"
                )

        return checkpoint_path

    def _load_pretrain(self):
        checkpoint_path = self._resolve_checkpoint(
            getattr(
                self.args,
                "transfer_checkpoints",
                "",
            )
        )

        print(
            f"Loading pretrained encoder: "
            f"{checkpoint_path}"
        )

        checkpoint = self._torch_load(
            checkpoint_path,
            self.device,
        )
        state = self._extract_state_dict(
            checkpoint
        )

        cleaned_state = {
            key.replace("module.", ""): value
            for key, value in state.items()
        }

        checkpoint_protocol = checkpoint.get("protocol_version")
        if checkpoint_protocol is not None and int(checkpoint_protocol) != 5:
            raise RuntimeError(
                f"Checkpoint metadata protocol_version={checkpoint_protocol}, "
                "but forecasting v5 requires protocol_version=5."
            )

        for protocol_key in (
            "encoder_model.protocol_version",
            "model_protocol_version",
        ):
            value = cleaned_state.get(protocol_key)
            if value is None or int(value.detach().cpu().item()) != 5:
                raise RuntimeError(
                    f"{protocol_key} is not exactly 5. "
                    "Do not reuse v2/v3 forecasting checkpoints."
                )

        missing_required = (
            self.REQUIRED_V5_KEYS
            - set(cleaned_state)
        )

        if missing_required:
            raise RuntimeError(
                "The supplied checkpoint is not compatible with the "
                "v5 forecast-safe causal endpoint-IRTC encoder. "
                "Retrain SSL with the v3 model. Missing keys: "
                f"{sorted(missing_required)}"
            )

        model_state = self.model.state_dict()
        filtered = {}
        skipped = []

        for key, value in cleaned_state.items():
            if not torch.is_tensor(value):
                skipped.append(
                    (key, "non-tensor")
                )
            elif self._is_forecast_head_param(key):
                skipped.append(
                    (
                        key,
                        "forecast head excluded by protocol",
                    )
                )
            elif (
                key in model_state
                and model_state[key].shape == value.shape
            ):
                filtered[key] = value
            elif key in model_state:
                skipped.append(
                    (
                        key,
                        tuple(value.shape),
                        tuple(model_state[key].shape),
                    )
                )
            else:
                skipped.append(
                    (key, "not in current model")
                )

        encoder_parameter_count = sum(
            value.numel()
            for key, value in model_state.items()
            if key.startswith("encoder_model.")
            and not self._is_forecast_head_param(key)
        )
        loaded_encoder_count = sum(
            value.numel()
            for key, value in filtered.items()
            if key.startswith("encoder_model.")
            and not self._is_forecast_head_param(key)
        )
        coverage = (
            loaded_encoder_count
            / max(encoder_parameter_count, 1)
        )

        if coverage < 0.98:
            raise RuntimeError(
                f"Only {coverage:.2%} of v5 encoder parameters "
                "were compatible. Refusing partial transfer."
            )

        missing, unexpected = (
            self.model.load_state_dict(
                filtered,
                strict=False,
            )
        )

        print(
            f"Loaded compatible parameters: "
            f"{len(filtered)}"
        )
        print(
            f"Encoder parameter coverage: "
            f"{coverage:.2%}"
        )
        print(
            f"Skipped parameters: "
            f"{len(skipped)}"
        )

        for item in skipped[:10]:
            print("  skipped:", item)

        print(
            f"Missing keys after transfer: "
            f"{len(missing)}"
        )
        print(
            f"Unexpected keys after transfer: "
            f"{len(unexpected)}"
        )

    def _build_ssl_components(self):
        preserve_tail = int(self.args.patch_len)
        augmentors = {
            "time_w": TimeAugmentor(
                weak=True,
                forecasting_safe=True,
                preserve_tail=preserve_tail,
            ),
            "time_s": TimeAugmentor(
                weak=False,
                forecasting_safe=True,
                preserve_tail=preserve_tail,
            ),
            "freq_w": FreqAugmentor(
                weak=True,
                forecasting_safe=True,
                preserve_tail=preserve_tail,
            ),
            "freq_s": FreqAugmentor(
                weak=False,
                forecasting_safe=True,
                preserve_tail=preserve_tail,
            ),
        }

        criterion = IRTCLoss(
            lambda_tic=self.args.lambda_tic,
            lambda_trgc=self.args.lambda_trgc,
            lambda_frgc=self.args.lambda_frgc,
            lambda_tfrc=self.args.lambda_tfrc,
            tau_t=self.args.tau_t,
            tau_f=self.args.tau_f,
            topk=self.args.graph_topk,
        )
        return augmentors, criterion

    def _select_physical_values(
        self,
        x_bct: torch.Tensor,
    ) -> torch.Tensor:
        """Remove calendar covariates before the SSL encoder."""
        n_covariates = int(
            getattr(self.args, "n_covariates", 7)
        )
        if n_covariates < 0 or n_covariates >= x_bct.size(1):
            raise ValueError(
                f"Expected 0 <= n_covariates < {x_bct.size(1)}, "
                f"got {n_covariates}"
            )
        values = x_bct[:, n_covariates:, :]
        expected = int(self.args.enc_in)
        if values.size(1) != expected:
            raise ValueError(
                f"Physical-value channel mismatch: selected "
                f"{values.size(1)}, model enc_in={expected}."
            )
        return values

    @staticmethod
    def _variance_regularizer(
        hidden: torch.Tensor,
        target_std: float = 1.0,
    ) -> torch.Tensor:
        """VICReg-style anti-collapse penalty over the batch dimension."""
        if hidden.dim() != 2:
            raise ValueError(
                f"Expected hidden=[B,D], got {tuple(hidden.shape)}"
            )
        if hidden.size(0) < 2:
            return hidden.sum() * 0.0
        std = torch.sqrt(
            hidden.var(dim=0, unbiased=False) + 1e-4
        )
        return torch.relu(float(target_std) - std).mean()

    def _ssl_forward(
        self,
        seq_x,
        augmentors,
        criterion,
        graph_weight,
    ):
        """Forecast-safe SSL on physical-value channels only.

        Temporal order and the final patch are preserved in every view.
        Original IRTC is still called exactly once. Two self-supervised
        state-preservation terms are added:
          1. reconstruct the final value patch;
          2. keep batch-wise endpoint variance above a minimum.
        """
        x = ensure_bct(seq_x).to(
            self.device,
            non_blocking=True,
        )
        values = self._select_physical_values(x)

        views = {
            name: augmentor(values)
            for name, augmentor in augmentors.items()
        }
        sequences = {
            name: self.model.encode_sequence(view)
            for name, view in views.items()
        }
        hidden = {
            name: sequence[..., -1]
            for name, sequence in sequences.items()
        }
        projected = {
            name: self.model.project_features(value)
            for name, value in hidden.items()
        }

        losses = criterion(
            self.model.encoder_model,
            projected["time_w"],
            projected["time_s"],
            projected["freq_w"],
            projected["freq_s"],
            graph_weight=graph_weight,
        )
        losses["irtc_total"] = losses["total"]

        patch_len = int(self.args.patch_len)
        target_patch = values[..., -patch_len:].detach()
        recon_terms = [
            nn.functional.mse_loss(
                self.model.reconstruct_last_patch(value),
                target_patch,
            )
            for value in hidden.values()
        ]
        losses["state_recon"] = torch.stack(recon_terms).mean()

        variance_terms = [
            self._variance_regularizer(value)
            for value in hidden.values()
        ]
        losses["variance"] = torch.stack(variance_terms).mean()

        losses["total"] = (
            losses["irtc_total"]
            + float(self.args.lambda_state_recon)
            * losses["state_recon"]
            + float(self.args.lambda_variance)
            * losses["variance"]
        )
        return losses

    def pretrain(self, setting):
        """Train only on the chronological training slice."""
        _, train_loader = data_provider(
            self.args,
            "pretrain",
        )
        augmentors, criterion = (
            self._build_ssl_components()
        )

        optimizer = AdamW(
            self.model.parameters(),
            lr=self.args.learning_rate,
            weight_decay=self.args.weight_decay,
        )

        ckpt_dir = self._ckpt_dir(setting)
        log_path = ckpt_dir / "log.txt"

        self._write_log(
            str(log_path),
            f"Setting: {setting}",
        )
        self._write_log(
            str(log_path),
            f"Arguments: {vars(self.args)}",
        )
        self._write_log(
            str(log_path),
            "Protocol v5: physical-value-only causal patch encoder; "
            "forecast-safe augmentations preserve temporal order/final patch; "
            "original IRTC is called once; endpoint state reconstruction and "
            "variance regularization prevent information loss/collapse; TRAIN only.",
        )

        metrics = None

        for epoch in range(
            1,
            self.args.train_epochs + 1,
        ):
            self.model.train()

            totals = {
                "total": 0.0,
                "irtc_total": 0.0,
                "state_recon": 0.0,
                "variance": 0.0,
                "tic": 0.0,
                "trgc": 0.0,
                "frgc": 0.0,
                "tfrc": 0.0,
            }
            count = 0
            start = time.time()

            graph_weight = self._graph_weight(
                epoch,
                self.args.train_epochs,
            )

            for seq_x, _ in train_loader:
                batch_size = int(
                    seq_x.size(0)
                )

                losses = self._ssl_forward(
                    seq_x,
                    augmentors,
                    criterion,
                    graph_weight=graph_weight,
                )
                loss = losses["total"]

                optimizer.zero_grad(
                    set_to_none=True
                )
                loss.backward()

                nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    self.args.clip_grad,
                )
                optimizer.step()

                for key in totals:
                    totals[key] += (
                        float(
                            losses[key]
                            .detach()
                            .cpu()
                        )
                        * batch_size
                    )

                count += batch_size

            metrics = {
                key: value / max(count, 1)
                for key, value in totals.items()
            }
            text = " | ".join(
                f"{key}={value:.6f}"
                for key, value in metrics.items()
            )

            self._write_log(
                str(log_path),
                f"Pretrain Epoch "
                f"{epoch:03d}/"
                f"{self.args.train_epochs} | "
                f"{text} | "
                f"graph_w={graph_weight:.2f} | "
                f"{time.time() - start:.1f}s",
            )

            save_checkpoint(
                str(ckpt_dir / "last.pth"),
                epoch=epoch,
                model_state=self.model.state_dict(),
                args=vars(self.args),
                train_pretrain_loss=metrics["total"],
                lambda_state_recon=float(self.args.lambda_state_recon),
                lambda_variance=float(self.args.lambda_variance),
                architecture_version=3,
                protocol_version=5,
                protocol="forecast_safe_values_endpoint_irtc_state_recon",
            )

        final_checkpoint = (
            ckpt_dir
            / "best.pth"
        )

        save_checkpoint(
            str(final_checkpoint),
            epoch=self.args.train_epochs,
            model_state=self.model.state_dict(),
            args=vars(self.args),
            train_pretrain_loss=metrics["total"],
            lambda_state_recon=float(self.args.lambda_state_recon),
            lambda_variance=float(self.args.lambda_variance),
            selection="final_training_epoch",
            architecture_version=3,
            protocol_version=5,
            protocol="forecast_safe_values_endpoint_irtc_state_recon",
        )

        self._write_log(
            str(log_path),
            f"Saved pretrained encoder: "
            f"{final_checkpoint}",
        )

        return str(final_checkpoint)

    @staticmethod
    def _generate_pred_samples(
        features,
        data,
        pred_len,
        drop=0,
    ):
        """Construct x_t -> [y_{t+1}, ..., y_{t+H}] samples.

        This is the single-instance 2D equivalent of the official TS2Vec
        forecasting evaluator. ``features[t]`` is paired with future targets
        ``data[t+1:t+1+pred_len]``.
        """
        features = np.asarray(features)
        data = np.asarray(data)

        if features.ndim != 2:
            raise ValueError(
                f"features must be [T,D], got {features.shape}"
            )
        if data.ndim != 2:
            raise ValueError(
                f"data must be [T,C], got {data.shape}"
            )
        if features.shape[0] != data.shape[0]:
            raise ValueError(
                "Feature/data timeline mismatch: "
                f"{features.shape[0]} vs {data.shape[0]}"
            )

        n = int(data.shape[0])
        pred_len = int(pred_len)
        drop = int(drop)

        if pred_len <= 0 or pred_len >= n:
            raise ValueError(
                f"Invalid pred_len={pred_len} "
                f"for split length={n}"
            )

        x = features[:-pred_len]
        y = np.stack(
            [
                data[
                    offset
                    : 1 + n + offset - pred_len
                ]
                for offset in range(pred_len)
            ],
            axis=1,
        )[1:]

        if x.shape[0] != y.shape[0]:
            raise RuntimeError(
                f"Sample alignment failed: x={x.shape}, y={y.shape}"
            )

        if drop < 0 or drop >= x.shape[0]:
            raise ValueError(
                f"Invalid drop={drop} for {x.shape[0]} samples"
            )

        x = x[drop:]
        y = y[drop:]

        return (
            np.ascontiguousarray(
                x.reshape(-1, x.shape[-1])
            ),
            np.ascontiguousarray(
                y.reshape(
                    -1,
                    pred_len * data.shape[-1],
                )
            ),
        )

    @staticmethod
    def _metrics(pred, target):
        pred = np.asarray(pred, dtype=np.float64)
        target = np.asarray(target, dtype=np.float64)

        if pred.shape != target.shape:
            raise ValueError(
                f"Metric shape mismatch: pred={pred.shape}, "
                f"target={target.shape}"
            )
        if not np.isfinite(pred).all():
            raise FloatingPointError(
                "Predictions contain NaN or Inf."
            )
        if not np.isfinite(target).all():
            raise FloatingPointError(
                "Targets contain NaN or Inf."
            )

        diff = pred - target

        return {
            "MSE": float(np.mean(diff**2)),
            "MAE": float(np.mean(np.abs(diff))),
        }

    @staticmethod
    def _per_target_metrics(
        pred,
        target,
        target_names,
    ):
        pred = np.asarray(pred, dtype=np.float64)
        target = np.asarray(target, dtype=np.float64)

        if pred.ndim != 3:
            raise ValueError(
                f"Expected [N,H,C], got {pred.shape}"
            )

        names = list(target_names)
        if len(names) != pred.shape[-1]:
            names = [
                f"target_{index}"
                for index in range(pred.shape[-1])
            ]

        output = {}
        for index, name in enumerate(names):
            output[str(name)] = Exp_IRTC._metrics(
                pred[..., index],
                target[..., index],
            )
        return output

    @staticmethod
    def _persistence_prediction(
        split_data,
        pred_len,
        drop=0,
    ):
        """Repeat the current observed value over the future horizon."""
        split_data = np.asarray(
            split_data,
            dtype=np.float64,
        )
        current = split_data[:-pred_len]
        if drop:
            current = current[int(drop):]
        return np.repeat(
            current[:, None, :],
            int(pred_len),
            axis=1,
        )

    @staticmethod
    def _validate_label_alignment(
        split_data,
        flattened_y,
        pred_len,
        split_name,
        atol=1e-7,
    ):
        """Verify the first generated label is y[t+1:t+1+H]."""
        split_data = np.asarray(
            split_data,
            dtype=np.float64,
        )
        y = np.asarray(
            flattened_y,
            dtype=np.float64,
        ).reshape(
            -1,
            int(pred_len),
            split_data.shape[-1],
        )

        expected_first = split_data[
            1 : 1 + int(pred_len)
        ]
        error = float(
            np.max(
                np.abs(
                    y[0] - expected_first
                )
            )
        )

        if error > atol:
            raise RuntimeError(
                f"{split_name} label alignment failed: "
                f"max_abs_error={error:.3e}"
            )
        return error

    def _fit_ridge(
        self,
        train_x,
        train_y,
        valid_x,
        valid_y,
    ):
        """Fit exact multi-output Ridge with one shared eigendecomposition.

        The previous LSQR implementation solved one iterative system for every
        target and alpha. For H=168 this meant 1176 targets x 19 alphas; for
        H=720 it meant 5040 x 19 solves. Here all targets share the same
        feature covariance decomposition, preserving the Ridge objective while
        making long-horizon evaluation practical.
        """
        train_x = np.ascontiguousarray(
            train_x,
            dtype=np.float64,
        )
        train_y = np.ascontiguousarray(
            train_y,
            dtype=np.float64,
        )
        valid_x = np.ascontiguousarray(
            valid_x,
            dtype=np.float64,
        )
        valid_y = np.ascontiguousarray(
            valid_y,
            dtype=np.float64,
        )

        for name, array in (
            ("train_x", train_x),
            ("train_y", train_y),
            ("valid_x", valid_x),
            ("valid_y", valid_y),
        ):
            if not np.isfinite(array).all():
                raise FloatingPointError(
                    f"{name} contains NaN or Inf."
                )

        max_samples = int(
            getattr(
                self.args,
                "ridge_max_samples",
                100000,
            )
        )

        if train_x.shape[0] > max_samples:
            (
                train_x,
                _,
                train_y,
                _,
            ) = train_test_split(
                train_x,
                train_y,
                train_size=max_samples,
                random_state=0,
            )

        if valid_x.shape[0] > max_samples:
            (
                valid_x,
                _,
                valid_y,
                _,
            ) = train_test_split(
                valid_x,
                valid_y,
                train_size=max_samples,
                random_state=0,
            )

        x_mean = train_x.mean(axis=0, dtype=np.float64)
        y_mean = train_y.mean(axis=0, dtype=np.float64)
        train_x_centered = train_x - x_mean
        train_y_centered = train_y - y_mean
        valid_x_centered = valid_x - x_mean

        # X^T X is only [D,D] (D=327 in the current protocol). One symmetric
        # eigendecomposition is shared by all horizons, targets, and alphas.
        xtx = train_x_centered.T @ train_x_centered
        eigenvalues, eigenvectors = np.linalg.eigh(xtx)
        eigenvalues = np.maximum(eigenvalues, 0.0)

        # Transform X^T Y and validation X once into the shared eigenbasis.
        spectral_xy = (
            eigenvectors.T
            @ (train_x_centered.T @ train_y_centered)
        )
        valid_spectral_x = valid_x_centered @ eigenvectors

        alpha_records = []
        best_record = None
        best_spectral_coef = None
        total_alphas = len(self.RIDGE_ALPHAS)

        print(
            f"[Ridge shared-spectrum] samples={train_x.shape[0]} "
            f"features={train_x.shape[1]} outputs={train_y.shape[1]} "
            f"alphas={total_alphas}",
            flush=True,
        )

        for index, alpha in enumerate(self.RIDGE_ALPHAS, start=1):
            alpha = float(alpha)
            spectral_coef = spectral_xy / (
                eigenvalues[:, None] + alpha
            )
            valid_pred = (
                valid_spectral_x @ spectral_coef
                + y_mean
            )
            valid_metrics = self._metrics(
                valid_pred,
                valid_y,
            )
            score = (
                np.sqrt(valid_metrics["MSE"])
                + valid_metrics["MAE"]
            )

            record = {
                "alpha": alpha,
                "validation_mse": float(
                    valid_metrics["MSE"]
                ),
                "validation_mae": float(
                    valid_metrics["MAE"]
                ),
                "validation_rmse_plus_mae": float(score),
            }
            alpha_records.append(record)

            if (
                best_record is None
                or (
                    record["validation_rmse_plus_mae"],
                    record["alpha"],
                )
                < (
                    best_record["validation_rmse_plus_mae"],
                    best_record["alpha"],
                )
            ):
                best_record = record
                best_spectral_coef = spectral_coef.copy()

            print(
                f"[Ridge alpha {index:02d}/{total_alphas:02d}] "
                f"alpha={alpha:g} | val_MSE="
                f"{valid_metrics['MSE']:.6f} | val_MAE="
                f"{valid_metrics['MAE']:.6f}",
                flush=True,
            )

        if best_record is None or best_spectral_coef is None:
            raise RuntimeError("Ridge alpha search produced no result.")

        best_alpha = float(best_record["alpha"])
        coef = eigenvectors @ best_spectral_coef
        regressor = SharedSpectrumRidge(
            coef=coef,
            x_mean=x_mean,
            y_mean=y_mean,
            alpha=best_alpha,
        )

        return (
            regressor,
            best_alpha,
            float(
                best_record["validation_rmse_plus_mae"]
            ),
            alpha_records,
        )

    def _extract_causal_representations(
        self,
        data,
    ):
        """Extract one final-point representation for every causal window."""
        context = int(
            getattr(
                self.args,
                "forecast_context",
                200,
            )
        )
        batch_size = int(
            getattr(
                self.args,
                "repr_batch_size",
                256,
            )
        )

        if context < 1:
            raise ValueError(
                "forecast_context must be positive"
            )
        if len(data) <= context:
            raise ValueError(
                f"Series length {len(data)} "
                f"must exceed context {context}"
            )

        self.model.eval()
        all_repr = None
        infer_start = time.time()

        with torch.inference_mode():
            for start in range(
                context,
                len(data),
                batch_size,
            ):
                end = min(
                    len(data),
                    start + batch_size,
                )

                windows = np.stack(
                    [
                        data[
                            timestamp - context
                            : timestamp + 1
                        ]
                        for timestamp in range(
                            start,
                            end,
                        )
                    ],
                    axis=0,
                ).astype(
                    np.float32,
                    copy=False,
                )

                x = torch.from_numpy(
                    windows
                ).to(
                    self.device,
                    non_blocking=True,
                )

                z = self.model.encode_timestamp(x)
                z = (
                    z.reshape(
                        z.size(0),
                        -1,
                    )
                    .detach()
                    .cpu()
                    .numpy()
                    .astype(
                        np.float32,
                        copy=False,
                    )
                )

                if all_repr is None:
                    all_repr = np.zeros(
                        (
                            len(data),
                            z.shape[1],
                        ),
                        dtype=np.float32,
                    )

                all_repr[start:end] = z

        return (
            all_repr,
            time.time() - infer_start,
        )

    def train(self, setting):
        """Run frozen-encoder Ridge forecasting with strict diagnostics."""
        self._load_pretrain()

        for parameter in self.model.parameters():
            parameter.requires_grad = False

        bundle = forecasting_data_provider(
            self.args
        )
        ckpt_dir = self._ckpt_dir(setting)
        log_path = ckpt_dir / "log.txt"

        self._write_log(
            str(log_path),
            f"Setting: {setting}",
        )
        self._write_log(
            str(log_path),
            f"Arguments: {vars(self.args)}",
        )
        self._write_log(
            str(log_path),
            "Residual forecasting diagnostic: frozen forecast-safe value encoder; "
            "Ridge predicts normalized future change y[t+h]-x[t], then the current "
            "value x[t] is added back before all validation/test metrics; "
            "current calendar covariates are appended only for Ridge; "
            + (
                "diagnostic current-value and one-step-delta features are also enabled; "
                if bool(getattr(self.args, "ridge_state_features", False))
                else "diagnostic state/delta skip features are disabled; "
            )
            + "float64 shared-spectrum exact Ridge alpha selected on validation; "
            "label alignment, inverse scaling, per-target metrics, "
            "and naive baselines are verified.",
        )

        (
            all_repr,
            encoder_infer_time,
        ) = self._extract_causal_representations(
            bundle.target_data
        )

        # Calendar information is supplied to the linear probe only. It is not
        # visible to the SSL encoder, preventing an unchanged-view shortcut.
        calendar = bundle.model_data[
            :,
            : bundle.n_covariate_cols,
        ]
        feature_parts = [all_repr, calendar]
        representation_description = (
            "value-only causal endpoint plus current calendar covariates"
        )

        # Diagnostic-only skip features. These use only information available
        # at forecast origin t, so they do not leak future targets. They are
        # intended to test whether ETTh2 fails because the frozen endpoint
        # representation does not make current level/trend linearly readable.
        if bool(getattr(self.args, "ridge_state_features", False)):
            current_value = np.asarray(
                bundle.target_data,
                dtype=np.float32,
            )
            current_delta = np.zeros_like(current_value)
            current_delta[1:] = (
                current_value[1:] - current_value[:-1]
            )
            feature_parts.extend([current_value, current_delta])
            representation_description += (
                " plus diagnostic current target value and one-step delta"
            )

        all_repr = np.concatenate(
            feature_parts,
            axis=1,
        ).astype(np.float32, copy=False)

        self._write_log(
            str(log_path),
            f"[Ridge features] state_delta="
            f"{bool(getattr(self.args, 'ridge_state_features', False))} "
            f"| dim={all_repr.shape[1]}",
        )

        train_repr = all_repr[
            bundle.train_slice
        ]
        valid_repr = all_repr[
            bundle.valid_slice
        ]
        test_repr = all_repr[
            bundle.test_slice
        ]

        train_data = bundle.target_data[
            bundle.train_slice
        ]
        valid_data = bundle.target_data[
            bundle.valid_slice
        ]
        test_data = bundle.target_data[
            bundle.test_slice
        ]
        raw_test_data = bundle.raw_target_data[
            bundle.test_slice
        ]

        pred_lens = [
            int(value)
            for value in self.args.pred_lens
        ]
        context = int(
            self.args.forecast_context
        )

        results = {
            "protocol": (
                "diagnostic_residual_ridge_v5_forecast_safe_"
                "values_encoder_plus_calendar_probe"
            ),
            "diagnostic_residual_targets": True,
            "residual_definition": "future_normalized_value_minus_current_normalized_value",
            "prediction_reconstruction": "absolute_prediction=current_value+predicted_residual",
            "architecture_version": 3,
            "pretrain_protocol_version": 5,
            "evaluation_version": 5,
            "dataset": bundle.data_name,
            "split": bundle.split_info,
            "target_names": list(
                bundle.target_names
            ),
            "forecast_context": context,
            "encoder_infer_time_sec": float(
                encoder_infer_time
            ),
            "representation": representation_description,
            "diagnostic_ridge_state_features": bool(
                getattr(self.args, "ridge_state_features", False)
            ),
            "ridge": {
                "dtype": "float64",
                "solver": "shared_spectrum_eigh",
                "fit_intercept": True,
                "decomposition": "eigh(X_centered.T @ X_centered)",
                "multioutput": "shared exact closed form",
                "alpha_grid": [
                    float(value)
                    for value in self.RIDGE_ALPHAS
                ],
                "selection_metric": (
                    "validation RMSE + validation MAE"
                ),
            },
            "horizons": {},
        }

        for pred_len in pred_lens:
            train_x, train_y = (
                self._generate_pred_samples(
                    train_repr,
                    train_data,
                    pred_len,
                    drop=context,
                )
            )
            valid_x, valid_y = (
                self._generate_pred_samples(
                    valid_repr,
                    valid_data,
                    pred_len,
                    drop=0,
                )
            )
            test_x, test_y = (
                self._generate_pred_samples(
                    test_repr,
                    test_data,
                    pred_len,
                    drop=0,
                )
            )

            alignment = {
                "train_max_abs_error": (
                    self._validate_label_alignment(
                        train_data[context:],
                        train_y,
                        pred_len,
                        "TRAIN",
                    )
                ),
                "valid_max_abs_error": (
                    self._validate_label_alignment(
                        valid_data,
                        valid_y,
                        pred_len,
                        "VALID",
                    )
                ),
                "test_max_abs_error": (
                    self._validate_label_alignment(
                        test_data,
                        test_y,
                        pred_len,
                        "TEST",
                    )
                ),
            }

            # Residual-target diagnostic.  For each forecast origin t, the
            # Ridge target is y[t+1:t+1+H] - x[t].  Zero residual prediction is
            # exactly the persistence baseline.  Alpha selection remains based
            # on validation RMSE+MAE; residual-space errors are identical to
            # reconstructed absolute-space errors because x[t] cancels.
            train_current = self._persistence_prediction(
                train_data,
                pred_len,
                drop=context,
            ).reshape(train_y.shape)
            valid_current = self._persistence_prediction(
                valid_data,
                pred_len,
                drop=0,
            ).reshape(valid_y.shape)
            test_current = self._persistence_prediction(
                test_data,
                pred_len,
                drop=0,
            ).reshape(test_y.shape)

            train_residual_y = np.ascontiguousarray(
                train_y - train_current,
                dtype=np.float64,
            )
            valid_residual_y = np.ascontiguousarray(
                valid_y - valid_current,
                dtype=np.float64,
            )

            self._write_log(
                str(log_path),
                f"[Residual targets H={pred_len}] "
                f"train={train_residual_y.shape} "
                f"valid={valid_residual_y.shape} | "
                "zero residual == persistence",
            )

            ridge_start = time.time()
            (
                regressor,
                best_alpha,
                valid_score,
                alpha_records,
            ) = self._fit_ridge(
                train_x,
                train_residual_y,
                valid_x,
                valid_residual_y,
            )
            ridge_train_time = (
                time.time()
                - ridge_start
            )

            infer_start = time.time()
            test_residual_pred = regressor.predict(
                np.ascontiguousarray(
                    test_x,
                    dtype=np.float64,
                )
            )
            test_pred = test_current + test_residual_pred
            ridge_infer_time = (
                time.time()
                - infer_start
            )

            n_targets = int(
                test_data.shape[1]
            )
            shape = (
                -1,
                pred_len,
                n_targets,
            )

            test_pred_norm = np.asarray(
                test_pred,
                dtype=np.float64,
            ).reshape(shape)
            test_y_norm = np.asarray(
                test_y,
                dtype=np.float64,
            ).reshape(shape)

            test_pred_raw = (
                bundle.scaler.inverse_transform(
                    test_pred_norm
                )
            )
            test_y_raw = (
                bundle.scaler.inverse_transform(
                    test_y_norm
                )
            )

            _, direct_raw_y = (
                self._generate_pred_samples(
                    test_repr,
                    raw_test_data,
                    pred_len,
                    drop=0,
                )
            )
            direct_raw_y = np.asarray(
                direct_raw_y,
                dtype=np.float64,
            ).reshape(shape)

            inverse_transform_error = float(
                np.max(
                    np.abs(
                        test_y_raw
                        - direct_raw_y
                    )
                )
            )
            if inverse_transform_error > 1e-4:
                raise RuntimeError(
                    "Inverse scaling consistency check failed: "
                    f"max_abs_error={inverse_transform_error:.3e}"
                )

            norm_metrics = self._metrics(
                test_pred_norm,
                test_y_norm,
            )
            raw_metrics = self._metrics(
                test_pred_raw,
                direct_raw_y,
            )

            persistence_norm = (
                self._persistence_prediction(
                    test_data,
                    pred_len,
                    drop=0,
                )
            )
            persistence_raw = (
                self._persistence_prediction(
                    raw_test_data,
                    pred_len,
                    drop=0,
                )
            )
            persistence_norm_metrics = (
                self._metrics(
                    persistence_norm,
                    test_y_norm,
                )
            )
            persistence_raw_metrics = (
                self._metrics(
                    persistence_raw,
                    direct_raw_y,
                )
            )

            train_mean = np.mean(
                train_data,
                axis=0,
                dtype=np.float64,
            )
            mean_norm = np.broadcast_to(
                train_mean[
                    None,
                    None,
                    :,
                ],
                test_y_norm.shape,
            ).copy()
            mean_raw_value = (
                bundle.scaler.inverse_transform(
                    train_mean[
                        None,
                        :,
                    ]
                )[0]
            )
            mean_raw = np.broadcast_to(
                mean_raw_value[
                    None,
                    None,
                    :,
                ],
                direct_raw_y.shape,
            ).copy()
            mean_norm_metrics = self._metrics(
                mean_norm,
                test_y_norm,
            )
            mean_raw_metrics = self._metrics(
                mean_raw,
                direct_raw_y,
            )

            per_target_norm = (
                self._per_target_metrics(
                    test_pred_norm,
                    test_y_norm,
                    bundle.target_names,
                )
            )
            per_target_raw = (
                self._per_target_metrics(
                    test_pred_raw,
                    direct_raw_y,
                    bundle.target_names,
                )
            )

            feature_std = np.std(
                np.asarray(
                    train_x,
                    dtype=np.float64,
                ),
                axis=0,
            )
            centered_features = np.asarray(
                train_x,
                dtype=np.float64,
            )
            centered_features = (
                centered_features
                - centered_features.mean(axis=0, keepdims=True)
            )
            singular_values = np.linalg.svd(
                centered_features[
                    : min(5000, centered_features.shape[0])
                ],
                compute_uv=False,
                full_matrices=False,
            )
            singular_prob = singular_values / max(
                singular_values.sum(),
                1e-12,
            )
            effective_rank = float(
                np.exp(
                    -np.sum(
                        singular_prob
                        * np.log(
                            np.clip(singular_prob, 1e-12, None)
                        )
                    )
                )
            )

            feature_diagnostics = {
                "effective_rank": effective_rank,
                "min_std": float(
                    np.min(feature_std)
                ),
                "median_std": float(
                    np.median(feature_std)
                ),
                "max_std": float(
                    np.max(feature_std)
                ),
                "near_constant_dimensions": int(
                    np.sum(feature_std < 1e-8)
                ),
            }

            with open(
                ckpt_dir
                / f"ridge_residual_h{pred_len}.pkl",
                "wb",
            ) as file:
                pickle.dump(
                    regressor,
                    file,
                )

            if bool(
                getattr(
                    self.args,
                    "save_predictions",
                    False,
                )
            ):
                np.savez_compressed(
                    ckpt_dir
                    / f"predictions_h{pred_len}.npz",
                    norm=test_pred_norm,
                    norm_gt=test_y_norm,
                    raw=test_pred_raw,
                    raw_gt=direct_raw_y,
                    persistence_norm=persistence_norm,
                    persistence_raw=persistence_raw,
                    predicted_residual_norm=np.asarray(
                        test_residual_pred,
                        dtype=np.float64,
                    ).reshape(shape),
                )

            boundary_alpha = bool(
                best_alpha
                == float(
                    self.RIDGE_ALPHAS[-1]
                )
            )
            beats_persistence = bool(
                norm_metrics["MSE"]
                < persistence_norm_metrics[
                    "MSE"
                ]
            )

            results["horizons"][
                str(pred_len)
            ] = {
                "target_mode": "residual_to_current_value",
                "zero_residual_is_persistence": True,
                "best_alpha": best_alpha,
                "alpha_at_search_upper_bound": (
                    boundary_alpha
                ),
                "validation_rmse_plus_mae": float(
                    valid_score
                ),
                "alpha_search": alpha_records,
                "norm": norm_metrics,
                "raw": raw_metrics,
                "per_target_norm": per_target_norm,
                "per_target_raw": per_target_raw,
                "baselines": {
                    "persistence": {
                        "norm": (
                            persistence_norm_metrics
                        ),
                        "raw": (
                            persistence_raw_metrics
                        ),
                    },
                    "train_mean": {
                        "norm": mean_norm_metrics,
                        "raw": mean_raw_metrics,
                    },
                },
                "beats_persistence_on_norm_mse": (
                    beats_persistence
                ),
                "alignment_checks": alignment,
                "inverse_transform_max_abs_error": (
                    inverse_transform_error
                ),
                "feature_diagnostics": (
                    feature_diagnostics
                ),
                "ridge_train_time_sec": float(
                    ridge_train_time
                ),
                "ridge_infer_time_sec": float(
                    ridge_infer_time
                ),
                "n_train_samples": int(
                    train_x.shape[0]
                ),
                "n_valid_samples": int(
                    valid_x.shape[0]
                ),
                "n_test_samples": int(
                    test_x.shape[0]
                ),
                "representation_dim": int(
                    train_x.shape[1]
                ),
            }

            self._write_log(
                str(log_path),
                f"[Checks H={pred_len}] "
                f"alignment(train/valid/test)="
                f"{alignment['train_max_abs_error']:.1e}/"
                f"{alignment['valid_max_abs_error']:.1e}/"
                f"{alignment['test_max_abs_error']:.1e} | "
                f"inverse_error="
                f"{inverse_transform_error:.1e}",
            )
            self._write_log(
                str(log_path),
                f"[Baselines H={pred_len}] "
                f"Persistence Norm MSE="
                f"{persistence_norm_metrics['MSE']:.6f} "
                f"MAE="
                f"{persistence_norm_metrics['MAE']:.6f} | "
                f"TrainMean Norm MSE="
                f"{mean_norm_metrics['MSE']:.6f} "
                f"MAE="
                f"{mean_norm_metrics['MAE']:.6f}",
            )
            self._write_log(
                str(log_path),
                f"H={pred_len:>3d} | "
                f"alpha={best_alpha:g}"
                f"{' [GRID MAX]' if boundary_alpha else ''} | "
                f"Norm MSE="
                f"{norm_metrics['MSE']:.6f} "
                f"MAE="
                f"{norm_metrics['MAE']:.6f} | "
                f"Raw MSE="
                f"{raw_metrics['MSE']:.6f} "
                f"MAE="
                f"{raw_metrics['MAE']:.6f} | "
                f"beats_persistence="
                f"{beats_persistence}",
            )

        metrics_path = (
            ckpt_dir
            / "final_metrics.json"
        )

        with open(
            metrics_path,
            "w",
            encoding="utf-8",
        ) as file:
            json.dump(
                results,
                file,
                indent=2,
                ensure_ascii=False,
            )

        self._write_log(
            str(log_path),
            f"Saved metrics: {metrics_path}",
        )

        return results

    def test(self, setting):
        return self.train(setting)
