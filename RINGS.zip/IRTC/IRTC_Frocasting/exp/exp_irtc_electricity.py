from __future__ import annotations

import json
import pickle
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.optim import AdamW

from common.utils import save_checkpoint
from data_provider.data_factory_electricity import (
    electricity_data_provider,
    electricity_forecasting_data_provider,
)
from exp.exp_irtc import Exp_IRTC as BaseExpIRTC


class Exp_IRTC_Electricity(BaseExpIRTC):
    """IRTC v5 for TS2Vec's Electricity client-as-instance protocol."""

    def pretrain(self, setting):
        _, train_loader = electricity_data_provider(self.args, "pretrain")
        augmentors, criterion = self._build_ssl_components()

        optimizer = AdamW(
            self.model.parameters(),
            lr=self.args.learning_rate,
            weight_decay=self.args.weight_decay,
        )

        ckpt_dir = self._ckpt_dir(setting)
        log_path = ckpt_dir / "log.txt"
        self._write_log(str(log_path), f"Setting: {setting}")
        self._write_log(str(log_path), f"Arguments: {vars(self.args)}")
        self._write_log(
            str(log_path),
            "Electricity protocol: TS2Vec client-as-instance layout; "
            "value-only forecast-safe IRTC encoder; TRAIN-only deterministic "
            "window sampling; final checkpoint selected by fixed epoch budget.",
        )

        metrics = None
        for epoch in range(1, int(self.args.train_epochs) + 1):
            self.model.train()
            totals = {
                "total": 0.0,
                "irtc_total": 0.0,
                "state_recon": 0.0,
                "variance": 0.0,
                "tic": 0.0,
                "trgc": 0.0,
                "frgc": 0.0,
                "tfrc": 0.0,
            }
            count = 0
            start = time.time()
            graph_weight = self._graph_weight(epoch, self.args.train_epochs)

            for seq_x, _ in train_loader:
                batch_size = int(seq_x.size(0))
                losses = self._ssl_forward(
                    seq_x,
                    augmentors,
                    criterion,
                    graph_weight=graph_weight,
                )
                optimizer.zero_grad(set_to_none=True)
                losses["total"].backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), self.args.clip_grad)
                optimizer.step()

                for key in totals:
                    totals[key] += float(losses[key].detach().cpu()) * batch_size
                count += batch_size

            metrics = {key: value / max(count, 1) for key, value in totals.items()}
            text = " | ".join(f"{key}={value:.6f}" for key, value in metrics.items())
            self._write_log(
                str(log_path),
                f"Pretrain Epoch {epoch:03d}/{self.args.train_epochs} | "
                f"{text} | graph_w={graph_weight:.2f} | "
                f"{time.time() - start:.1f}s",
            )

            save_checkpoint(
                str(ckpt_dir / "last.pth"),
                epoch=epoch,
                model_state=self.model.state_dict(),
                args=vars(self.args),
                train_pretrain_loss=metrics["total"],
                architecture_version=3,
                protocol_version=5,
                protocol="forecast_safe_electricity_client_as_instance",
            )

        final_checkpoint = ckpt_dir / "best.pth"
        save_checkpoint(
            str(final_checkpoint),
            epoch=int(self.args.train_epochs),
            model_state=self.model.state_dict(),
            args=vars(self.args),
            train_pretrain_loss=metrics["total"],
            selection="final_training_epoch",
            architecture_version=3,
            protocol_version=5,
            protocol="forecast_safe_electricity_client_as_instance",
        )
        self._write_log(str(log_path), f"Saved pretrained encoder: {final_checkpoint}")
        return str(final_checkpoint)

    def _extract_point_features(self, bundle, series_ids, timestamps):
        series_ids = np.asarray(series_ids, dtype=np.int64)
        timestamps = np.asarray(timestamps, dtype=np.int64)
        if series_ids.shape != timestamps.shape:
            raise ValueError("series_ids and timestamps must have identical shape")

        context = int(self.args.forecast_context)
        batch_size = int(self.args.repr_batch_size)
        output = None
        self.model.eval()

        with torch.inference_mode():
            for begin in range(0, len(series_ids), batch_size):
                end = min(len(series_ids), begin + batch_size)
                s = series_ids[begin:end]
                t = timestamps[begin:end]
                if np.any(t < context):
                    raise ValueError("Timestamp is smaller than forecast_context")

                windows = np.stack(
                    [
                        bundle.target_data[si, ti - context : ti + 1]
                        for si, ti in zip(s.tolist(), t.tolist())
                    ],
                    axis=0,
                ).astype(np.float32, copy=False)
                x = torch.from_numpy(windows).to(self.device, non_blocking=True)
                z = self.model.encode_timestamp(x)
                z = z.reshape(z.size(0), -1).detach().cpu().numpy().astype(
                    np.float32, copy=False
                )
                calendar = bundle.model_data[s, t, : bundle.n_covariate_cols]
                features = np.concatenate([z, calendar], axis=1).astype(
                    np.float32, copy=False
                )
                if output is None:
                    output = np.empty((len(series_ids), features.shape[1]), dtype=np.float32)
                output[begin:end] = features

        if output is None:
            raise ValueError("No point features requested")
        return output

    @staticmethod
    def _pair_targets(data, series_ids, timestamps, pred_len):
        series_ids = np.asarray(series_ids, dtype=np.int64)
        timestamps = np.asarray(timestamps, dtype=np.int64)
        offsets = np.arange(1, int(pred_len) + 1, dtype=np.int64)
        return data[
            series_ids[:, None],
            timestamps[:, None] + offsets[None, :],
            0,
        ]

    def _sample_pairs(self, bundle, split_slice, pred_len, max_samples, seed, train):
        n_instances = int(bundle.target_data.shape[0])
        context = int(self.args.forecast_context)
        start = int(split_slice.start or 0)
        stop = int(split_slice.stop)
        first_t = max(start, context if train else start)
        last_t = stop - int(pred_len) - 1
        if last_t < first_t:
            raise ValueError(
                f"No eligible points: split=[{start},{stop}), H={pred_len}, context={context}"
            )
        n_times = last_t - first_t + 1
        total = n_instances * n_times
        take = min(int(max_samples), total)
        rng = np.random.default_rng(int(seed))
        if take == total:
            flat = np.arange(total, dtype=np.int64)
        else:
            flat = rng.choice(total, size=take, replace=False)
            flat.sort()
        series_ids = flat // n_times
        timestamps = first_t + (flat % n_times)
        return series_ids.astype(np.int64), timestamps.astype(np.int64), total

    @staticmethod
    def _metric_accumulator():
        return {"sq": 0.0, "abs": 0.0, "count": 0}

    @staticmethod
    def _accumulate(acc, pred, target):
        diff = np.asarray(pred, dtype=np.float64) - np.asarray(target, dtype=np.float64)
        acc["sq"] += float(np.sum(diff * diff, dtype=np.float64))
        acc["abs"] += float(np.sum(np.abs(diff), dtype=np.float64))
        acc["count"] += int(diff.size)

    @staticmethod
    def _finish(acc):
        if acc["count"] <= 0:
            raise RuntimeError("Empty metric accumulator")
        return {
            "MSE": acc["sq"] / acc["count"],
            "MAE": acc["abs"] / acc["count"],
        }

    def _evaluate_test_stream(self, bundle, regressor, pred_len):
        n_instances = int(bundle.target_data.shape[0])
        context = int(self.args.forecast_context)
        start = max(int(bundle.test_slice.start), context)
        stop = int(bundle.test_slice.stop)
        last_t = stop - int(pred_len) - 1
        n_times = last_t - start + 1
        if n_times <= 0:
            raise ValueError(f"No TEST points for H={pred_len}")

        total_samples = n_instances * n_times
        chunk_size = max(1, int(self.args.repr_batch_size) * 4)
        norm_acc = self._metric_accumulator()
        raw_acc = self._metric_accumulator()
        persist_norm_acc = self._metric_accumulator()
        persist_raw_acc = self._metric_accumulator()
        mean_norm_acc = self._metric_accumulator()
        mean_raw_acc = self._metric_accumulator()
        inverse_error = 0.0

        train_mean_norm = bundle.target_data[:, bundle.train_slice, 0].mean(axis=1)
        train_mean_raw = bundle.raw_target_data[:, bundle.train_slice, 0].mean(axis=1)

        infer_start = time.time()
        for flat_start in range(0, total_samples, chunk_size):
            flat_end = min(total_samples, flat_start + chunk_size)
            flat = np.arange(flat_start, flat_end, dtype=np.int64)
            series_ids = flat // n_times
            timestamps = start + (flat % n_times)

            x = self._extract_point_features(bundle, series_ids, timestamps)
            y_norm = self._pair_targets(
                bundle.target_data, series_ids, timestamps, pred_len
            ).astype(np.float64, copy=False)
            y_raw = self._pair_targets(
                bundle.raw_target_data, series_ids, timestamps, pred_len
            ).astype(np.float64, copy=False)
            pred_norm = regressor.predict(np.asarray(x, dtype=np.float64))
            pred_raw = bundle.scaler.inverse_instances(pred_norm, series_ids)
            inverse_y = bundle.scaler.inverse_instances(y_norm, series_ids)
            inverse_error = max(
                inverse_error,
                float(np.max(np.abs(inverse_y - y_raw))),
            )

            current_norm = bundle.target_data[series_ids, timestamps, 0].astype(np.float64)
            current_raw = bundle.raw_target_data[series_ids, timestamps, 0].astype(np.float64)
            persistence_norm = np.repeat(current_norm[:, None], pred_len, axis=1)
            persistence_raw = np.repeat(current_raw[:, None], pred_len, axis=1)
            mean_norm = np.repeat(train_mean_norm[series_ids, None], pred_len, axis=1)
            mean_raw = np.repeat(train_mean_raw[series_ids, None], pred_len, axis=1)

            self._accumulate(norm_acc, pred_norm, y_norm)
            self._accumulate(raw_acc, pred_raw, y_raw)
            self._accumulate(persist_norm_acc, persistence_norm, y_norm)
            self._accumulate(persist_raw_acc, persistence_raw, y_raw)
            self._accumulate(mean_norm_acc, mean_norm, y_norm)
            self._accumulate(mean_raw_acc, mean_raw, y_raw)

        return {
            "norm": self._finish(norm_acc),
            "raw": self._finish(raw_acc),
            "persistence_norm": self._finish(persist_norm_acc),
            "persistence_raw": self._finish(persist_raw_acc),
            "train_mean_norm": self._finish(mean_norm_acc),
            "train_mean_raw": self._finish(mean_raw_acc),
            "inverse_error": inverse_error,
            "n_test_samples": total_samples,
            "ridge_and_encoder_infer_time_sec": time.time() - infer_start,
        }

    def train(self, setting):
        self._load_pretrain()
        for parameter in self.model.parameters():
            parameter.requires_grad = False

        bundle = electricity_forecasting_data_provider(self.args)
        ckpt_dir = self._ckpt_dir(setting)
        log_path = ckpt_dir / "log.txt"
        self._write_log(str(log_path), f"Setting: {setting}")
        self._write_log(str(log_path), f"Arguments: {vars(self.args)}")
        self._write_log(
            str(log_path),
            "Electricity evaluation: official TS2Vec client-as-instance layout; "
            "frozen value-only endpoint encoder; current calendar appended to Ridge; "
            "TRAIN/VALID Ridge samples capped by ridge_max_samples; TEST streamed in full.",
        )

        results = {
            "protocol": "ts2vec_electricity_client_as_instance_v5_direct_ridge",
            "architecture_version": 3,
            "pretrain_protocol_version": 5,
            "evaluation_version": 5,
            "dataset": "electricity",
            "features_mode": self.args.features,
            "split": bundle.split_info,
            "forecast_context": int(self.args.forecast_context),
            "representation": "value-only causal endpoint plus current calendar covariates",
            "ridge": {
                "dtype": "float64",
                "solver": "shared_spectrum_eigh",
                "alpha_grid": [float(v) for v in self.RIDGE_ALPHAS],
                "selection_metric": "validation RMSE + validation MAE",
                "ridge_max_samples": int(self.args.ridge_max_samples),
            },
            "horizons": {},
        }

        max_samples = int(self.args.ridge_max_samples)
        for pred_len in [int(v) for v in self.args.pred_lens]:
            train_s, train_t, train_total = self._sample_pairs(
                bundle,
                bundle.train_slice,
                pred_len,
                max_samples,
                self.args.seed + pred_len,
                train=True,
            )
            valid_s, valid_t, valid_total = self._sample_pairs(
                bundle,
                bundle.valid_slice,
                pred_len,
                max_samples,
                self.args.seed + 10000 + pred_len,
                train=False,
            )

            feature_start = time.time()
            train_x = self._extract_point_features(bundle, train_s, train_t)
            valid_x = self._extract_point_features(bundle, valid_s, valid_t)
            feature_time = time.time() - feature_start
            train_y = self._pair_targets(bundle.target_data, train_s, train_t, pred_len)
            valid_y = self._pair_targets(bundle.target_data, valid_s, valid_t, pred_len)

            ridge_start = time.time()
            regressor, best_alpha, valid_score, alpha_records = self._fit_ridge(
                train_x, train_y, valid_x, valid_y
            )
            ridge_train_time = time.time() - ridge_start
            test = self._evaluate_test_stream(bundle, regressor, pred_len)

            feature_std = np.std(np.asarray(train_x, dtype=np.float64), axis=0)
            centered = np.asarray(train_x[: min(5000, len(train_x))], dtype=np.float64)
            centered -= centered.mean(axis=0, keepdims=True)
            singular_values = np.linalg.svd(centered, compute_uv=False, full_matrices=False)
            prob = singular_values / max(float(singular_values.sum()), 1e-12)
            effective_rank = float(
                np.exp(-np.sum(prob * np.log(np.clip(prob, 1e-12, None))))
            )

            with open(ckpt_dir / f"ridge_h{pred_len}.pkl", "wb") as file:
                pickle.dump(regressor, file)

            boundary = bool(best_alpha == float(self.RIDGE_ALPHAS[-1]))
            beats = bool(test["norm"]["MSE"] < test["persistence_norm"]["MSE"])
            results["horizons"][str(pred_len)] = {
                "best_alpha": float(best_alpha),
                "alpha_at_search_upper_bound": boundary,
                "validation_rmse_plus_mae": float(valid_score),
                "alpha_search": alpha_records,
                "norm": test["norm"],
                "raw": test["raw"],
                "baselines": {
                    "persistence": {
                        "norm": test["persistence_norm"],
                        "raw": test["persistence_raw"],
                    },
                    "train_mean": {
                        "norm": test["train_mean_norm"],
                        "raw": test["train_mean_raw"],
                    },
                },
                "beats_persistence_on_norm_mse": beats,
                "inverse_transform_max_abs_error": float(test["inverse_error"]),
                "feature_diagnostics": {
                    "effective_rank": effective_rank,
                    "min_std": float(feature_std.min()),
                    "median_std": float(np.median(feature_std)),
                    "max_std": float(feature_std.max()),
                    "near_constant_dimensions": int(np.sum(feature_std < 1e-8)),
                },
                "n_train_samples_used": int(len(train_x)),
                "n_train_samples_available": int(train_total),
                "n_valid_samples_used": int(len(valid_x)),
                "n_valid_samples_available": int(valid_total),
                "n_test_samples": int(test["n_test_samples"]),
                "representation_dim": int(train_x.shape[1]),
                "feature_extract_time_sec": float(feature_time),
                "ridge_train_time_sec": float(ridge_train_time),
                "test_stream_time_sec": float(test["ridge_and_encoder_infer_time_sec"]),
            }

            self._write_log(
                str(log_path),
                f"[Checks H={pred_len}] inverse_error={test['inverse_error']:.2e} | "
                f"TRAIN used/available={len(train_x)}/{train_total} | "
                f"VALID used/available={len(valid_x)}/{valid_total} | "
                f"TEST={test['n_test_samples']}",
            )
            self._write_log(
                str(log_path),
                f"[Baselines H={pred_len}] Persistence Norm MSE="
                f"{test['persistence_norm']['MSE']:.6f} MAE="
                f"{test['persistence_norm']['MAE']:.6f} | TrainMean Norm MSE="
                f"{test['train_mean_norm']['MSE']:.6f} MAE="
                f"{test['train_mean_norm']['MAE']:.6f}",
            )
            self._write_log(
                str(log_path),
                f"H={pred_len:>3d} | alpha={best_alpha:g}"
                f"{' [GRID MAX]' if boundary else ''} | Norm MSE="
                f"{test['norm']['MSE']:.6f} MAE={test['norm']['MAE']:.6f} | "
                f"Raw MSE={test['raw']['MSE']:.6f} MAE={test['raw']['MAE']:.6f} | "
                f"beats_persistence={beats}",
            )

        metrics_path = ckpt_dir / "final_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as file:
            json.dump(results, file, indent=2, ensure_ascii=False)
        self._write_log(str(log_path), f"Saved metrics: {metrics_path}")
        return results
