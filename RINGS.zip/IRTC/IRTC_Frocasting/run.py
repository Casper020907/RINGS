# -*- coding: utf-8 -*-

import argparse

import torch

from exp.exp_irtc import Exp_IRTC


def get_args():
    parser = argparse.ArgumentParser(
        description=(
            "IRTC v5 forecast-safe endpoint forecasting with "
            "TS2Vec-style frozen Ridge evaluation"
        )
    )

    parser.add_argument(
        "--task_name",
        type=str,
        default="pretrain",
        choices=[
            "pretrain",
            "finetune",
            "test",
        ],
    )
    parser.add_argument(
        "--is_training",
        type=int,
        default=1,
    )
    parser.add_argument(
        "--model_id",
        type=str,
        default="ETTh1_IRTC_TS2Vec_v5",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="IRTC",
    )
    parser.add_argument(
        "--data",
        type=str,
        default="ETTh1",
    )
    parser.add_argument(
        "--root_path",
        type=str,
        default=(
            "/root/IRTC_SimMTM_style/"
            "datasets/ETT-small/"
        ),
    )
    parser.add_argument(
        "--data_path",
        type=str,
        default="ETTh1.csv",
    )
    parser.add_argument(
        "--features",
        type=str,
        default="M",
        choices=["M", "S"],
    )
    parser.add_argument(
        "--target",
        type=str,
        default="OT",
    )
    parser.add_argument(
        "--split_protocol",
        type=str,
        default="ts2vec",
        choices=["ts2vec"],
    )
    parser.add_argument(
        "--checkpoints",
        type=str,
        default="./checkpoints",
    )
    parser.add_argument(
        "--transfer_checkpoints",
        type=str,
        default="",
    )

    parser.add_argument(
        "--seq_len",
        type=int,
        default=336,
    )
    parser.add_argument(
        "--label_len",
        type=int,
        default=48,
    )
    parser.add_argument(
        "--pred_len",
        type=int,
        default=24,
    )
    parser.add_argument(
        "--pred_lens",
        type=int,
        nargs="+",
        default=[
            24,
            48,
            168,
            336,
            720,
        ],
    )
    parser.add_argument(
        "--forecast_context",
        type=int,
        default=200,
    )
    parser.add_argument(
        "--repr_batch_size",
        type=int,
        default=256,
    )
    parser.add_argument(
        "--ridge_max_samples",
        type=int,
        default=100000,
    )
    parser.add_argument(
        "--save_predictions",
        action="store_true",
    )
    parser.add_argument(
        "--ridge_state_features",
        action="store_true",
        help=(
            "Diagnostic only: append the current normalized target value "
            "and one-step target delta to the frozen Ridge features."
        ),
    )

    parser.add_argument(
        "--enc_in",
        type=int,
        default=7,
    )
    parser.add_argument(
        "--dec_in",
        type=int,
        default=7,
    )
    parser.add_argument(
        "--c_out",
        type=int,
        default=7,
    )
    parser.add_argument(
        "--n_covariates",
        type=int,
        default=7,
        help=(
            "Calendar covariates are preserved during "
            "time/frequency augmentation."
        ),
    )

    parser.add_argument(
        "--encoder",
        type=str,
        default="transformer",
        choices=[
            "transformer",
            "patchtst",
            "resnet",
            "tcn",
        ],
    )
    parser.add_argument(
        "--d_model",
        type=int,
        default=320,
    )
    parser.add_argument(
        "--d_ff",
        type=int,
        default=640,
    )
    parser.add_argument(
        "--e_layers",
        type=int,
        default=3,
    )
    parser.add_argument(
        "--n_heads",
        type=int,
        default=8,
    )
    parser.add_argument(
        "--dropout",
        type=float,
        default=0.1,
    )
    parser.add_argument(
        "--proj_dim",
        type=int,
        default=320,
    )
    parser.add_argument(
        "--patch_len",
        type=int,
        default=16,
    )
    parser.add_argument(
        "--stride",
        type=int,
        default=8,
    )
    parser.add_argument(
        "--max_patches",
        type=int,
        default=2048,
    )

    # Data are already standardized using TRAIN statistics. RevIN is disabled
    # by default so the Ridge representation retains the current level.
    parser.add_argument(
        "--revin",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--no_revin",
        action="store_false",
        dest="revin",
    )

    parser.add_argument(
        "--train_epochs",
        type=int,
        default=50,
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=32,
    )
    parser.add_argument(
        "--learning_rate",
        type=float,
        default=1e-4,
    )
    parser.add_argument(
        "--weight_decay",
        type=float,
        default=1e-4,
    )
    parser.add_argument(
        "--clip_grad",
        type=float,
        default=5.0,
    )
    parser.add_argument(
        "--num_workers",
        type=int,
        default=0,
    )
    parser.add_argument(
        "--num_threads",
        type=int,
        default=4,
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
    )

    parser.add_argument(
        "--lambda_state_recon",
        type=float,
        default=1.0,
        help="Weight for reconstructing the final physical-value patch.",
    )
    parser.add_argument(
        "--lambda_variance",
        type=float,
        default=0.05,
        help="VICReg-style endpoint anti-collapse weight.",
    )

    parser.add_argument(
        "--lambda_tic",
        type=float,
        default=1.0,
    )
    parser.add_argument(
        "--lambda_trgc",
        type=float,
        default=0.2,
    )
    parser.add_argument(
        "--lambda_frgc",
        type=float,
        default=0.2,
    )
    parser.add_argument(
        "--lambda_tfrc",
        type=float,
        default=0.1,
    )
    parser.add_argument(
        "--tau_t",
        type=float,
        default=0.2,
    )
    parser.add_argument(
        "--tau_f",
        type=float,
        default=0.2,
    )
    parser.add_argument(
        "--graph_topk",
        type=int,
        default=0,
    )
    parser.add_argument(
        "--warmup_ratio",
        type=float,
        default=0.1,
    )

    parser.add_argument(
        "--use_gpu",
        action="store_true",
    )
    parser.add_argument(
        "--gpu",
        type=int,
        default=0,
    )

    return parser.parse_args()


if __name__ == "__main__":
    args = get_args()
    torch.set_num_threads(
        args.num_threads
    )

    horizon_tag = "-".join(
        str(value)
        for value in args.pred_lens
    )
    setting = (
        f"{args.task_name}_"
        f"{args.model_id}_"
        f"{args.data}_"
        f"sl{args.seq_len}_"
        f"h{horizon_tag}_"
        f"seed{args.seed}"
    )

    print("Args:", vars(args))
    print("Setting:", setting)

    experiment = Exp_IRTC(args)

    if args.task_name == "pretrain":
        experiment.pretrain(setting)
    elif args.task_name == "finetune":
        experiment.train(setting)
    else:
        experiment.test(setting)
