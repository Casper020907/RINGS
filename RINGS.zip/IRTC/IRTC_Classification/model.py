# -*- coding: utf-8 -*-

import os
import sys
import torch
import torch.nn as nn

_THIS = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_THIS, '..', '..'))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from common.model_blocks import IRTCEncoderModel


class Classifier(nn.Module):
    def __init__(
        self,
        encoder_model: IRTCEncoderModel,
        n_classes: int,
        dropout: float = 0.1,
        clf_repr: str = "encoder",
        head_type: str = "linear",
        head_hidden: int = 0,
    ):
        super().__init__()

        self.encoder_model = encoder_model
        self.clf_repr = clf_repr
        self.head_type = head_type

        if clf_repr == "encoder":
            in_dim = encoder_model.hidden_dim

        elif clf_repr == "projected":
            in_dim = encoder_model.proj_dim

        elif clf_repr == "concat":
            in_dim = encoder_model.hidden_dim + encoder_model.proj_dim

        else:
            raise ValueError(
                f"Unsupported clf_repr={clf_repr}. "
                "Choose from ['encoder', 'projected', 'concat']."
            )

        if head_type == "linear":
            self.classifier = nn.Sequential(
                nn.Dropout(dropout),
                nn.Linear(in_dim, n_classes),
            )

        elif head_type == "mlp":
            hidden = head_hidden if head_hidden and head_hidden > 0 else in_dim
            self.classifier = nn.Sequential(
                nn.Dropout(dropout),
                nn.Linear(in_dim, hidden),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout),
                nn.Linear(hidden, n_classes),
            )

        else:
            raise ValueError(
                f"Unsupported head_type={head_type}. "
                "Choose from ['linear', 'mlp']."
            )

    @property
    def encoder(self):
        return self.encoder_model.encoder

    def forward(self, x):
        if self.clf_repr == "encoder":
            h = self.encoder_model.encode(x, project=False)

        elif self.clf_repr == "projected":
            h = self.encoder_model.encode(x, project=True)

        elif self.clf_repr == "concat":
            h_encoder = self.encoder_model.encode(x, project=False)
            h_projected = self.encoder_model.encode(x, project=True)
            h = torch.cat([h_encoder, h_projected], dim=1)

        else:
            raise ValueError(
                f"Unsupported clf_repr={self.clf_repr}. "
                "Choose from ['encoder', 'projected', 'concat']."
            )

        return self.classifier(h)


def build_encoder(args):
    return IRTCEncoderModel(
        hidden_dim=args.hidden_dim,
        depth=args.depth,
        proj_dim=args.proj_dim,
        dropout=args.dropout,
        encoder_type=getattr(args, 'encoder', 'resnet'),
    )