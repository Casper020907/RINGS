# -*- coding: utf-8 -*-

import argparse
import os
import sys

import torch

_THIS = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_THIS, "..", ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from common.utils import set_seed
from dataloader import build_loaders, infer_n_classes
from model import build_encoder
from trainer import pretrain, finetune


def get_args():
    parser = argparse.ArgumentParser(
        description=(
            "IRTC classification using official TRAIN/TEST splits and "
            "fixed-epoch full fine-tuning."
        )
    )

    # Protocol
    parser.add_argument(
        "--training_mode",
        type=str,
        default="pre_train",
        choices=["pre_train", "fine_tune", "linear"],
    )
    parser.add_argument("--pretrain_dataset", type=str, default="FordA")
    parser.add_argument("--target_dataset", type=str, default="FordA")
    parser.add_argument("--datasets_root", type=str, default="./datasets")
    parser.add_argument("--checkpoints", type=str, default="./checkpoints")
    parser.add_argument("--experiment_name", type=str, default=None)
    parser.add_argument("--skip_finetune", action="store_true")
    parser.add_argument("--pretrained_checkpoint", type=str, default=None)

    # Optimization
    parser.add_argument("--pretrain_epoch", type=int, default=100)
    parser.add_argument("--finetune_epoch", type=int, default=300)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--ft_lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--clip_grad", type=float, default=5.0)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--num_threads", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--label_ratio", type=float, default=1.0)
    parser.add_argument(
        "--pretrain_samples",
        type=int,
        default=0,
        help=(
            "Maximum number of official TRAIN samples used for SSL "
            "pretraining. 0 uses the complete official TRAIN split."
        ),
    )
    parser.add_argument(
        "--finetune_samples",
        type=int,
        default=0,
        help=(
            "Maximum number of official TRAIN samples used for fine-tuning. "
            "0 is controlled by --label_ratio."
        ),
    )
    parser.add_argument(
        "--subset_mode",
        type=str,
        default="stratified",
        choices=["random", "first", "stratified"],
    )

    # Model
    parser.add_argument(
        "--encoder",
        type=str,
        default="resnet",
        choices=["resnet", "tcn", "inception"],
    )
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--depth", type=int, default=4)
    parser.add_argument("--proj_dim", type=int, default=128)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument(
        "--finetune_mode",
        type=str,
        default="full",
        choices=["full", "linear"],
    )
    parser.add_argument(
        "--clf_repr",
        type=str,
        default="encoder",
        choices=["encoder", "projected", "concat"],
    )
    parser.add_argument(
        "--head_type",
        type=str,
        default="linear",
        choices=["linear", "mlp"],
    )
    parser.add_argument("--head_hidden", type=int, default=0)

    # Fine-tuning regularization
    parser.add_argument("--label_smoothing", type=float, default=0.0)
    parser.add_argument("--mixup_alpha", type=float, default=0.0)
    parser.add_argument("--mixup_prob", type=float, default=1.0)
    parser.add_argument(
        "--class_weight",
        type=str,
        default="none",
        choices=["none", "balanced"],
    )

    # Optional two-stage full fine-tuning
    parser.add_argument("--two_stage_ft", action="store_true")
    parser.add_argument("--stage1_epochs", type=int, default=40)
    parser.add_argument(
        "--encoder_lr",
        type=float,
        default=0.0,
        help="0 means use --ft_lr.",
    )
    parser.add_argument(
        "--classifier_lr",
        type=float,
        default=0.0,
        help="0 means use --ft_lr.",
    )

    # Kept only for backward CLI compatibility. It is not used because
    # this protocol has no validation split.
    parser.add_argument(
        "--selection_mode",
        type=str,
        default="fixed_epoch",
        help="Ignored in the official TRAIN/TEST fixed-epoch protocol.",
    )

    # IRTC loss
    parser.add_argument("--lambda_tic", type=float, default=1.0)
    parser.add_argument("--lambda_trgc", type=float, default=0.2)
    parser.add_argument("--lambda_frgc", type=float, default=0.2)
    parser.add_argument("--lambda_tfrc", type=float, default=0.1)
    parser.add_argument("--tau_t", type=float, default=0.2)
    parser.add_argument("--tau_f", type=float, default=0.2)
    parser.add_argument("--graph_topk", type=int, default=0)
    parser.add_argument("--warmup_ratio", type=float, default=0.1)

    # Device
    parser.add_argument("--use_gpu", action="store_true")
    parser.add_argument("--gpu", type=int, default=0)

    return parser.parse_args()


def main():
    args = get_args()
    torch.set_num_threads(args.num_threads)
    set_seed(args.seed)

    if args.experiment_name is None:
        args.experiment_name = (
            f"IRTC_{args.pretrain_dataset}_to_"
            f"{args.target_dataset}_seed{args.seed}"
        )

    if args.training_mode == "linear":
        args.finetune_mode = "linear"

    print("Args:", vars(args))
    print(
        "Protocol: complete official TRAIN for SSL pretraining and "
        "fine-tuning; no validation split; fixed epoch budgets; "
        "official TEST evaluated once after fine-tuning."
    )

    pretrained_checkpoint = args.pretrained_checkpoint

    if args.training_mode == "pre_train":
        print(
            f"==> SSL pretraining on complete official TRAIN: "
            f"{args.pretrain_dataset}"
        )

        pretrain_loader, _ = build_loaders(
            root=args.datasets_root,
            dataset=args.pretrain_dataset,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            label_ratio=1.0,
            seed=args.seed,
            max_train_samples=args.pretrain_samples,
            subset_mode=args.subset_mode,
        )

        encoder_model = build_encoder(args)
        pretrained_checkpoint = pretrain(
            args,
            encoder_model,
            pretrain_loader,
        )

    if args.skip_finetune:
        return

    if not pretrained_checkpoint:
        raise ValueError(
            "--pretrained_checkpoint is required when "
            "--training_mode=fine_tune."
        )

    print(
        f"==> Full fine-tuning on official TRAIN: "
        f"{args.target_dataset}"
    )

    target_train_loader, target_test_loader = build_loaders(
        root=args.datasets_root,
        dataset=args.target_dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        label_ratio=args.label_ratio,
        seed=args.seed,
        max_train_samples=args.finetune_samples,
        subset_mode=args.subset_mode,
    )

    n_classes = infer_n_classes(
        args.datasets_root,
        args.target_dataset,
    )
    encoder_model = build_encoder(args)

    finetune(
        args,
        encoder_model,
        n_classes,
        target_train_loader,
        target_test_loader,
        ckpt_path=pretrained_checkpoint,
    )


if __name__ == "__main__":
    main()
