# -*- coding: utf-8 -*-
"""
IRTC classification trainer for the official UCR TRAIN/TEST protocol.

Differences from the earlier trainer:
- no validation split;
- pretraining uses a fixed epoch budget;
- fine-tuning uses a fixed epoch budget;
- official TEST is not evaluated during training;
- official TEST is evaluated exactly once after the last fine-tuning epoch.
"""

import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.optim import AdamW

_THIS = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_THIS, "..", ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from common.augmentations import ensure_bct, TimeAugmentor, FreqAugmentor
from common.losses import IRTCLoss
from common.utils import (
    classification_metrics,
    load_checkpoint,
    metric_line,
    mkdir,
    save_checkpoint,
)
from model import Classifier


def _device(args):
    if args.use_gpu:
        if not torch.cuda.is_available():
            raise RuntimeError(
                "--use_gpu was requested, but CUDA is unavailable. "
                f"torch={torch.__version__}, "
                f"torch.version.cuda={torch.version.cuda}"
            )

        gpu_id = int(args.gpu)
        device_count = torch.cuda.device_count()

        if gpu_id < 0 or gpu_id >= device_count:
            raise RuntimeError(
                f"Requested cuda:{gpu_id}, but only "
                f"{device_count} CUDA device(s) are visible."
            )

        device = torch.device(f"cuda:{gpu_id}")
        print(
            f"[Device] Using {device} | "
            f"{torch.cuda.get_device_name(gpu_id)}",
            flush=True,
        )
        return device

    print("[Device] Using CPU", flush=True)
    return torch.device("cpu")


def _graph_weight(epoch, epochs, warmup_ratio):
    warm_epochs = int(max(0, epochs * warmup_ratio))
    if warm_epochs <= 0:
        return 1.0
    if epoch <= warm_epochs:
        return 0.0
    return min(
        1.0,
        (epoch - warm_epochs) / max(1, warm_epochs),
    )


def _python_metrics(metrics):
    """Convert NumPy/Torch scalar values into JSON-safe Python floats."""
    converted = {}
    for key, value in metrics.items():
        if torch.is_tensor(value):
            value = value.detach().cpu().item()
        elif isinstance(value, np.generic):
            value = value.item()

        if isinstance(value, (int, float)):
            converted[key] = float(value)
        else:
            converted[key] = value
    return converted


def pretrain(args, model, train_loader):
    """
    Fixed-epoch SSL pretraining on the official TRAIN split.

    The checkpoint transferred to fine-tuning is pretrain_final.pth from the
    last configured pretraining epoch. No validation or test data is used.
    """
    device = _device(args)
    model.to(device)

    time_weak = TimeAugmentor(weak=True)
    time_strong = TimeAugmentor(weak=False)
    freq_weak = FreqAugmentor(weak=True)
    freq_strong = FreqAugmentor(weak=False)

    criterion = IRTCLoss(
        lambda_tic=args.lambda_tic,
        lambda_trgc=args.lambda_trgc,
        lambda_frgc=args.lambda_frgc,
        lambda_tfrc=args.lambda_tfrc,
        tau_t=args.tau_t,
        tau_f=args.tau_f,
        topk=args.graph_topk,
    )

    optimizer = AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    checkpoint_dir = Path(args.checkpoints) / args.experiment_name
    mkdir(checkpoint_dir)

    final_metrics = None

    for epoch in range(1, args.pretrain_epoch + 1):
        model.train()
        meter = {
            "total": [],
            "tic": [],
            "trgc": [],
            "frgc": [],
            "tfrc": [],
        }

        start = time.time()
        graph_weight = _graph_weight(
            epoch,
            args.pretrain_epoch,
            args.warmup_ratio,
        )

        num_batches = len(train_loader)
        print(
            f"[Pretrain] Epoch {epoch:03d}/{args.pretrain_epoch} started | "
            f"batches={num_batches} | batch_size={args.batch_size}",
            flush=True,
        )

        for batch_idx, batch in enumerate(train_loader, start=1):
            x = ensure_bct(batch[0]).to(
                device,
                non_blocking=True,
            )

            x_tw = time_weak(x)
            x_ts = time_strong(x)
            x_fw = freq_weak(x)
            x_fs = freq_strong(x)

            z_tw = model.encode(x_tw, project=True)
            z_ts = model.encode(x_ts, project=True)
            z_fw = model.encode(x_fw, project=True)
            z_fs = model.encode(x_fs, project=True)

            losses = criterion(
                model,
                z_tw,
                z_ts,
                z_fw,
                z_fs,
                graph_weight=graph_weight,
            )

            optimizer.zero_grad(set_to_none=True)
            losses["total"].backward()
            nn.utils.clip_grad_norm_(
                model.parameters(),
                args.clip_grad,
            )
            optimizer.step()

            for key in meter:
                meter[key].append(
                    float(losses[key].detach().cpu())
                )

            if (
                batch_idx == 1
                or batch_idx % 100 == 0
                or batch_idx == num_batches
            ):
                print(
                    f"Epoch {epoch:03d}/{args.pretrain_epoch} | "
                    f"Batch {batch_idx:05d}/{num_batches:05d} | "
                    f"total={float(losses['total'].detach().cpu()):.5f} | "
                    f"tic={float(losses['tic'].detach().cpu()):.5f} | "
                    f"trgc={float(losses['trgc'].detach().cpu()):.5f} | "
                    f"frgc={float(losses['frgc'].detach().cpu()):.5f} | "
                    f"tfrc={float(losses['tfrc'].detach().cpu()):.5f}",
                    flush=True,
                )

        final_metrics = {
            key: float(np.mean(values))
            for key, values in meter.items()
        }

        line = " | ".join(
            f"{key}={value:.5f}"
            for key, value in final_metrics.items()
        )
        print(
            f"Epoch {epoch:03d}/{args.pretrain_epoch} | "
            f"{line} | graph_w={graph_weight:.2f} | "
            f"{time.time() - start:.1f}s"
        )

        save_checkpoint(
            str(checkpoint_dir / "last.pth"),
            epoch=epoch,
            model_state=model.state_dict(),
            args=vars(args),
            train_metrics=final_metrics,
            protocol="official_train_fixed_epoch_pretraining",
        )

    final_path = checkpoint_dir / "pretrain_final.pth"

    save_checkpoint(
        str(final_path),
        epoch=args.pretrain_epoch,
        model_state=model.state_dict(),
        args=vars(args),
        train_metrics=final_metrics,
        protocol="official_train_fixed_epoch_pretraining",
    )

    # Compatibility alias for older scripts. This is the final epoch, not a
    # validation-selected or training-loss-selected checkpoint.
    save_checkpoint(
        str(checkpoint_dir / "best.pth"),
        epoch=args.pretrain_epoch,
        model_state=model.state_dict(),
        args=vars(args),
        train_metrics=final_metrics,
        protocol="compatibility_alias_of_pretrain_final",
    )

    print(f"Pretraining checkpoint: {final_path}")
    return str(final_path)


def load_pretrained_encoder(model, ckpt_path):
    checkpoint = load_checkpoint(
        ckpt_path,
        map_location="cpu",
    )
    state = checkpoint.get("model_state", checkpoint)

    missing, unexpected = model.load_state_dict(
        state,
        strict=False,
    )

    if missing:
        print(
            f"[Info] Missing keys when loading checkpoint: "
            f"{len(missing)}"
        )
    if unexpected:
        print(
            f"[Info] Unexpected keys when loading checkpoint: "
            f"{len(unexpected)}"
        )

    return model


def evaluate_classifier(model, loader, args):
    device = _device(args)
    model.eval()

    labels_all = []
    logits_all = []

    with torch.no_grad():
        for x, y in loader:
            x = ensure_bct(x).to(device)
            logits = model(x)

            logits_all.append(
                logits.detach().cpu().numpy()
            )
            labels_all.append(y.numpy())

    labels_all = np.concatenate(labels_all, axis=0)
    logits_all = np.concatenate(logits_all, axis=0)

    return _python_metrics(
        classification_metrics(
            labels_all,
            logits_all,
        )
    )


def _mixup_batch(x, y, alpha):
    if alpha <= 0:
        return x, y, y, 1.0

    coefficient = float(np.random.beta(alpha, alpha))
    coefficient = max(coefficient, 1.0 - coefficient)

    index = torch.randperm(
        x.size(0),
        device=x.device,
    )
    mixed_x = (
        coefficient * x
        + (1.0 - coefficient) * x[index]
    )
    return mixed_x, y, y[index], coefficient


def _mixup_criterion(
    criterion,
    logits,
    y_a,
    y_b,
    coefficient,
):
    return (
        coefficient * criterion(logits, y_a)
        + (1.0 - coefficient) * criterion(logits, y_b)
    )


def _collect_train_labels(train_loader):
    labels = []
    for _, y in train_loader:
        labels.append(
            y.detach().cpu().long().view(-1)
        )

    if not labels:
        return torch.empty(0, dtype=torch.long)

    return torch.cat(labels, dim=0)


def _make_ce_criterion(
    args,
    train_loader,
    n_classes,
    device,
):
    class_weight = None

    if args.class_weight == "balanced":
        labels = _collect_train_labels(train_loader)
        counts = torch.bincount(
            labels,
            minlength=n_classes,
        ).float()
        counts = torch.clamp(counts, min=1.0)

        class_weight = counts.sum() / (
            n_classes * counts
        )
        class_weight = class_weight / class_weight.mean()
        class_weight = class_weight.to(device)

        print(
            f"[Loss] class counts={counts.long().tolist()} | "
            f"weights="
            f"{[round(float(v), 4) for v in class_weight.cpu()]}"
        )
    else:
        print("[Loss] class_weight=none")

    print(
        f"[Loss] label_smoothing="
        f"{float(args.label_smoothing)}"
    )

    return nn.CrossEntropyLoss(
        weight=class_weight,
        label_smoothing=float(args.label_smoothing),
    )


def _set_encoder_trainable(model, trainable):
    for parameter in model.encoder_model.parameters():
        parameter.requires_grad = trainable


def _set_classifier_trainable(model, trainable):
    for parameter in model.classifier.parameters():
        parameter.requires_grad = trainable


def _make_optimizer(args, model, phase):
    weight_decay = float(args.weight_decay)
    fine_tune_lr = float(args.ft_lr)

    encoder_lr = (
        float(args.encoder_lr)
        if float(args.encoder_lr) > 0
        else fine_tune_lr
    )
    classifier_lr = (
        float(args.classifier_lr)
        if float(args.classifier_lr) > 0
        else fine_tune_lr
    )

    if phase in {"linear", "stage1_head"}:
        parameters = [
            parameter
            for parameter in model.classifier.parameters()
            if parameter.requires_grad
        ]
        print(
            f"[Optim] phase={phase} | "
            f"classifier_lr={classifier_lr:g} | "
            f"wd={weight_decay:g}"
        )
        return AdamW(
            parameters,
            lr=classifier_lr,
            weight_decay=weight_decay,
        )

    parameter_groups = []

    encoder_parameters = [
        parameter
        for parameter in model.encoder_model.parameters()
        if parameter.requires_grad
    ]
    classifier_parameters = [
        parameter
        for parameter in model.classifier.parameters()
        if parameter.requires_grad
    ]

    if encoder_parameters:
        parameter_groups.append(
            {
                "params": encoder_parameters,
                "lr": encoder_lr,
            }
        )
    if classifier_parameters:
        parameter_groups.append(
            {
                "params": classifier_parameters,
                "lr": classifier_lr,
            }
        )

    print(
        f"[Optim] phase={phase} | "
        f"encoder_lr={encoder_lr:g} | "
        f"classifier_lr={classifier_lr:g} | "
        f"wd={weight_decay:g}"
    )

    return AdamW(
        parameter_groups,
        weight_decay=weight_decay,
    )


def _train_one_epoch(
    args,
    model,
    train_loader,
    criterion,
    optimizer,
):
    device = _device(args)
    model.train()

    losses = []

    for x, y in train_loader:
        x = ensure_bct(x).to(device)
        y = y.long().to(device)

        use_mixup = (
            float(args.mixup_alpha) > 0.0
            and x.size(0) > 1
            and np.random.rand() < float(args.mixup_prob)
        )

        if use_mixup:
            mixed_x, y_a, y_b, coefficient = _mixup_batch(
                x,
                y,
                float(args.mixup_alpha),
            )
            logits = model(mixed_x)
            loss = _mixup_criterion(
                criterion,
                logits,
                y_a,
                y_b,
                coefficient,
            )
        else:
            logits = model(x)
            loss = criterion(logits, y)

        optimizer.zero_grad(set_to_none=True)
        loss.backward()

        nn.utils.clip_grad_norm_(
            [
                parameter
                for parameter in model.parameters()
                if parameter.requires_grad
            ],
            args.clip_grad,
        )
        optimizer.step()

        losses.append(float(loss.detach().cpu()))

    return float(np.mean(losses)) if losses else float("nan")


def finetune(
    args,
    encoder_model,
    n_classes,
    train_loader,
    test_loader,
    ckpt_path=None,
):
    """
    Fixed-epoch supervised fine-tuning.

    The official TEST loader is not touched inside the training loop. It is
    evaluated once, after the final fine-tuning epoch.
    """
    device = _device(args)

    if ckpt_path:
        print(f"Loading pretrained checkpoint: {ckpt_path}")
        encoder_model = load_pretrained_encoder(
            encoder_model,
            ckpt_path,
        )
    else:
        print(
            "[Warning] No pretrained checkpoint provided. "
            "Fine-tuning from random initialization."
        )

    model = Classifier(
        encoder_model,
        n_classes=n_classes,
        dropout=args.dropout,
        clf_repr=args.clf_repr,
        head_type=args.head_type,
        head_hidden=args.head_hidden,
    ).to(device)

    criterion = _make_ce_criterion(
        args,
        train_loader,
        n_classes,
        device,
    )

    checkpoint_dir = Path(args.checkpoints) / args.experiment_name
    mkdir(checkpoint_dir)

    total_epochs = int(args.finetune_epoch)

    two_stage = (
        bool(args.two_stage_ft)
        and args.finetune_mode == "full"
    )
    stage1_epochs = (
        int(args.stage1_epochs)
        if two_stage
        else 0
    )
    stage1_epochs = max(
        0,
        min(stage1_epochs, total_epochs),
    )

    if args.finetune_mode == "linear":
        _set_encoder_trainable(model, False)
        _set_classifier_trainable(model, True)
        optimizer = _make_optimizer(
            args,
            model,
            "linear",
        )
        current_phase = "linear"

    elif two_stage and stage1_epochs > 0:
        _set_encoder_trainable(model, False)
        _set_classifier_trainable(model, True)
        optimizer = _make_optimizer(
            args,
            model,
            "stage1_head",
        )
        current_phase = "stage1_head"

    else:
        _set_encoder_trainable(model, True)
        _set_classifier_trainable(model, True)
        optimizer = _make_optimizer(
            args,
            model,
            "full",
        )
        current_phase = "full"

    final_train_loss = float("nan")

    print(
        "Fine-tune protocol: fixed epoch budget; no validation selection; "
        "official TEST evaluated once after the final epoch."
    )

    for epoch in range(1, total_epochs + 1):
        if (
            two_stage
            and stage1_epochs > 0
            and epoch == stage1_epochs + 1
        ):
            _set_encoder_trainable(model, True)
            _set_classifier_trainable(model, True)
            optimizer = _make_optimizer(
                args,
                model,
                "stage2_full",
            )
            current_phase = "stage2_full"
            print(
                f"[TwoStage] Switch to full fine-tuning "
                f"at epoch {epoch}."
            )

        start = time.time()

        final_train_loss = _train_one_epoch(
            args,
            model,
            train_loader,
            criterion,
            optimizer,
        )

        print(
            f"FT Epoch {epoch:03d}/{total_epochs} | "
            f"phase={current_phase} | "
            f"loss={final_train_loss:.6f} | "
            f"{time.time() - start:.1f}s"
        )

        save_checkpoint(
            str(checkpoint_dir / "last_finetune.pth"),
            epoch=epoch,
            model_state=model.state_dict(),
            args=vars(args),
            phase=current_phase,
            train_loss=final_train_loss,
            protocol="official_train_fixed_epoch_finetuning",
        )

    # This is the only official TEST evaluation.
    test_metrics = evaluate_classifier(
        model,
        test_loader,
        args,
    )

    final_checkpoint = checkpoint_dir / "final_finetune.pth"

    save_checkpoint(
        str(final_checkpoint),
        epoch=total_epochs,
        model_state=model.state_dict(),
        args=vars(args),
        phase=current_phase,
        train_loss=final_train_loss,
        test_metrics=test_metrics,
        protocol="official_test_evaluated_once_after_fixed_epoch_finetuning",
    )

    result = {
        "dataset": args.target_dataset,
        "pretrain_dataset": args.pretrain_dataset,
        "seed": int(args.seed),
        "pretrain_epoch": int(args.pretrain_epoch),
        "finetune_epoch": total_epochs,
        "finetune_mode": args.finetune_mode,
        "label_ratio": float(args.label_ratio),
        "test_metrics": test_metrics,
        "pretrained_checkpoint": ckpt_path,
        "final_checkpoint": str(final_checkpoint),
        "protocol": (
            "Complete official UCR TRAIN is used for SSL pretraining and "
            "supervised fine-tuning; no validation split is constructed; "
            "fixed epoch budgets are used; official TEST is evaluated once "
            "after fine-tuning."
        ),
    }

    with (checkpoint_dir / "final_metrics.json").open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            result,
            file,
            ensure_ascii=False,
            indent=2,
        )

    print("=" * 100)
    print(
        metric_line(
            "Official TEST evaluated once",
            test_metrics,
        )
    )
    print(f"Final checkpoint: {final_checkpoint}")
    print("=" * 100)

    return test_metrics
