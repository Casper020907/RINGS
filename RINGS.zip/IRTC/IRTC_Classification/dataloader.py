# -*- coding: utf-8 -*-
"""
Official UCR TRAIN/TEST dataloader for IRTC classification.

There is no validation loader in this protocol.

- SSL pretraining can use the complete official TRAIN split.
- Fine-tuning can use the complete official TRAIN split or a deterministic
  low-label subset of it.
- Official TEST is returned separately for one final evaluation.
"""

import os
from typing import Tuple

import torch
from torch.utils.data import DataLoader, Subset, TensorDataset


def _extract_xy(obj) -> Tuple[torch.Tensor, torch.Tensor]:
    if isinstance(obj, TensorDataset):
        return obj.tensors[0], obj.tensors[1]

    if isinstance(obj, dict):
        x_keys = ["samples", "data", "x", "X", "features"]
        y_keys = ["labels", "label", "y", "Y", "targets"]

        x = next((obj[key] for key in x_keys if key in obj), None)
        y = next((obj[key] for key in y_keys if key in obj), None)

        if x is None or y is None:
            raise KeyError(
                f"Cannot find sample/label keys. Available keys={list(obj.keys())}"
            )
        return x, y

    if isinstance(obj, (list, tuple)):
        if (
            len(obj) >= 2
            and torch.is_tensor(obj[0])
            and torch.is_tensor(obj[1])
        ):
            return obj[0], obj[1]

        if (
            len(obj) > 0
            and isinstance(obj[0], (list, tuple))
            and len(obj[0]) >= 2
        ):
            xs = torch.stack(
                [
                    item[0]
                    if torch.is_tensor(item[0])
                    else torch.tensor(item[0])
                    for item in obj
                ]
            )
            ys = torch.tensor([int(item[1]) for item in obj])
            return xs, ys

    raise TypeError(f"Unsupported dataset object type: {type(obj)}")


def load_pt_dataset(path: str) -> TensorDataset:
    if not os.path.exists(path):
        raise FileNotFoundError(path)

    obj = torch.load(path, map_location="cpu")
    x, y = _extract_xy(obj)
    return TensorDataset(x.float(), y.long().view(-1))


def dataset_path(root: str, dataset: str, split: str) -> str:
    path = os.path.join(root, dataset, f"{split}.pt")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Missing {split}.pt: {path}")
    return path


def _labels_from_dataset(dataset) -> torch.Tensor:
    if isinstance(dataset, TensorDataset):
        return dataset.tensors[1].long().view(-1)

    if isinstance(dataset, Subset):
        labels = _labels_from_dataset(dataset.dataset)
        indices = torch.as_tensor(dataset.indices, dtype=torch.long)
        return labels[indices]

    raise TypeError(f"Cannot extract labels from {type(dataset)}")


def _subset_train_dataset(
    train_dataset,
    *,
    label_ratio: float = 1.0,
    max_train_samples: int = 0,
    seed: int = 42,
    subset_mode: str = "stratified",
):
    """
    Select a deterministic subset from the official TRAIN split.

    Priority:
      max_train_samples > label_ratio

    The full official TRAIN split is returned when neither restriction applies.
    """
    n_samples = len(train_dataset)

    if max_train_samples is not None and max_train_samples > 0:
        target_size = min(int(max_train_samples), n_samples)
    elif label_ratio is not None and label_ratio < 1.0:
        target_size = max(1, int(round(n_samples * float(label_ratio))))
    else:
        return train_dataset

    target_size = min(max(1, target_size), n_samples)
    generator = torch.Generator().manual_seed(seed)

    if subset_mode == "first":
        indices = list(range(target_size))

    elif subset_mode == "random":
        indices = torch.randperm(
            n_samples,
            generator=generator,
        )[:target_size].tolist()

    elif subset_mode == "stratified":
        labels = _labels_from_dataset(train_dataset)
        selected = []
        remaining = []

        for class_id in torch.unique(labels).tolist():
            class_indices = torch.where(labels == int(class_id))[0]
            permutation = class_indices[
                torch.randperm(len(class_indices), generator=generator)
            ]

            # Allocate approximately proportional samples while retaining
            # at least one sample for each class whenever possible.
            class_target = max(
                1,
                int(round(target_size * len(class_indices) / n_samples)),
            )
            class_target = min(class_target, len(permutation))

            selected.extend(permutation[:class_target].tolist())
            remaining.extend(permutation[class_target:].tolist())

        if len(selected) > target_size:
            selected_tensor = torch.as_tensor(selected, dtype=torch.long)
            selected_tensor = selected_tensor[
                torch.randperm(len(selected_tensor), generator=generator)
            ]
            selected = selected_tensor[:target_size].tolist()

        elif len(selected) < target_size and remaining:
            remaining_tensor = torch.as_tensor(remaining, dtype=torch.long)
            remaining_tensor = remaining_tensor[
                torch.randperm(len(remaining_tensor), generator=generator)
            ]
            selected.extend(
                remaining_tensor[: target_size - len(selected)].tolist()
            )

        indices = selected

    else:
        raise ValueError(
            f"Unsupported subset_mode={subset_mode}; "
            "choose random, first, or stratified."
        )

    subset = Subset(train_dataset, indices)

    print(
        f"[Data] Official TRAIN subset: {len(subset)}/{n_samples} | "
        f"mode={subset_mode} | seed={seed} | label_ratio={label_ratio}"
    )

    if subset_mode == "stratified":
        selected_labels = _labels_from_dataset(subset)
        counts = {
            int(class_id): int((selected_labels == int(class_id)).sum())
            for class_id in torch.unique(selected_labels).tolist()
        }
        print(f"[Data] Subset label counts: {counts}")

    return subset


def build_loaders(
    root: str,
    dataset: str,
    batch_size: int = 128,
    num_workers: int = 0,
    label_ratio: float = 1.0,
    seed: int = 42,
    max_train_samples: int = 0,
    subset_mode: str = "stratified",
):
    """
    Returns:
        train_loader, test_loader

    No validation loader is constructed.
    """
    train_dataset = load_pt_dataset(
        dataset_path(root, dataset, "train")
    )
    test_dataset = load_pt_dataset(
        dataset_path(root, dataset, "test")
    )

    train_dataset = _subset_train_dataset(
        train_dataset,
        label_ratio=label_ratio,
        max_train_samples=max_train_samples,
        seed=seed,
        subset_mode=subset_mode,
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        drop_last=False,
        num_workers=num_workers,
        pin_memory=True,
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=max(batch_size, 256),
        shuffle=False,
        drop_last=False,
        num_workers=num_workers,
        pin_memory=True,
    )

    return train_loader, test_loader


def infer_n_classes(root: str, dataset: str) -> int:
    dataset_obj = load_pt_dataset(dataset_path(root, dataset, "train"))
    labels = dataset_obj.tensors[1]
    return int(torch.unique(labels).numel())
